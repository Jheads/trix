@echo off
chcp 65001
set /p menu=<c:\trix_cmd\0\menu.txt
 
for /F %%a in ('"prompt $E & for %%b in (1) do rem"') do set "ESC=%%a"
set rd=%%ESC%%[31m
set nl=%%ESC%%[30m
set gr=%%ESC%%[32m
set yw=%%ESC%%[33m
set bl=%%ESC%%[34m
set pl=%%ESC%%[35m
set ci=%%ESC%%[36m
set we=%%ESC%%[37m
set sd=%%ESC%%[0m
set ln=%gr%
set cl=%pl%
set c11=%userprofile%\dados\pers\cor\cl
set L11=%userprofile%\dados\pers\cor\ln
if exist %c11%\rd.txt (
   set cl=%rd%
)
if exist %c11%\nl.txt (
   set cl=%nl%
)
if exist %c11%\gr.txt (
   set cl=%gr%
)
if exist %c11%\yw.txt (
   set cl=%yw%
)
if exist %c11%\bl.txt (
   set cl=%bl%
)
if exist %c11%\pl.txt (
   set cl=%pl%
)
if exist %c11%\ci.txt (
   set cl=%ci%
)
if exist %c11%\we.txt (
   set cl=%we%
)
if exist %c11%\sd.txt (
   set cl=%sd%
)
::linhas
if exist %L11%\rd.txt (
   set ln=%rd%
)
if exist %l11%\nl.txt (
   set ln=%nl%
)
if exist %l11%\gr.txt (
   set ln=%gr%
)
if exist %l11%\yw.txt (
   set ln=%yw%
)
if exist %l11%\bl.txt (
   set ln=%bl%
)
if exist %l11%\pl.txt (
   set ln=%pl%
)
if exist %l11%\ci.txt (
   set ln=%ci%
)
if exist %l11%\we.txt (
   set ln=%we%
)
if exist %l11%\sd.txt (
   set ln=%sd%
)


cls
call echo %cl%========================================================
call echo                     %ln%conquistas%cl%
call echo ========================================================%gr%
call echo [v] %ln%voltar%cl%
call echo ========================================================%ln%
call echo suas conquistas são:
call echo %cl%-------------------------------------------------------%yw%
setlocal enabledelayedexpansion

set "pasta=C:\trix_conquistas"

if exist "%pasta%" (
    cd /d "%pasta%"
    for %%f in (*.txt) do (
        set "nome_arquivo=%%~nf"
        echo conquista: !nome_arquivo!
                 type "%%f"
        echo ------------------------
    )
) else (
    echo A %pasta% nao existe, conquistas desativadas
)

endlocal
set /p "opc=escolha uma opção: "
if /i "%opc%"=="v" echo voltando..... & timeout /t 2 >nul & %menu%
﻿
chcp 65001
color 2
cls
@echo off
msg "*" "para criar tarefas o sistema precisa de permissões administrativas. no instalador é opcional mas as atualizações semanais não serão criadas se selecionadas"
echo [pressione qualquer tecla para continuar]
pause >nul
if %errorlevel% neq 0 (
   echo solicitando privilégios de adm...
   powershell -command "start-process cmd -argumentlist '/c \"%~f0\"' -verb runas"
)
if exist c:\users\%username%\desktop\trix (
   powershell remove-item -path "c:\users\%username%\desktop\trix" -recurse -force
)
set /p menu=<c:\trix_cmd\0\menu.txt
if not exist C:\trix_cmd (
   echo mova a pasta trix_cmd, com todos os arquivos para o diretório C para que ela funcione!
   xcopy "c:\users\%username%\downloads\trix_cmd" "c:\trix_cmd" /E /I /H /Y
   powershell remove-item -path c:\users\%username%\downloads\trix_cmd -recurse -force
)
if exist "c:\users\%username%\downloads\trix_cmd" (
   xcopy "c:\users\%username%\downloads\trix_cmd" "c:\trix_cmd" /E /I /H /Y
   powershell remove-item -path "C:\users\%username%\downloads\trix_cmd" -recurse -force
)
if not exist C:\trix_cmd\cache (
   mkdir C:\trix_cmd\cache 
)
:tin
set /p nome=<c:\users\%username%\dados\nome\nome.txt
set /p v=<c:\trix_cmd\versao\versao.txt
if exist "C:\users\%username%\dados\nome\nome.txt" (
   cls
   echo          ============================
   echo          BEM VINDO %nome% A VERSÃO %v%
   echo          ============================
   echo          Trix: a minha versão melhorada!
   echo.
   echo          pressione qualquer tecla para continuar e verificar se a trix está com todos os arquivos
   pause >nul
   echo verificando arquivos...
   goto verificacao
)

:verificacao
set /p nome=<c:\users\%username%\dados\nome\nome.txt
echo criando base de dados...
mkdir C:\trix_cmd\versao
mkdir c:\users\%username%\dados\config
mkdir C:\users\%username%\dados\config\sprotecao
mkdir C:\users\%username%\dados\nome
mkdir c:\users\%username%\dados\pers
mkdir C:\users\%username%\dados\secretos
mkdir c:\users\%username%\dados\status
mkdir c:\users\%username%\dados\status\limpeza-automatica
mkdir c:\trix_conquistas
mkdir C:\trix_cmd\dicas
mkdir C:\trix_cmd\dicas\cache
:voltar
cls
echo atalho ativado > c:\users\%username%\dados\pers\atalho-ativo.txt

if not exist "C:\users\%username%\dados\nome\nome.txt" goto bmv
if exist "C:\users\%username%\dados\nome\nome.txt" goto menu_inicial

:continue
echo > "C:\user\%username%\dados\nome\nome.txt"

fir /x "C:\trix_cmd\0\ 0instalador.bat || echo ocorreu um erro! %% pause"
cls
if exist C:\users\%username%\dados\nome\nome.txt (
    set /p nome=<nome.txt
    if not defined nome (
        goto boas_vindas
    )
    goto menu_inicial
) else (
    goto boas_vindas
)

:at
@echo off
cls
echo ===================================
echo tutorial rápido.
echo para selecionar opções, digite o 
echo número da caixa ao lado da opção
echo.
echo exemplo: [1] opção 1
echo.
echo o número 1 deve ser digitado para
echo selecionar, e depois enter para executar
echo o mesmo vale para opções com letras 
echo como essa opção.
echo algumas opções mais antigas não terão
echo essa dica
echo.
echo [C] confirmar
echo pressione C para finalizar tutorial
set /p "conf=>"
if /i "%conf%"=="c" (
   echo sucesso!
   timeout /t 2 >nul
   goto bmv
)
echo opa, opção inválida, tente novamente!
goto at

:bmv
if exist c:\users\%username%\dados\nome\nome.txt (
   goto menu_inicial
)
cls
echo ao iniciar os serviços você concorda com as
echo políticas de privacidade
echo ================BEM VINDO!==========================
echo Trix: Estamos quase terminado as configurações.
echo Trix: Qual é o seu nome?
echo [clique 1 para ver políticas de privacidade]
echo ====================================================
set /p nome=Escreva como gostaria de ser chamado(a): 
if "%nome%"=="1" (
   echo abrindo termos... 
   start "" "C:\trix_cmd\3\termos.pdf"
   cls 
   goto bmv
)
if "%nome%"=="" (
    echo Trix: O nome será definido como usuário
   echo usuário > "C:\user\%username%\dados\nome\nome.txt"
    timeout /t 2 >nul
    goto bmv
)
if /i "%nome%"=="airii" goto airii

echo Nome salvo: %nome%
echo %nome% > "C:\users\%username%\dados\nome\nome.txt"
timeout /t 2 >nul
goto menu_inicial

:airii
echo olá, seja bem vindo! opções adicionais ativadas! 

echo [ari] opção especial >="C:\users\%username%\dados\secretos\airi.txt
mkdir C:\trix_conquistas
echo seja amigo e software tester de J >="C:\trix_conquistas\[MELHOR_AMIGO].txt"
pause
goto menu_inicial

:menu_inicial
echo %nome% > %userprofile%\dados\nome\nome.txt
echo nome definido!
timeout /t 2 >nul
cls
echo nome salvo: %nome%.
echo %nome%, você poderá muda-lo no menu se não gostar do nome
timeout /t 5 >nul
ping -n 1 8.8.8.8 
if errorlevel 1 (
   goto atua
   echo [sem conexão com internet]
) else (
   echo verificando atualizações...
   goto atua2
)
:atua
cls
echo verificando versão....
echo versão mais atual sendo usada.
echo deseja procurar uma atualização agora?
echo [1] procurar depois
echo [2] procurar agora
echo [3] atualizar automaticamente na sexta-feira
set /p atua=">"
if "%atua%"=="1" (
   echo iremos adiar essa opção...
   %menu%
)
if "%atua%"=="2" (
   echo procurando atualizações 
   goto atua2
)
if "%atua%"=="3" (
   echo 1 > c:\users\%username%\dados\status\atualizacao.txt
   schtasks /create /tn "atualizacao_automatica.bat" /tr "c:\trix_cmd\5\atualizacao_automatica.bat" /sc weekly /d FRI /f
   goto atua2
)
echo opção inválida!
goto atua

:atua2
if not exist %userprofile%\dados\final.txt (
   echo aviso > %userprofile%\dados\final.txt
)
:aviso
echo Trix: olá %nome%, já iremos iniciar o menu normal, mas antes tenho que dar alguns avisos!
timeout /t 5 >nul
color 04
cls
echo                 =======================================================
echo                 AVISO:! %nome%, o windows defender pode barrar a trix 
echo                 pois ela contém comandos de limpeza como "del/temp" 
echo                 e outros que limpam pastas com arquivos temporários 
echo                 de registro o que causa gigas de arquivos inúteis.
echo                 a trix também tem arquivos com comandos que exigem 
echo                 privilégios de administrador para serem executados, 
echo                 então é recomendado executa-la como administrador 
echo                 para evitar possiveis falhas. 
echo.
echo                 após seguir todos os passos corretamente, você terá 
echo                 acesso também aos privilégios de administrador pois 
echo                 a trix executa um comando para promover você %nome% 
echo                 para administrador.
echo                 tenha um bom uso da trix e dos serviços trx!
echo.                
echo                 adicionando %nome% aos privilégios de adm...
echo                 =======================================================
echo.                
echo               [pressione qualquer tecla para ir para o menu]
pause >nul
powershell start c:\trix_cmd\5\atualizacao_automatica.bat
exit

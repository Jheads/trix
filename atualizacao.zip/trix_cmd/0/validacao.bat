@echo off 
chcp 65001
cls
set /p nome=<c:\users\%username%\dados\nome\nome.txt
mkdir c:\users\%username%\dados\config 
mkdir C:\users\%username%\dados\config\sprotecao 
mkdir C:\users\%username%\dados\nome
mkdir c:\users\%username%\dados\pers
mkdir C:\users\%username%\dados\secretos 
mkdir c:\users\%username%\dados\status 
mkdir c:\users\%username%\dados\status\limpeza-automatica 

if exist "c:\users\%username%\downloads\trix_cmd" (
   powershell remove-item -path "C:\users\%username%\downloads\trix_cmd" -reurse -force
)
if not exist C:\trix_cmd (
   echo mova a pasta trix_cmd, com todos os arquivos para o diretório C para que ela funcione!
   xcopy "c:\users\%username%\downloads\trix_cmd" "c:\trix_cmd" /E /I /H /Y
   powershell remove-item -path c:\users\%username%\downloads\trix_cmd -recurse -force
)

start c:\trix_cmd\0\0instalador.bat
exit
﻿@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
:pesquisa
set /p menu=<C:\trix_Cmd\0\menu.txt
@echo off
cls
set "pasta=C:\trix_cmd\biblioteca"
echo escreva "/help" se precisar de ajuda
echo [x] voltar ao menu
set /p filtro="Digite letra ou palavra para procurar: "
set contador=1

if /i "%filtro%"=="/help" goto help
if /i "%filtro%"=="x" goto menu
:: Lista arquivos filtrados e numera
for /f "delims=" %%f in ('dir /b "%pasta%\*.txt" ^| findstr /i "%filtro%"') do (
    echo [!contador!] %%~nf
    set "arquivo[!contador!]=%%f"
    set /a contador+=1
)

:: Se não encontrou nenhum arquivo
if %contador%==1 (
    echo Nenhum arquivo encontrado com "%filtro%"
    timeout /t 2 >nul
    goto pesquisa
)

:: Pede para o usuário escolher o número
set /p escolha="Escolha o numero do arquivo: "

:: Lê o arquivo correspondente e coloca em uma variável

set "arquivoEscolhido=!arquivo[%escolha%]!"
set "arquivocaminho=c:\trix_cmd\biblioteca\!arquivo[%escolha%]!"
set /p arquiv=<c:\trix_cmd\biblioteca\!arquivo[%escolha%]!

if exist "!arquivocaminho!" (
    set /p conteudo=<"!arquivoEscolhido!"
    echo indo ao destino...
    timeout /t 2 >nul
    call %arquiv%
) else (
    echo Numero invalido ou arquivo nao encontrado
    timeout /t 2 >nul
)
goto pesquisa
:help
cls
echo =============================================
echo                 AJUDA
ECHO =============================================
echo pesquise o nome da opção ou a letra de inicio
echo.
echo                   MENU
echo.
echo para voltar ao menu escreva menu
echo.
echo escreva T para ver todos as opções,
echo.
echo opção em desenvolvimento, poderá haver bugs
echo.
echo   [pressione qualquer tecla para voltar]
pause >nul
goto pesquisa

:menu
%menu%
exit
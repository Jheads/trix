@echo off
cls
chcp 65001
@echo off
cls
:menu
mkdir C:\at
mkdir C:\backup
robocopy "C:\trix_cmd" "C:\backup\trix_cmd" /E /COPYALL /R:0 /W:0
echo iniciando reinicialização
set setup=C:\trix_cmd\setup.cmd
set pasta=C:\at
set "destino=%pasta%\atualizacao.zip "
set "link=https://github.com/joaoPHD/trix/raw/main/atualizacao.zip"
curl -L -o "%destino%" "%link%"
tar -xf %destino% -C C:\at
if errorlevel 1 (
    echo erro ao extrair, abortando
    powershell remove-item C:\at -recurse -force
    powershell remove-item C:\atualizacao.zip -recurse -force
    start C:\trix_cmd\0\0_menu.bat
    powershell remove-item %userprofile%\recupera.bat
    exit
) else (
    echo sucesso na extração. verificando integridade dos pacotes...
    if exist C:\at\trix_cmd (
        powershell remove-item C:\trix_cmd -recurse -force
        schtasks /delete /tn "limpezaauto"
        schtasks /delete /tn "TornExplorer"
        schtasks /delete /tn "torn-Protecao"
        robocopy "C:\at\trix_cmd" "C:\trix_cmd" /E /COPYALL /R:0 /W:0
        if exist C:\trix_cmd\* (
            taskkill /f /im explorer.exe & start explorer.exe
            powershell remove-item C:\at -recurse -force
            powershell remove-item %userprofile%\recupera.bat
            msg "*" "sucesso!"
            call %setup%
        ) else (
            msg "*" "AVISO: erro critico de integridade, por favor faça a intalação dos sistemas manualmente"
            start https://github.com/joaoPHD/trix/raw/main/atualizacao.zip
            start %userprofile%\Downloads
            exit
        )
    )
)
msg "*" "erro desconhecido"
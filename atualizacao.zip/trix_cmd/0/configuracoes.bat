@echo off
chcp 65001
@echo off
for /F %%a in ('"prompt $E & for %%b in (1) do rem"') do set "ESC=%%a"
set rd=%%ESC%%[31m
set nl=%%ESC%%[30m
set gr=%%ESC%%[32m
set yw=%%ESC%%[33m
set bl=%%ESC%%[34m
set pl=%%ESC%%[35m
set ci=%%ESC%%[36m
set we=%%ESC%%[37m
set sd=%%ESC%%[0m
set cl=%bl%
set cor=C:\users\%username%\dados\pers\cor.txt
set ln=%gr%
set linha=C:\users\%username%\dados\pers\lin.txt
if exist %linha% (
   set /p ln=<%linha%
)
set /p menu=<c:\trix_cmd\0\menu.txt
set recuperacao=%userprofile%\recuperacao-trix
 
cls
:inicio
cls
call echo %bl%===============%gr%configurações%bl%============%gr%
call echo [1]%pl% ligar ansi%gr%
call echo [2] %pl%configurar agenda%gr%
call echo [3] %pl%ativar testes (fase beta)%gr%
call echo [4] %pl%configurar exibição de pastas%gr%
if exist C:\users\%username%\dados\status\dn.txt (
   call echo [5] %pl%ativar pergunta do donate %gr%
)
if exist C:\users\%username%\dados\status\ds.txt (
   call echo [5] %pl%desativar pergunta do donate %gr%
)
if not exist C:\users\%username%\dados\status\dn.txt (
   if not exist C:\users\%username%\dados\status\ds.txt (
      call echo [5] %pl%configurar donate%gr% 
   )
)
call echo [6] %pl%mudar nome%gr%
call echo [7]%pl%configurar atalho%gr%
call echo [8]%pl% configurar limpeza%gr%
call echo [9]%pl% configurar tamanho das letras [BETA]
call echo [10]%pl% reiniciar todos os dados%gr%
if not exist C:\trix_cmd\3\chat-biblioteca (
   call echo [11]%pl% baixar e instalar biblioteca do chat%gr%[BETA]
) else (
   call echo [11]%pl% remover e desinstalar biblioteca do chat%gr%
)
call echo [12]%pl% modificar tempo limite de animações
call echo %rd%[x] %pl%voltar%gr%
call echo programa em fase beta, algumas opções podem não estar diponiveis%bl%
call echo ===================beta=================%yw%
set /p "opt=Escolha uma opção: "

if "%opt%"=="1" goto ansi & cls
if "%opt%"=="2" goto agenda & cls
if "%opt%"=="3" goto ativar & cls
if /i "%opt%"=="x" goto voltar
if "%opt%"=="4" goto pastas
if "%opt%"=="5" goto donate
if "%opt%"=="6" goto nome
if "%opt%"=="7" goto atalho
if "%opt%"=="8" goto limpeza
if "%opt%"=="9" goto fontes
if "%opt%"=="10" goto dados
if "%opt%"=="11" goto chat
if "%opt%"=="12" goto limite
echo Opção inválida, tente novamente 
timeout /t 2 >nul
cls
goto inicio

:limite
cls
echo ====================================================
echo deseja modificar tempo limite da animação do menu?
if exist C:\trix_cmd\3\timeout.txt (
   echo [r] reiniciar para tempo padrão
)
echo [1] sim 
echo [2] não, voltar
echo ====================================================
set /p "opt=> "
if "%opt%"=="1" goto menu-anim
if "%opt%"=="2" goto inicio
if /i "%opt%"=="r" goto reini-anim
echo opção inválida, tente novamente
timeout /t 2 >nul
goto limite
:reini-anim
cls
if exist C:\trix_cmd\3\timeout.txt (
   powershell remove-item C:\trix_cmd\3\timeout.txt
) else (
   echo opção inválida, tente novamente
   timeout /t 2 >nul
   goto limite 
)
goto limite

:menu-anim
cls
set /p "tempo=defina o tempo de intervalo: "
echo %tempo%| findstr /r "^[0-9][0-9]*$*" >nul || (
     echo opção inválida apenas números são aceitos
     timeout /t 2 >nul
     goto menu-anim
)
echo %tempo% > C:\trix_cmd\3\timeout.txt
echo o tempo será de %tempo% segundos
timeout /t 2 >nul
goto limite

:chat
if not exist C:\trix_cmd\3\chat-biblioteca (
   mkdir C:\trix_cmd\3\chat-biblioteca
   echo 1 > %userprofile%\dados\status\chat.txt
   curl -L "https://github.com/Jheads/trix/raw/refs/heads/main/chat-instalador.bat" -o "C:\trix_cmd\3\chat-instalador.bat"
   echo exit >> C:\trix_cmd\3\chat-instalador.bat
   echo > %userprofile%\dados\status\chat.txt
   start C:\trix_cmd\3\chat-instalador.bat
   timeout /t 6 >nul
   powershell remove-item C:\trix_cmd\3\chat-instalador.bat -recurse -force
   msg "*" "download concluido, chat beta está disponivel para testes"
) else (
   powershell remove-item C:\trix_cmd\3\chat-biblioteca -recurse -force
   powershell remove-item C:\trix_cmd\3\chat-instalador.bat -recurse -force
   powershell remove-item %userprofile%\dados\status\chat.txt
)
goto inicio

:dados
echo AVISO: só use essa opção em casos críticos do sistema, pois ele reiniciará
echo tudo que está salvo pelo usuário.
echo ele reiniciara:
echo conquistas
echo dados salvos
echo tarefas automaticas
echo cache
echo arquivos antigos
echo modificações feitas na raiz do windows não serão desfeitas por limite dos
echo do sistema. 
echo após reiniciar dados o sistema se atualizará, certifique-se de ter internet
echo para não quebrar o sistema
echo     [PRESSIONE QUALQUER TECLA PARA CONTINUAR]
pause >nul
cls
ping -n 1 8.8.8.8 >nul
if errorlevel 1 (
   echo erro de conexão
   echo abortando reinicialização
   timeout /t 2 >nul 
   goto menu
) else (
   echo internet validada, iniciando reinicialização, por favor não feche essa janela ou desligue a internet
)
:dadosreset
copy C:\trix_cmd\0\recupera.bat %userprofile%
if not exist %userprofile%\recupera.bat goto dadosreset
powershell start %userprofile%\recupera.bat

:fontes
call C:\trix_cmd\7\fonte.bat
goto menu

:limpeza
call c:\trix_cmd\2\preferencias.bat
goto menu

:atalho
call C:\trix_Cmd\4\4trix-atalho.bat
goto menu

:nome
call c:\trix_cmd\0\nome.bat
goto menu

:donate
if exist C:\users\%username%\dados\status\dn.txt (
   echo ativando pergunta do donate
   powershell remove-item C:\users\%username%\dados\status\dn.txt -recurse -force
   tiemout /t 2 >nul 
   goto inicio
)
if exist C:\users\%username%\dados\status\ds.txt (
   call echo desativando pergunta do donate
   powershell remove-item C:\users\%username%\dados\status\ds.txt -recurse -force
   timeout /t 2 >nul
   goto inicio
)
echo sem configurações
timeout /t 2 >nul
goto inicio

:voltar
echo Voltando...
timeout /t 5 >nul
%menu%
exit
goto inicio

:agenda
cls
echo disponivel na proxima atualização
timeout /t 3 >nul
pause
cls
goto inicio

:ativar
color 2
cls
set "ativar=C:\users\%username%\dados\pers\ativar.txt"
if not exist "%ativar%" echo ativado > "%ativar%"
set /p "mode=" < "%ativar%"
echo [trx]desenvolvedor > "%ativar%"
call echo %gr% para acessar os testes digite trx no menu. As opções de teses podem ser massivas e agressivas para seu computador, use com sua conta em risco.
timeout /t 2 >nul
pause
cls
goto inicio

:ansi
cls
call echo%gr% suporte ativado a partir da 21.0, alguns windwos podem não suportar diretamente o anscii
timeout /t 2 >nul
pause
cls
goto inicio

:agenda
cls
echo fora de serviços por enquanto...
timeout /t 2 >nul
pause
cls
goto inicio

:pastas
cls
echo ==========================================
if exist c:\users\%username%\dados\status\pasta.txt (
   call echo ocultar configurações das pastas do sistema?
   ) else (
   call echo mostrar configurações do sistema?
)
call echo [1] mudar
call echo [x] voltar 
set /p "opcc=>"
if "%opcc%"=="1" (
   if exist c:\users\%username%\dados\status\pasta.txt (
      powershell remove-item c:\users\%username%\dados\status\pasta.txt -recurse -force
      echo as pastas desaparecerão agora
      timeout /t 2 >nul
      ) else (
      echo > c:\users\%username%\dados\status\pasta.txt 
      echo as pastas aparecerão agora
      timeout /t 2 >Nul
   )
   goto pastas
)
if /i "%opcc%"=="x" goto inicio

cls
pause
exit
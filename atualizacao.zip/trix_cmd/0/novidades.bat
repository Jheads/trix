﻿ (
    @echo off
 )
chcp 65001
set /p v=<c:\trix_cmd\versao\versao.txt
set /p nome=<c:\users\%username%\dados\nome\nome.txt
set /p novidades=<C:\trix_cmd\3\infos-da-versao.txt
set /p menu=<"c:\trix_cmd\0\menu.txt"
 
color 4

cls
echo          ========================
echo          novidades da %v%
echo          ========================
ECHO          %novidades%
echo         [pressione qualquer tecla para voltar ao menu]
pause >nul
cls
%menu%
exit
cls

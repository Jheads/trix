@echo off
chcp 65001
set nome=<c:\users\%username%\dados\nome\nome.txt
   
set /p menu=<c:\trix_cmd\0\menu.txt
if not exist "%ativar%" echo ativado > "%ativar%"
 
cls
:menu
ECHO ======================
echo ========AVISO=========
ECHO ======================
echo esses testes não foram e nem vão ser lançados, alguns testes são 
echo agressivos e massivos para o computadores. tudo vai ser questão de sorte, exemplo:
echo %g% %nome% terá seu computador corrompido ou irá conseguir uma performance maior 
echo que a normal. 
echo.
echo se for usar os testes, use-os com sua conta e computador em risco, se não tiver 
echo nenhum arquivo realmente importante no computador, use-os a vontade.
echo.
pause
cls
echo =========================================================================
echo esses arquivos estão classificados como arquivos que podem causar o código 
echo 1- cpd
echo critical process died 
echo 2 -ibd
echo inaccessible boot device
echo 3- 0x80070057
echo falhas na memória
echo 4- 0xc0000005
echo falhas no disco
echo 5- BSOD
echo tela azul (falha crítica no sistema)
echo não se preocupe, esses processos não funcionam em segundo plano,
echo não puxam bateria e nem memória, não mexa neles se não souber o que está fazendo.
tiemout /t 30 >nul
pause

:menu0
cls
echo ==========testes================
echo alto nivel de perigo
echo.
echo [1] limpeza profunda
echo info: alto risco de tela azul e corrupção do HD ou SDD, se tiver sorte liberará mais de 20 gb
echo [2] limpeza rápida
echo info: alto risco de corrupção de driver e armazenamento
echo.
echo baixo nivel de perigo 
echo [3] aviso 
echo info: não afeta nada em seu computador, mas se executado várias vezes pode causar lentidão
echo [4] animação 
echo info: animação infinita, não da pra sair dela sem fechar a trix
echo [5] animação 2
echo [6] chat fase beta
echo info: planta do chat da trix
echo [7] hora e nome
echo info: parou de funcionar na última atualização
echo [8] voltar 
echo =================================
echo algumas opções não estão funcionando ou não estão disponíveis
set /p "opc=escolha uma opção: "

if "%opc%"=="1" call C:\trix_cmd\testes\CPD\limpeza-profunda.bat
if "%opc%"=="2" echo ação bloqueada por motivos de segurança
if "%opc%"=="3" call C:\trix_cmd\testes\sucessos\.2.bat
if "%opc%"=="4" call C:\trix_cmd\testes\sucessos\car.bat
if "%opc%"=="5" call C:\trix_cmd\testes\sucessos\anima.bat
if "%opc%"=="6" call C:\trix_cmd\testes\sucessos\chat_teste.bat
if "%opc%"=="7" call C:\trix_cmd\testes\sucessos\hn.bat
if "%opc%"=="8" %menu%
echo opção inválida, tente novamente!
timeout /t 2 >nul
cls
goto menu0
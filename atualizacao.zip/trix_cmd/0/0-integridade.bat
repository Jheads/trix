@echo off
chcp 65001 >nul
:delta
@echo off
cls 
net session >nul 2>&1
if %errorlevel% neq 0 (
   :: Se não estiver elevado, solicita admin oculto
   powershell -Command "Start-Process cmd -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs -WindowStyle Hidden"
   exit
)
echo [=====================esperando confirmação===========================]
echo > C:\trix_cmd\cache\anim.txt
start "" "C:\trix_cmd\0\animacao.bat"
if errorlevel 1 (
   echo erro 3: desculpe-nos, ocorreu algum erro.
   timeout /t 2 >nul
   start "" "C:\trix_cmd\0\animacao.bat"
)
echo [=====================modificando pastas==========================]
if not exist %userprofile%\dados\status\chat.txt (
   powershell remove-item C:\trix_cmd\3\chat-instalador.bat -recurse -force
   powershell remove-item C:\trix_cmd\3\chat-biblioteca -recurse -force
)
if exist C:\users\%username%\dados\status\aviso.txt (
   if not exist %userprofile%\dados\final.txt (
      powershell remove-item C:\users\%username%\dados\status\aviso.txt -recurse -force
      goto delta
      powershell -Command "Start-Process C:\trix_cmd\0\temp.vbs"
   ) else (
      goto menu 
   )
)
echo 1 > c:\users\%username%\dados\status\aviso.txt
echo criação do aviso
if exist %userprofile%\dados\nome\*.txt (
   set /p nome=<%userprofile%\dados\nome\*.txt
) else (
   set nome=usuário
)
cls
:menu
@echo off
chcp 65001 >nul
color 8
:attt
@echo off
echo I======================================================================================================================I
echo                                             CARREGANDO ARQUIVOS....
echo I======================================================================================================================I
if exist c:\trix_cmd\copyright (
   attrib -h "c:\trix_cmd\copyright"
)
if exist c:\trix_cmd\copyright\*.txt (
   attrib +h "c:\trix_cmd\copyright\*.txt"
)
if exist c:\users\%username%\dados\status\pasta.txt (
   attrib -h "C:\trix_cmd\*" /d
   ) else (
   attrib +h "c:\trix_cmd\*" /d
)
attrib +h "C:\trix_cmd\8\*.txt"
attrib -h "c:\trix_cmd\setup.cmd"
if exist c:\trix_cmd\platform-tools (
   set adb=c:\trix_cmd\platform-tools
   attrib -h "c:\trix_cmd\platform-tools" /d
)
if exist C:\backup-trix powershell remove-item C:\backup-trix -recurse -force
if exist c:\users\%username%\dados\pers\atalho-desativo.txt (
   setlocal
   xcopy "%atalho%" "%APPDATA%\Microsoft\Windows\start Menu\Programs" /Y
   attrib +h "%atalho%"
)
if exist c:\users\%username%\dados\pers\atalho-ativo.txt (
   setlocal
   attrib -h "%atalho%"
)
if not exist C:\trix_cmd\dicas\cache (
   mkdir C:\trix_cmd\dicas\cache
)

echo [===================echo definindo váriaveis========================]
::definindo todas as variaveis normais
set /p menu=<c:\trix_cmd\0\menu.txt
set vs=alpha
set /p vss=<c:\trix_cmd\variavel\vs.txt
set deletador=c:\trix_cmd\5\deletador.bat
set adbc=platform-tools
set /p novo=<c:\trix_cmd\3\novo.txt
set skip=c:\users\%username%\dados\pers\skip.txt
set escuro=c:\users\%username%\dados\pers\escuro.txt
set branco=c:\users\%username%\dados\pers\branco.txt
set cor=c:\users\%username%\dados\pers\cor.txt
set /p cor1=<c:\users\%username%\dados\pers\cor.txt
set /p menu=<C:\trix_cmd\0\menu.txt
set /p opcao=<c:\users\%username%\dados\pers\opcao.txt
set /p lims=<c:\users\%username%\dados\status\limpeza-automatica\vers.txt
set /p limc=<c:\users\%username%\dados\status\limpeza-automatica\varc.txt
set airii=c:\users\%username%\dados\secretos\airii.txt
set /p ari=<c:\users\%username%\dados\secretos\airii.txt
set rr=c:\users\%username%\dados\secretos\[r].txt
set aa=c:\users\%username%\dados\secretos\[A].txt
set ativa=C:\users\%username%\dados\pers\ativar.txt
set /p ativar=<C:\users\%username%\dados\pers\ativar.txt
set /p v=<c:\trix_cmd\versao\versao.txt
set /p torn=<c:\users\%username%\dados\torn\torn.txt
set caminho-torn=%USERPROFILE%\dados\torn\torn.txt
set "statusFile=C:\Users\%USERNAME%\dados\status\status.txt"
set "shortcutName=trix.lnk"
set "desktop=%USERPROFILE%\Desktop"
set "targetPath=%menu%"
set "statusFolder=C:\Users\%USERNAME%\dados\status"
set "lockFile=%statusFolder%\script.lock"
set "atalho=%userprofile%\desktop\trix.lnk"
set /p v1=<c:\trix_cmd\versao\versao.txt
set extensoes=C:\trix_Cmd\9\biblioteca-extensoes
set windows=C:\trix_Cmd\9\biblioteca-windows
set biblioteca=C:\trix_cmd\biblioteca
set jogos=C:\trix_cmd\biblioteca-jogos
set defesa=C:\trix_cmd\defesa
set status-extensoes=%userprofile%\dados\status\extensoes.txt
set status-windows=%userprofile%\dados\status\windows.txt
set status-lupa=%userprofile%\dados\status\lupa.txt
set status-jogos=%userprofile%\dados\status\jogos.txt
set status-defesa=%userprofile%\dados\status\defesa.txt
set dicas-pasta=C:\trix_cmd\dicas
set /p MAX=<C:\trix_cmd\3\MAX.txt
echo [=======================váriveis especiais============================]
::adicionando versão nas dicas
echo versão atual:%v1% > C:\trix_cmd\dicas\1.txt
::definindo nome do usuario
if exist "C:\users\%username%\dados\nome\nome.txt" (
   set /p nome=<%userprofile%\dados\nome\nome.txt
   ) else (
   set nome=usuário
)
if exist "C:\users\%username%\dados\nome\nome.txt" set /p nome=<%userprofile%\dados\nome\nome.txt

::verificando e definindo a vigia
if exist %userprofile%\dados\status\vigia.txt (
   set vigia=%userprofile%\dados\status\vigia.txt
) 
::definindo scrcpy
if exist c:\trix_cmd\scrcpy-win64-v%vs% (
   set scpyc=c:\trix_cmd\scrcpy-win64-v%vs%
   set scpy=scrcpy-win64-v%vs%
)
if exist c:\trix_cmd\scrcpy-win32-v%vs% (
   set scpyc=c:\trix_cmd\scrcpy-win32-v%vs%
   set scpy=scrcpy-win32-v%vs%
)
set scpyc=c:\trix_cmd\scrcpy-win%vss%-v%vs%
::conquistas
if exist c:\trix_conquistas\[R].txt (
   if not exist c:\users\%username%\dados\secretos\[r].txt (
      echo [R] congratulations > c:\users\%username%\dados\secretos\[r].txt
   )
   echo [R] congratulations > c:\users\%username%\dados\secretos\[r].txt
   set /p r=<c:\users\%username%\dados\secretos\[r].txt
)
if exist c:\trix_conquistas\[MELHOR_AMIGO].txt (
   echo airii > c:\users\%username%\dados\secretos\airii.txt
   set airii=c:\users\%username%\dados\secretos\airii.txt
   powershell remove-item -path c:\users\%username%\dados\secretos\airii.txt -recurse -force
   echo "[Ari] opção secreta > c:\users\%username%\dados\secretos\airii.txt"
   set /p ari =< c:\users\%username%\dados\secretos\airii.txt
)
::definindo dicas do menu
if exist %dicas-pasta% (
   goto dicas
) else (
   mkdir %dicas-pasta%
)
:dicas
set /a SORTE=(%RANDOM% %% MAX) + 1
set /p DICAS=<"%dicas-pasta%\%SORTE%.txt"
echo %sorte%
echo %dicas%
setlocal enabledelayedexpansion
for /F %%a in ('"prompt $E & for %%b in (1) do rem"') do set "ESC=%%a"

:: Pegando a hora atual sem os minutos
for /F "tokens=1 delims=:" %%H in ("%TIME%") do set hora=%%H

:: Removendo espaços extras
set hora=%hora: =%

:: Convertendo a hora para número
set /A hora+=0 2>nul
:: Definindo a mensagem baseada no horário
set msg=uma Boa noite!
if %hora% GEQ 5 if %hora% LSS 12 set msg=um Bom dia!
if %hora% GEQ 12 if %hora% LSS 18 set msg=uma Boa tarde!
::definindo cores do menu
set rd=%%ESC%%[31m
set nl=%%ESC%%[30m
set gr=%%ESC%%[32m
set yw=%%ESC%%[33m
set bl=%%ESC%%[34m
set pl=%%ESC%%[35m
set ci=%%ESC%%[36m
set we=%%ESC%%[37m
set sd=%%ESC%%[0m
set cl=%pl%
set c11=%userprofile%\dados\pers\cor\cl
set ln=%gr%
if exist %c11%\rd.txt (
   set cl=%rd%
)
if exist %c11%\nl.txt (
   set cl=%nl%
)
if exist %c11%\gr.txt (
   set cl=%gr%
)
if exist %c11%\yw.txt (
   set cl=%yw%
)
if exist %c11%\bl.txt (
   set cl=%bl%
)
if exist %c11%\pl.txt (
   set cl=%pl%
)
if exist %c11%\ci.txt (
   set cl=%ci%
)
if exist %c11%\we.txt (
   set cl=%we%
)
if exist %c11%\sd.txt (
   set cl=%sd%
)
set L11=%userprofile%\dados\pers\cor\ln
if exist %L11%\rd.txt (
   set ln=%rd%
)
if exist %l11%\nl.txt (
   set ln=%nl%
)
if exist %l11%\gr.txt (
   set ln=%gr%
)
if exist %l11%\yw.txt (
   set ln=%yw%
)
if exist %l11%\bl.txt (
   set ln=%bl%
)
if exist %l11%\pl.txt (
   set ln=%pl%
)
if exist %l11%\ci.txt (
   set ln=%ci%
)
if exist %l11%\we.txt (
   set ln=%we%
)
if exist %l11%\sd.txt (
   set ln=%sd%
)

echo [====================personalização===============================]

echo > c:\trix_cmd\0\fontes.txt
powershell remove-item -path C:\trix_cmd\0\fontes.txt -recurse -force

echo [====================integridade==================================]

if exist %status-windows% powershell remove-item %windows% -recurse -force
if exist %status-extensoes% powershell remove-item %extensoes% -recurse -force
if exist %status-lupa% powershell remove-item %biblioteca% -recurse -force
if exist %status-jogos% powershell remove-item %jogos% -recurse -force
if exist %status-defesa% powershell remove-item %defesa% -recurse -force

attrib -h "c:\trix_cmd\scrcpy-win64-v%vs%" 
attrib -h "c:\trix_cmd\scrcpy-win32-v%vs%"

if not exist %userprofile%\dados\status\chat.txt (
   if exist C:\trix_cmd\3\chat-biblioteca (
      powershell remove-item C:\trix_cmd\3\chat-biblioteca -recurse -force
   )
)

if exist c:\trix_cmd\instalar-trix (
   takeown /f "c:\trix_cmd\instalar-trix" /r /d y
   icacls "c:\trix_cmd\instalar-trix" /grant "%username%:F" /t
   powershell remove-item -path c:\trix_cmd\instalar-trix -recurse -force
)

:: verificação do torn
if not exist c:\users\%username%\dados\pers\atalho-ativo.txt (
   if not exist c:\users\%username%\dados\pers\atalho-desativo.txt (
      if not exist c:\users\%username%\dados\pers (
         msg "*" "PERSONALIZAÇÕES ESTÁ VAZIA, RECRIANDO ATALHO"
         mkdir c:\users\%username%\dados\pers
         echo Torn corrigu arquivos corrompidos as %hora% horas > %caminho-torn%
      )
      msg "*" "TORN DETECTOU QUE ARQUIVOS DO ATALHO ESTÃO EM FALTA"
      if not exist C:\trix_cmd\cache\atalho-erro.txt (
         echo ==============================================
         echo                 ERRO
         echo ==============================================
         echo > %userprofile%\dados\pers\atalho-ativo.txt
         echo > C:\trix_cmd\cache\atalho-erro.txt
         if errorlevel 1 (
            call c:\trix_cmd\0\0-integridade.bat
         ) else (
            msg "*" "erro corrigido, atalho reiniciado. mude as configurações se desejar"
            echo Torn corrigiu um erro de atalho as %hora% horas > %caminho-torn%
            %menu% 
            exit
         )
      ) else (
         msg "*" "não foi possivel corrigir o erro. forçando criação..."
         echo torn forçou criação de atalho as %hora% horas > %caminho-torn%
         echo > c:\users\%username%\dados\pers\atalho-ativo.txt
         if exist c:\users\%username%\dados\pers\atalho-ativo.txt (
            msg "*" "sucesso ao corrigir erros!"
         )
         %menu%
      )
   )
)
if exist c:\trix_cmd\atualizacao.zip (
   echo att > c:\users\%username%\dados\status\att.txt
   msg "*" "atualização detectada"
   powershell start c:\trix_cmd\5\atualizacao_automatica.bat
   exit
)

if exist c:\trix_conquistas\[MELHOR_AMIGO].txt (
   echo airii > c:\users\%username%\dados\secretos\airii.txt
   powershell remove-item -path c:\users\%username%\dados\secretos\airii.txt -recurse -force
)

:re-verificar-versao
if not exist "c:\trix_cmd\versao\%v%.txt" (
   powershell remove-item C:\trix_cmd\versao\%v%.txt -recurse -force
   echo %v%> "C:\trix_cmd\versao\%v%.txt"
   echo %v%
   msg "*" "TORN DETECTOU UM ERRO: versão quebrada, corrigindo variavel..."
   echo Torn corrigiu um erro de váriavel as %hora% horas > %caminho-torn%
   goto re-verificar-versao
) else (
   echo ====================================================================
   echo                   versão saudavel 
   echo ====================================================================
)
setlocal enabledelayedexpansion

if not exist c:\users\%username%\dados\atualizacao (
   mkdir c:\users\%username%\dados\atualizacao
)

echo [==============adicionando usuário aos administradores====================]
net localgroup administrators %USERNAME% /add
net localgroup administradores %USERNAME% /add

echo [==========================criando atalho============================]
@echo off

set "TXT=C:\trix_cmd\3\atalho.txt"
set "ICON=C:\trix_cmd\trix.ico"
set "SHORTCUT=%USERPROFILE%\Desktop\Trix.lnk"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
$bytes = [System.IO.File]::ReadAllBytes('%TXT%'); ^
if ($bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191) { $bytes = $bytes[3..($bytes.Length-1)] }; ^
$target = ([System.Text.Encoding]::UTF8.GetString($bytes)).Trim(); ^
$ws = New-Object -ComObject WScript.Shell; ^
$s = $ws.CreateShortcut('%SHORTCUT%'); ^
$s.TargetPath = $target; ^
$s.IconLocation = '%ICON%'; ^
$s.Save()

if not exist %shortcut% (
   msg * "Erro: Ambos os métodos falharam. Não foi possível criar o atalho."
)

set "TXT=C:\trix_cmd\3\torn-atalho.txt"
set "ICON=C:\trix_cmd\torn.ico"
set "SHORTCUT=%USERPROFILE%\Desktop\Torn.lnk"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
$bytes = [System.IO.File]::ReadAllBytes('%TXT%'); ^
if ($bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191) { $bytes = $bytes[3..($bytes.Length-1)] }; ^
$target = ([System.Text.Encoding]::UTF8.GetString($bytes)).Trim(); ^
$ws = New-Object -ComObject WScript.Shell; ^
$s = $ws.CreateShortcut('%SHORTCUT%'); ^
$s.TargetPath = $target; ^
$s.IconLocation = '%ICON%'; ^
$s.Save()

:: Se ambos falharem, exibe mensagem de erro
if not exist %shortcut% (
   msg * "Erro: Ambos os métodos falharam. Não foi possível criar o atalho."
)

:end
:: Limpeza
del "%TEMP%\createShortcut.vbs" > nul 2>&1
del "%TEMP%\CreateShortcut.ps1" > nul 2>&1
del "%lockFile%" > nul 2>&1
:iniciarmenu

echo [============================100===========================================]

title Menu Trix

setlocal enabledelayedexpansion
if not exist "C:\Trix_cmd\" (
    echo O sistema da Trix pode não funcionar corretamente.
    echo Por favor, mova a pasta "Trix_cmd" para o disco C ou o disco principal para que a Trix funcione corretamente.
    echo verifique se a pasta do sistema existe
    attrib -h "c:\trix_cmd\*" /d
    echo [pressione qualquer tecla para sair]
    pause >nul
    exit
)
:volta1
set limss=c:\users\%username%\dados\status\limpeza-automatica\vers.txt
set limcc=c:\users\%username%\dados\status\limpeza-automatica\verc.txt
set /p lims=<c:\users\%username%\dados\status\limpeza-automatica\vers.txt
set /p limc=<c:\users\%username%\dados\status\limpeza-automatica\verc.txt

echo I======================================================================================================================I
echo                                             Arquivos carregados
echo I======================================================================================================================I
echo verificando intergridade dos arquivos...
echo "tenha %msg%, seja bem vindo %nome%, o sistema está iniciando, aguarde :)"

if not exist "c:\users\%username%\dados\atualizacao\%v%.txt" (
   powershell remove-item c:\users\%username%\dados\atualizacao\* -recurse -force
   echo atualizado > "c:\users\%username%\dados\atualizacao\%v%.txt"
   start c:\trix_cmd\5\novidades.bat
   exit
) else (
   if exist %userprofile%\dados\atualizacao\%v% (
      powershell remove-item %userprofile%\dados\atualizacao\%v%
      msg "*" "ERRO FATAL, TORN ESTÁ CORRIGINDO PROBLEMAS DA VERSÃO"
   )
)

if exist c:\users\%username%\dados\status\atualizado.txt (
   powershell remove-item -path "c:\users\%username%\dados\status\atualizado.txt" -recurse -force
)
if not exist C:\trix_Cmd\dicas\*.txt (
   if not exist %userprofile%\dados\dicas-vazia.txt (
      msg "*" "aviso, pasta de dicas vazia. não é um erro grave, mas poderá causar erros de variaveis"
      echo > %userprofile%\dados\dicas-vazia.txt
   )
)

:iniciarmenu
for /F %%a in ('"prompt $E & for %%b in (1) do rem"') do set "ESC=%%a"
if exist c:\users\%username%\dados\status\limpeza-automatica\vers.txt ( 
   set /p lims=<c:\users\%username%\dados\status\limpeza-automatica\vers.txt
)
if exist c:\users\%username%\dados\status\limpeza-automatica\verc.txt (
   set /p limc=<c:\users\%username%\dados\status\limpeza-automatica\verc.txt
)

:menu
@echo off
if not exist C:\trix_cmd\1\*.bat msg "*" "AVISO CRÍTICO: PASTA 1 VAZIA OU CORROMPIDA"
if not exist C:\trix_cmd\2\*.bat msg "*" "AVISO CRÍTICO: PASTA 2 VAZIA OU CORROMPIDA"
if not exist C:\trix_cmd\3\*.bat msg "*" "AVISO CRÍTICO: PASTA 3 VAZIA OU CORROMPIDA"
if not exist C:\trix_cmd\4\*.bat msg "*" "AVISO CRÍTICO: PASTA 4 VAZIA OU CORROMPIDA"
if not exist C:\trix_cmd\5\*.bat msg "*" "AVISO CRÍTICO: PASTA 5 VAZIA OU CORROMPIDA"
if not exist C:\trix_cmd\6\*.bat msg "*" "AVISO CRÍTICO: PASTA 6 VAZIA OU CORROMPIDA"
if not exist C:\trix_cmd\7\*.bat msg "*" "AVISO CRÍTICO: PASTA 7 VAZIA OU CORROMPIDA"
if not exist C:\trix_cmd\8\*.bat msg "*" "AVISO CRÍTICO: PASTA 8 VAZIA OU CORROMPIDA"
if not exist C:\trix_cmd\9\*.bat msg "*" "AVISO CRÍTICO: PASTA 9 VAZIA OU CORROMPIDA"
if not exist C:\trix_cmd\biblioteca\*.txt call echo %rd%AVISO CRÍTICO: BIBLIOTECA VAZIA OU CORROMPIDA%cl%
set > "C:\trix_cmd\cache\var.txt"
powershell remove-item C:\trix_cmd\cache\anim.txt -recurse -force
echo integridade finalizada
timeout /t 2 >nul
exit
﻿@echo off
chcp 65001
setlocal
net session >nul 2>&1
if %errorlevel% neq 0 (
   echo solicitando privilégios de adm...
   powershell -command "start-process cmd -argumentlist '/c \"%~f0\"' -verb runas"
   exit
)
@echo off
for /f "delims=" %%a in (C:\trix_cmd\cache\var.txt) do set "%%a"
powershell remove-item C:\trix_cmd\cache\var.txt -recurse -force
setlocal enabledelayedexpansion
set deletador=c:\trix_cmd\5\deletador.bat
if exist c:\trix_cmd\cache\* start %deletador%
if exist C:\RN.TXT start %deletador%
echo definindo arquivos e iniciando menu
:: define aonde os arquivos estão
set "op1=2\2trix-confirmacao.bat"
set "op2=1\escolha.bat"
set "op3=3\3info.bat"
set "op4=0\automocao.bat"
set "op5=9\extensoes.bat"
set "op6=9\menu.bat"
set "op7=3\chat.bat"
set "op8=9\ativacao.bat"
set "op9=4\loja.bat"
set "op10=0\configuracoes.bat"
set "optrx=0\testes.bat"
set "op11=0\suporte.bat"
set "op12=0\conquistas.bat"
set "opari=6\especial.bat"
set "opa=6\Aespecial.bat"
set "opr=6\respecial.bat"
set "op13=0\aplicativos.bat"
set "op14=0\novidades.bat"
set "op15=2\backup.bat"
set "op16=5\att-menu.bat"
set "op17=7\menu.bat"
set "op18=5\torn-menu.bat"
set "op19=1\menu.bat"
set "opD=8\donate.bat"
set "opad=platform-tools\start.bat"
set "ops=4\chama.bat"
set "oprst=4\server.bat"
set "opp=0\lupa.bat"

:: define o nome dos arquivos
set "nomer=congratulations"
set "nomea=my insides are red"
set "nomead=iniciando adb"
set "nomes=iniciando scrcpy"
set "nome1=limpeza"
set "nome2=menu de otimização"
set "nome3=utilidades"
set "nome4=automoção"
set "nome5=extensoes"
set "nome6=bibliotecas e extensões"
set "nome7=chat"
set "nome8=ativar windows"
set "nome9=Trix store"
set "nome10=configurações"
set "nometrx=desenvolvedor"
set "nome11=suporte"
set "nome12=conquistas"
set "nomeari=hehehe"
set "nome13=aplicativos do sistema"
set "nome14=novidades"
set "nome15=definir backups"
set "nome16=gerenciador de atualizações"
set "nome17=cores"
set "nome18=Torn"
set "nome19=avaliação de desempenho"
set "nomerm=reiniciar menu"
set "nomerst=reiniciando servidor..."
set "nomep=abrindo pesquisa"
set "nomeD=cafeteria"
cls
if exist c:\users\%username%\dados\pers\atalho-desativo.txt call echo                    %gr% [=Trix está localizada na lista de aplicativos do menu inicial=]
call echo %cl%I================================================ %gr% MENU TRIX %cl% =========================================================I
call echo                %gr%olá, %nome% seja bem vindo e tenha %msg%. o que você deseja?      
call echo %cl%I----------------------------------------------------------------------------------------------------------------------I
call echo I%ln%   [1] fazer limpeza                      [2] otimização geral  [3] info                [4] automatizar          %cl%     I
call echo %cl%I----------------------------------------------------------------------------------------------------------------------I
call echo I%ln%   [5] extensoes                          [6] bibliotecas       [7] abrir chat          [8] ativar windows/office%cl%     I
call echo %cl%I----------------------------------------------------------------------------------------------------------------------I
call echo I%ln%   [9] loja Trix                          [10] configurações    [11] pedir suporte      [12] ver conquista       %cl%     I
call echo %cl%I----------------------------------------------------------------------------------------------------------------------I
call echo I%ln%   [13] gerenciar apps do sistema         [14] versão novidades [15] definir backup     [16] ger. atualizações    %cl%    I
call echo %cl%I----------------------------------------------------------------------------------------------------------------------I
call echo I%ln%   [17] cores                             [18] Torn             [19] avaliar PC                                  %cl%     I
call echo %cl%I----------------------------------------------------------------------------------------------------------------------I
call echo I%rd%   [X]%gr% sair                           %bl%[P]%gr% procurar opção%cl%                       %yw%[D]%gr%ajude-nos/donate%cl%
call echo %cl%I======================================================================================================================I%cl%
call echo I%pl%OPÇÕES ESPECIAIS: 
if exist c:\trix_cmd\scrcpy-win32-v%vs% (
   call echo.%gr% [S] %ln%scrcpy
   call echo.%rd% [rst] %ln% reiniciar adb
)
if exist c:\trix_cmd\scrcpy-win64-v%vs% (
   call echo.%gr% [S] %ln%scrcpy
   call echo.%rd% [rst] %ln%reiniciar adb
)
if exist %adb% call echo.%gr% [AD]%ln%adb
if exist %ativa% call echo.%yw% %ativar%
if exist %airii% call echo.%yw% %ari%
if exist %aa% call echo. %yw% %a%
if exist %rr% call echo. %yw% %r% 
if exist c:\users\%username%\dados\status\tipo.txt (
   call echo %cl%I======================================================================================================================I
   if exist %limss% call echo.%cl%I %gr%[limpeza] %yw% %lims%
   if exist %limcc% call echo.%cl%I %gr%[limpeza] %yw% %limc%
   call echo %cl%I======================================================================================================================I
)
if exist c:\users\%username%\dados\torn (
   if not exist c:\users\%username%\dados\status\tipo.txt (
   call echo %cl%I======================================================================================================================I
   )
   call echo I %gr%[TORN]%yw% %torn% %cl%
   if exist %vigia% call echo I%gr% [Torn está fazendo vigia]
   call echo %cl%I======================================================================================================================I
)
call echo %gr%[NOVIDADES]%yw% %NOVO%
call echo %gr%[DICAS]%yw% %DICAS%
call echo %bl%[VERSÃO:%V%]
call echo %yw%
set /p "opt=> "
if /i "%opt%"=="rm" (
   %menu%
   exit
)
if /i "%opt%"=="x" (
    :invalido
    cls
    call echo %bl% =============================
    call echo %gr%   %msg%, até logo %nome%!
    call echo %bl% =============================
    timeout /t 3 >nul
    exit
)
if not defined op%opt% (
    echo.  
    call echo    %rd%[OPÇÃO INVÁLIDA, TENTE NOVAMENTE]%rd%
    echo.    
    timeout /t 2 >nul
    goto menu
)
set "nome=!nome%opt%!"

set "arquivo=C:\trix_cmd\!op%opt%! "
if not exist "!arquivo!" (
    echo Arquivo não encontrado ou indispónivel: "!arquivo!"
    echo Verifique se a pasta Trix contém todos os arquivos necessários.
    pause
    goto menu
)

cls
call echo %bl%==========================================================================
call echo        %gr%[!nome!] selecionado!%bl%
call echo ==========================================================================%rd%
if not exist c:\users\%username%\dados\nome\*.txt (
   echo parece que os arquivos de nome estão em falta! 
   echo redirecionando %nome% para a pagina de verificação...
   echo [pressione qualquer tecla para fazer verificação]
   pause >nul
   start c:\trix_cmd\0\validacao.bat
   exit
)
if not exist "c:\users\%username%\dados" (
   echo parece que dados estão em falta! 
   echo redirecionando %nome% para a pagina de verificação...  
   echo [pressione qualquer tecla para fazer verificação]
   pause >nul
   call c:\trix_cmd\0\validacao.bat
   exit
)
timeout /t 1 >nul
call "!arquivo!"
:removidos
cls
echo essa opção pode ter sido removida após o remake, ou esta em falta, aguarde atualizações ou atualize agora
echo [pressione qualquer tecla para confirmar leitura]
pause >nul
goto menu
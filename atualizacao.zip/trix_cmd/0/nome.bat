@echo off
chcp 65001
set /p menu=<c:\trix_cmd\0\menu.txt
for /F %%a in ('"prompt $E & for %%b in (1) do rem"') do set "ESC=%%a"
set rd=%%ESC%%[31m
set nl=%%ESC%%[30m
set gr=%%ESC%%[32m
set yw=%%ESC%%[33m
set bl=%%ESC%%[34m
set pl=%%ESC%%[35m
set ci=%%ESC%%[36m
set we=%%ESC%%[37m
set sd=%%ESC%%[0m
set cl=%bl%
set cor=C:\users\%username%\dados\pers\cor.txt
set ln=%gr%
set linha=C:\users\%username%\dados\pers\lin.txt
if exist %linha% (
   set /p ln=<%linha%
)
 

setlocal enabledelayedexpansion

:: Caminho do arquivo de nome
set "b=C:\users\%username%\dados\nome\nome.txt"

:: Lê o nome salvo anteriormente, se existir
if exist "%b%" (
    for /f "usebackq delims=" %%a in ("%b%") do set "nome=%%a"
)

:inicio
cls
color 2
:: Remove arquivo apenas se necessário
if exist "%b%" powershell remove-item -path "%b%"

if exist "C:\trix_conquistas\[persistência].txt" set trx=MENOS O NOME TRIX"

call echo %bl%==============================%gr%
call echo        ALTERAR NOME
call echo Escolha um nome %trx% para voltar ao menu%bl%
call echo ============================== %yw%
set "nome=" 
set /p "nome=Qual nome que você deseja? %nome% "

echo %nome% > c:\users\%username%\dados\nome\nome.txt
:: Verifica se a variável "nome" está vazia
if not defined nome (
    call echo %gr%Trix:%rd% O nome não pode estar vazio! Tente novamente.
    timeout /t 2 >nul
    goto incio
)

:: Bloqueia nomes proibidos
if /i "%nome%"=="trix" (
    goto ver
)

:: Salva o novo nome no arquivo corretamente
echo %nome% > "%b%"
call echo %gr%Nome alterado com sucesso para %nome%!
timeout /t 2 >nul
cls
%menu%
goto inicio

:ver
if not exist C:\trix_conquistas mkdir "C:\trix_conquistas" 
if exist c:\trix_conquistas goto conquista

:conquista
if exist "C:\trix_conquistas\[persistência].txt" (
    cls
    call echo %pl%Trix:%rd% NÃO, ESCOLHA OUTRO NOME %bl%
    timeout /t 2 >nul 
    set "trx=MENOS TRIX" 
    echo infeliz > "%b%"
    %menu%
    exit
    goto inicio
)

if exist "C:\trix_conquistas\[cópia].txt" (
    mkdir "C:\trix_conquistas"
    cls
    call echo %pl%Trix:%rd% Só existe uma Trix!!!!%gr%
    timeout /t 1 >nul
    echo Essa pergunta novamente? > "C:\trix_conquistas\[persistência].txt"
    timeout /t 2 >nul
    cls
    goto inicio
) else (
    mkdir "C:\trix_conquistas"
    cls
    call echo %pl%Trix:%bl% Só existe uma Trix! Que ousadia!%gr%
    timeout /t 1 >nul
    call echo Conquista desbloqueada: [Cópia]
    echo Tente copiar a Trix > "C:\trix_conquistas\[cópia].txt"
    timeout /t 2 >nul
    cls
    goto inicio
)

@echo off
timeout /t 180 >nul
for /f %%a in ('powershell -command "(get-date).adddays(1).day -eq 1"') do set "ultimo=%%A"
if /i "%ultimo%"=="true" (
   msg * atualização disponível! verifique seu email!
) else (
    exit 
)


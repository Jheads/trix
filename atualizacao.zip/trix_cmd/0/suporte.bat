@echo off
chcp 65001
set /p menu=<c:\trix_cmd\0\menu.txt
 
color 2
:menu
cls
echo ======================
echo        SUPORTE
echo ====================== 
echo [1] opção não funcionando
echo [2] trix abrindo e fechando automático
echo [3] trix travando
echo [4] atalho não sendo executado
echo [5] não entendo como mexer na trix
echo [6] enviar email para suporte humano
echo [x] voltar
echo ======================
set /p "opc=escolha uma opção:"

if "%opc%"=="1" goto 1
if "%opc%"=="2" goto 2
if "%opc%"=="3" goto 3
if "%opc%"=="4" goto 4
if "%OPC%"=="5" goto 5
if "%opc%"=="6" goto 6
if /i "%opc%"=="x" goto x
echo opção inválida, tente novamente! 
timeout /t 1 >nul 
pause
goto menu

:1
cls
echo informe a opção e o que aparece quando ela para de funcionar 
pause
goto 5

:2
cls
echo certifique que seu computador seja compátivel com o sistema e que todos os arquivos estejam presentes, se sim envie um email descrevendo em qual opção a trix trava
pause
goto 5

:3
cls
echo reinicie as preferencias dela na opção de desinstalar ao menu, verifique também se nao tem outros apps funcionando enquanto ela exeuta comandos pesados como a limpeza
pause
goto menu

:4
cls
será resolvido na próxima atualização esse bug do powershell, não se preocupe
pause
goto menu

:6
cls
echo ======================
echo enviar email?
echo =====================
echo você pode usar abreviações como s, sim, Sim, SIM, n, não, NAO, Não, Nao,
echo para ficar mais fácil de se escrever
set /p "op=(sim/não): "
if /i "%op%"=="s" goto sim
if /i "%op%"=="sim" goto sim
if /i "%op%"=="não" goto nao
if /i "%op%"=="nao" goto nao
if /i "%op%"=="n" goto nao
echo opção inválida, tente novamente
timeout /t 1 >nul
goto 5

:nao
cls
echo entendido, voltando para o menu...
timeout /t 1 >nul 
goto menu

:sim
cls
echo abrindo email 
start "" "https://mail.google.com/mail/?view=cm&fs=1&to=usua2947@email.com"
goto 5

:5
echo algumas opções da trix podem estar com letras e números, sempre verifique a caixinha ao lado da opção.
echo futuramente um novo menu minimalista será adicionado.
timeout /t 2 >nul
echo [pressione qualquer tecla para continuar]
pause >nul
goto menu

:x
cls
echo levando %nome% de volta ao menu...
timeout /t 1 >nul
%menu%
@echo off
chcp 65001
set /p menu=<C:\trix_cmd\0\menu.txt
set /a contador=0
:loop
if not exist C:\trix_cmd\cache\anim.txt goto 1
if %contador% GEQ %limite% goto tempo
if exist C:\trix_cmd\3\timeout.txt (
    set /p limite=<C:\trix_cmd\3\timeout.txt
) else (
    set limite=180
)
cls
echo tempo limite [%contador%] [%limite%]
echo    /\_/\ 
echo   ( o.o )  _
echo   "> ^ <"_//
echo   c_c_d_d_ )
echo.
echo Carregando.
timeout /t 1 >nul
cls
echo tempo limite [%contador%] [%limite%]
echo    /\_/\ 
echo   ( -.- ) _
echo   "> ^ <"_))
echo   c_c_d_d_ )
echo.
echo Carregando..
timeout /t 1 >nul
cls
echo tempo limite [%contador%] [%limite%]
echo    /\_/\ 
echo   ( o.o ) _
echo   "> ^ <"_//
echo   c_c_d_d_ )
echo.
echo Carregando...
timeout /t 1 >nul
cls
echo tempo limite [%contador%] [%limite%]
echo    /\_/\ 
echo   ( -.- ) _
echo   "> ^ <"_((
echo   c_c_d_d_ )
echo.
echo Carregando...
cls
set /a contador+=3
goto loop
:1 
cls
echo    /\_/\ 
echo   ( o.o )  _
echo   "> ^ <" ((
echo   (     )  ))
echo  Carregado!
call C:\trix_cmd\0\0_menu.bat
exit
:tempo
echo tempo limite atingido
echo menu não está respondendo, deseja tentar novamente?
echo [1] sim         /\_/\
echo [2] não, sair  ( T.T )
set /p "opc=> "
if "%opc%"=="1" (
    %menu%
    exit & exit
)
if "%opc%"=="2" (
    exit
)
exit
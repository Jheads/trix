@echo off
chcp 65001
color 4
set /p menu=<c:\trix_cmd\0\menu.txt
:inicio
cls
echo ===============================
echo        AUTOMATIZAR
ECHO ==============================
ECHO [1] LIMPEZA AUTOMÁTICA
ECHO [2] PROTEÇÃO COTRA BUGS
ECHO [x] VOLTAR
SET /P "OPC=ESCOLHA UMA OPÇÃO: "
if "%opc%"=="1" goto 1
if "%opc%"=="2" goto 2
if /i "%opc%"=="x" cls & echo voltando.... & goto x
echo opção inválida, tente novamente!
timeout /t 1 >nul
goto inicio

:1
echo iniciando limpeza automática...
timeout /t 1 >nul
call C:\trix_cmd\2\limpeza_auto.bat
goto inicio

:2
echo iniciando proteção de bugs
timeout /t >nul 1
call  C:\trix_cmd\0\protecao.bat
goto inicio

:x
timeout /t 1 >nul 
%menu%
exit
powershell -WindowStyle Hidden -Command "Start-Process cmd -ArgumentList '/c \"\"C:\trix_cmd\0\0-integridade.bat\"\"' -WindowStyle Hidden"
echo ocultando backend
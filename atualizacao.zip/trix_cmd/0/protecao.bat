cls
@echo off
chcp 65001
color 2
set /p menu=<c:\trix_cmd\0\menu.txt
 
if not exist "C:\users\%username%\dados\sprotecao" mkdir C:\users\%username%\dados\pers\sprotecao

set /p smile0=<"C:\users\%username%\dados\config\sprotecao\tr.txt"
set /p smile1=<"C:\users\%username%\dados\config\sprotecao\ix.txt"

:menu
cls
echo      ================================
echo     ativar ou desativar proteção de bugs?
echo     ================================
echo     essa opção fará com que o computador tenha menos chances de corromper,
echo     travar na tela inicial e de dar tela preta
echo      =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=
echo      [s] sim
echo      [n] não, voltar
echo.     %smile0%
echo.     %smile1%
echo     -=-=-===-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
set /p "opc=ativar/desativar proteção de bugs? " 
if "%opc%"=="sim" goto sim
if "%opc%"=="s" goto sim
if "%opc%"=="n" goto nao
if "%opc%"=="não" goto nao
if "%opc%"=="nao" goto nao
if "%opc%"=="desativar" goto dv
if "%opc%"=="dv" goto dv
if "%opc%"=="" echo escolha alguma opção antes de apertar enter!
echo opção inválida, tente novamente!
timoeut /t 2 >NUL
goto menu

:sim
echo ativado com sucesso!
echo [dv]desativar > "C:\users\%username%\dados\config\sprotecao\ix.txt"
echo . > "C:\users\%username%\dados\config\sprotecao\tr.txt"
timeout /t 1 >nul
schtasks /create /tn  "proteção de bugs trx" /tr "explorer.exe" /sc onstart /ru SYSTEM
cls
call C:\trix_cmd\0\protecao.bat

:nao
echo  /\__/\ > "C:\users\%username%\dados\config\sprotecao\tr.txt"
echo  /- w - \ > "C:\users\%username%\dados\config\sprotecao\ix.txt"
echo entendido, voltando para o menu...
cls
%menu%
exit
timeout /t 1 >nul
goto menu

:dv
echo  /\__/\ > "C:\users\%username%\dados\config\sprotecao\tr.txt"
echo  /- w - \ > "C:\users\%username%\dados\config\sprotecao\ix.txt"
echo desativado com sucesso!
set /p dv=<"C:\users\%username%\dados\config\sprotecao\ix.txt"
echo carregando volta
schtasks /delete /tn "proteção de bugs trx" /f <nul
cls
call C:\trix_cmd\0\protecao.bat
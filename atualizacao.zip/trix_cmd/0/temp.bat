@echo off
chcp 65001
if exist c:\users\%username%\dados\status\temp(0).txt goto sair
echo 1 > c:\users\%username%\dados\status\temp(0).txt
:sair
exit
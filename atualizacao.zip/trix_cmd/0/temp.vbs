set objshell = createobject("wscript.shell")
objshell.run """c:\trix_cmd\0\temp.bat""", 0, false
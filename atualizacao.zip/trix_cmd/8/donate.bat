﻿@echo off
chcp 65001
@echo off
echo aqui é a cafeteria onde você poderá doar dinheiro real diferentes
echo cafés virtuais para ajudar no desenvolvimento dos sistemas da Trix.
echo não é obrigatório, então qualquer quantia já será de bom agrado!
echo para resgatar o café virtual 
:menu
set /p chave=<c:\trix_cmd\8\chave.txt
cls
if exist C:\users\%username%\dados\status\dn.txt (
   echo pergunta pós donate, desativada
   timeout /t 2 >nul
)
if exist C:\users\%username%\dados\status\ds.txt (
   echo pergunta pós donate, desativada com email
   tiemout /t 2 >nul
)
cls
echo ================================ 
echo ----------CAFETERIA-------------
ECHO ================================
echo [1] cappucino--------------[10$]
echo [2] extra forte------------[15$]
echo [3] expresso---------------[20$]
echo [4] escolher--------------------
echo ================================
echo [x] voltar
echo ================================
set /p "opc=-> "
if "%opc%"=="1" goto 1
if "%opc%"=="2" goto 2
if "%opc%"=="3" goto 3
if "%opc%"=="4" goto 4
if /i "%opc%"=="x" goto x
echo opção inválida, tente novamente!
timeout /t 2 >nul
goto menu

:1
echo cappucino saindo! 
timeout /t 2 >Nul
echo "    (  )   (   )  )"
echo "      ) (   )  (  ("
echo "     ( )  (    ) )"
echo "     _____________"
echo "    <_____________> ___"
echo "    |             |/ _ \"
echo "    |               | | |"
echo "    |               |_| |"
echo " ___|             |\___/"
echo "/    \___________/    \"
echo "\_____________________/"
start C:\trix_cmd\8\cappucino.pdf
timeout /t 2 >Nul
goto per

:2
echo extra forte saindo!
timeout /t 2 >nul
echo "    (  )   (   )  )"
echo "      ) (   )  (  ("
echo "     ( )  (    ) )"
echo "     _____________"
echo "    <_____________> ___"
echo "    |             |/ _ \"
echo "    |               | | |"
echo "    |               |_| |"
echo " ___|             |\___/"
echo "/    \___________/    \"
echo "\_____________________/"
start C:\trix_cmd\8\extra.pdf
timeout /t 2 >nul
goto per

:3
echo expresso saindo!
timeout /t 2 >nul
echo "    (  )   (   )  )"
echo "      ) (   )  (  ("
echo "     ( )  (    ) )"
echo "     _____________"
echo "    <_____________> ___"
echo "    |             |/ _ \"
echo "    |               | | |"
echo "    |               |_| |"
echo " ___|             |\___/"
echo "/    \___________/    \"
echo "\_____________________/"
start C:\trix_cmd\8\expresso.pdf
timeout /t 2 >nul
goto per

:4
cls
echo escolha a quantidade do donate!
echo chave pix: %chave%
timeout /t 2 >nul
echo [pressione qualquer tecla para voltar]
pause >nul
goto per

:per
if exist C:\users\%username%\dados\status\dn.txt goto menu
if exist C:\users\%username%\dados\status\ds.txt goto mail
cls
echo você quer entrar para o mural de doante? será exibido na página do github
echo só precisará enviar um email com o seu nome da conta de sua doação e em 1-3 dias
echo após validação seu nome estará no mural
echo [1] enviar email
echo [2] sim e não perguntar novamente
echo [3] não e não perguntar novamente
echo [x] não, obrigado(a)
set /p "opcc=-> "
if "%opcc%"=="1" goto mail
if "%opcc%"=="2" (
   echo > C:\users\%username%\dados\status\ds.txt
   goto mail
)
if "%opcc%"=="3" (
   echo > C:\users\%username%\dados\status\dn.txt
   goto menu
)
if /i "%opcc%"=="x" goto menu
echo opção inválida, tente novamente
timeout /t 2 >nul
goto per

:mail
start "" "https://mail.google.com/mail/?view=cm&fs=1&to=usua2947@email.com"
goto menu

:x
%menu%
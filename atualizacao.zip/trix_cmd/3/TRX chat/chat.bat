@echo off
chcp 65001
if not exist %userprofile%\dados\status\chat.txt (
    echo opção em fase beta, para ativar a opção acesse as configurações
    pause 
    goto x
)
set /p menu=<C:\trix_cmd\0\menu.txt
set disco=C:
:menu
cls
echo ==================================
echo [1] verificar apps.exe
echo [2] ver clima
echo [3] verificar informações de agora
echo [4] abrir chat
echo [x] voltar
echo ==================================
set /p "opc=>"
if "%opc%"=="1" goto 1
if "%opc%"=="2" goto 2
if "%opc%"=="3" goto 3
if "%opc%"=="4" goto 4
if /i "%opc%"=="x" goto x
echo opção inválida.
timeout /t 2 >nul
goto menu

:4
start C:\trix_cmd\3\0chat.bat 
goto menu

:3
echo essas informações são superficiais e podem conter erros
echo computador:
echo %computername%
echo usuario:
echo %username%
echo hora:
time /t
echo [pressione qualquer tecla para voltar]
pause >nul
goto menu

:2
start "" "https://www.accuweather.com"
goto menu

:01
cls
if exist D:\ goto pergunta
if exist E:\ goto pergunta
if exist F:\ goto pergunta
goto 1
:pergunta
cls
echo =====================================
echo       pergunta de disco
echo ======================================
echo foi detectado um disco extra.
echo qual disco você usa como disco de apps?
echo se for o disco C, digite C
set /p "disco=> "
:1
cls
echo ======================================
echo [1] verificar exes do sistema
echo [2] abrir exes 
echo [x] voltar
echo ======================================
set /p "opc=>"
if "%opc%"=="1" goto 11
if "%opc%"=="2" goto 22
if /i "%opc%"=="x" goto menu
echo opção inválida
timeout /t 2 >nul
goto 1

:11
cls
echo ========================================
echo [1] todos os exes
echo [2] exe específico
echo [x] voltar
echo ========================================
set /p "opc=> "
if "%opc%"=="1" goto exesys
if "%opc%"=="2" goto exe
if /i "%opc%"=="x" goto 1
echo opção inválida
timeout /t 2 >nul
goto 11

:exe
cls
echo digite o nome do aplicativo exe que você deseja
set /p "exe=> "
for /f "delims=" %%i in ('dir %disco%:\%exe%*.exe /s /b 2^>nul') do @echo %%~nxi
if errorlevel 1 (
    echo arquivo não encontrado ou inexistente
)
echo [pressione qualquer tecla para voltar]
pause >nul
goto menu

:exesys
cls
echo procurando, não irá demorar muito....
for /f "delims=" %%i in ('dir %disco%:\*.exe /s /b 2^>nul') do @echo %%~nxi
echo [pressione qualquer tecla para voltar]
pause >nul
goto menu

:22
cls
set /p "programa=>"
echo procurando %programa%.exe
for /f "delims=" %%i in ('dir %dsico%:\%programa%.exe /s /b') do "%%i"
if errorlevel 1 (
    for /f "delims=" %%i in ('where %programa%.exe') do "%%i"
    if errorlevel 1 (
        cls
        echo aplicativo não encontrado ou inexistente
        timeout /t 2 >nul
        goto menu
    )
) else (
    echo aplicativo aberto
)
goto menu
:x
%menu%
if errorlevel 1 (
    echo erro de caminho, travando script no chat
    timeout /t 2 >nul
    goto menu
)
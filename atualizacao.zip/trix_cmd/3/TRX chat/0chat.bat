@echo off
chcp 65001
setlocal EnableDelayedExpansion

set "PASTA=C:\trix_cmd\3\chat-biblioteca"
echo BETA: o sistema ainda está "seco" mas futuramente poderá receber 
echo inteligencia ou uma biblioteca maior, por estar em fase beta o sistema 
echo pode gerar frases sem sentido as vezes. tudo conforme a biblioteca do sistema
echo se quiser emvie um email com frases e repostas para adicionar ao sistema!
pause

:chat
echo.
set /p "op=> "

set "MELHOR="
set /a SCOREMAX=0

for %%F in ("%PASTA%\*.txt") do (
    set /a SCORE=0
    set "NOME=%%~nF"

    for %%W in (%op%) do (
        if not "%%W"=="" (
            if not "%%W"=="a" if not "%%W"=="o" if not "%%W"=="e" (
                
                echo !NOME! | findstr /i "\<%%W\>" >nul && (
                    set /a SCORE+=3
                )

                findstr /i "\<%%W\>" "%%F" >nul && (
                    set /a SCORE+=1
                )
            )
        )
    )

    if !SCORE! gtr !SCOREMAX! (
        set /a SCOREMAX=!SCORE!
        set "MELHOR=%%F"
    )
)

if defined MELHOR if !SCOREMAX! gtr 0 (
    echo.
    type "!MELHOR!"
) else (
    echo.
    echo Nao entendi direito. Pode reformular?
)

goto chat

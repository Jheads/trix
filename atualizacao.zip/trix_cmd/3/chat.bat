@echo off
:menu
tasklist | findstr /i opera >nul 
if errorlevel 1 (
    echo opera ja existe no sistema, nao remover > C:\trix_cmd\cache\opera.txt
)
set /p menu=<C:\trix_cmd\0\menu.txt
set /p nome=<%userprofile%\dados\nome\nome.txt
@echo off
chcp 65001
net session >nul 2>&1
if %errorlevel% neq 0 (
   echo solicitando privilégios de adm...
   powershell -command "start-process cmd -argumentlist '/c \"%~f0\"' -verb runas"
   exit
)
ollama --version
if errorlevel 1 (
    goto instalador 
) else (
    goto 2
)
:instalador
ping -s 3 google.com >nul
if errorlevel 1 (
    echo erro, não foi possivel estabelecer uma conexão com a internet
    pause 
    %menu%
) else (
    echo conexão estável
    echo downloading [5GB] para cancelar pressione ctrl+C
    powershell -command "irm https://ollama.com/install.ps1 | iex"
)
:1
if exist C:\trix_cmd\cache\opera.txt (
    taskkill /f /im opera.exe >nul 2>&1
    taskkill /f /im opera_gx.exe >nul 2>&1
    taskkill /f /im launcher.exe >nul 2>&1
    taskkill /f /im crashpad_handler.exe >nul 2>&1
    goto 2
)
echo ollama vem com o opera junto, para deixar só o ollama 
echo iremos desinstalar o opera
tasklist | findstr /i opera >nul
if errorlevel 1 (
    goto 1
)
title Remocao Completa do opera

taskkill /f /im opera.exe >nul 2>&1
taskkill /f /im opera_gx.exe >nul 2>&1
taskkill /f /im launcher.exe >nul 2>&1
taskkill /f /im crashpad_handler.exe >nul 2>&1
timeout /t 2 >nul

if exist "%LOCALAPPDATA%\Programs\Opera\launcher.exe" (
    start "" /wait "%LOCALAPPDATA%\Programs\Opera\launcher.exe" --uninstall --silent
)

if exist "%LOCALAPPDATA%\Programs\Opera GX\launcher.exe" (
    start "" /wait "%LOCALAPPDATA%\Programs\Opera GX\launcher.exe" --uninstall --silent
)

echo Finalizado.
pause

timeout /t 3 >nul

echo.
echo Removendo pastas residuais...

rmdir /s /q "%LOCALAPPDATA%\Programs\Opera"
powershell remove-item -path ("%LOCALAPPDATA%\Programs\Opera") -recurse -force
rmdir /s /q "%LOCALAPPDATA%\Programs\Opera GX"
rmdir /s /q "%APPDATA%\Opera Software"
powershell remove-item -path "%APPDATA%\Opera*" -recurse -force
rmdir /s /q "%LOCALAPPDATA%\Opera Software"


echo.
echo Processo finalizado
:2
cls 
echo BETA
echo =======================
echo      chat offline
echo =======================
echo [1] mistral 
echo consumo: [8 RAM, 4.4gb]
echo [2] phi3 
if not exist %userprofile%\dados\status\ai.txt (
    echo consumo: [4 RAM, 2.2gb]
)
echo [x] voltar 
echo =======================
echo os chats serão instalados 
echo após a intalação eles 
echo funcionarão sem internet
echo -----------------------
set /p "opc=> "
if "%opc%"=="1" goto mistral-instalador
if "%opc%"=="2" goto phi3-instalador
if /i "%opc%"=="x" goto x
echo opção inválida, tente novamente
timeout /t 2 >nul
goto 2

:mistral-instalador
ollama pull mistral
cls
echo [x] voltar ao menu
:mistral
set /p pergunta=%nome%: 
if /i "%pergunta%"=="x" goto 2
ollama run mistral "%pergunta%"
echo. 
goto mistral

:phi3-instalador
ollama pull phi3
cls
echo [x] voltar ao menu
:phi3
set /p pergunta=%nome%: 
if /i "%pergunta%"=="x" goto 2
set prompt=Responda em portugues do Brasil e com um "Trix:" no inicio da frase. Pergunta: %pergunta%
ollama run phi3 "%pergunta%"
echo. 
goto phi3
:x
%menu%
﻿@echo off
chcp 65001 
:menu
@echo off
set /p menu=<C:\trix_cmd\0\menu.txt
cls
echo ====================================
echo        opções do computador
echo [1] verificar infos do computador
echo [2] verificar infos de internet
echo [3] fazer verificação de integridade completa
echo [x] voltar
set /p "opc=>"
if "%opc%"=="1" goto 1 
if "%opc%"=="2" goto 2
if "%opc%"=="3" goto 3
if /i "%opc%"=="x" goto X
echo opção inválida, tente novamente
timeout /t 2 >nul
goto menu 

:1
echo.
echo.
systeminfo
echo.
echo.
echo                       INFORMAÇÕES GERAIS
echo.
echo             [pressione qualquer tecla para ver infos CPU]
pause >nul
echo.
echo.
wmic cpu get name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed
wmic cpu get loadpercentage
echo.
echo.
echo                       INFORMAÇÕES DA CPU
echo.
echo          [pressione qualquer tecla para ver infos memória ram]
pause >nul
echo.
echo.
wmic memorychip get capacity,speed,manufacturer
echo.
echo.
echo                    INFORMAÇÕES DA MEMÓRIA RAM
echo.
echo            [pressione qualquer tecla para ver infos placa mãe]
pause >nul
echo.
echo.
wmic baseboard get manufacturer,product,serialnumber
echo.
echo.
echo                        INFORMAÇÕES DA PLACA MÃE
ECHO.
echo              [pressione qualquer tecla para ver infos da bios]
pause >nul
ECHO.
ECHO.
wmic bios get smbiosbiosversion,manufacturer,releaseDate
ECHO.
ECHO.
echo                           INFORMAÇÕES DA BIOS
ECHO.
echo            [pressione qualquer tecla para ver infos do hd/ssd]
pause >nul
ECHO.
ECHO.
wmic diskdrive get model,size,interfacetype
ECHO.
ECHO                                MODELOS
ECHO.
wmic logicaldisk get name,freespace,size
ECHO.
echo                            ESPAÇO LIVRE EM MB
ECHO.
wmic diskdrive get status
ECHO.
echo                              ESTADO DO DISCO
ECHO.
echo            [pressione qualquer tecla para ver infos da placa de vídeo]
pause >nul
ECHO.
ECHO.
wmic path win32_videocontroller get name,adapterram,driverversion
ECHO.
ECHO.
echo             [pressione qualquer tecla para ver infos da temperatura]
pause >nul
ECHO.
ECHO.
wmic /namespace:\\root\wmi PATH MSAcpi_ThermalZoneTemperature get CurrentTemperature
ECHO.
ECHO.
ECHO                      INFOS DA TEMPERATURA [PODE CONTER ERROS]
ECHO.
echo               [pressione qualquer tecla para FINALIZAR RELATÓRIO]
pause >nul
ECHO.
ECHO.
goto menu

:2
ipconfig /all
ECHO                          INFORMAÇÕES DE REDE
ECHO.
ECHO               [PRESSIONE QUALQUER TECLA PARA VER VELOCIDADE DE REDE] 
ECHO.
ECHO.
PAUSE >NUL
wmic nic where NetEnabled=true get Name,Speed
ECHO.
ECHO.
ECHO              100000000 = 100 Mbps, menor que isso = rede lenta ou 2g
ECHO              [PRESSIONE QUALQUER TECLA PARA VER QUALIDADE DE CONEXÃO]
PAUSE >NUL
ECHO.
ECHO.
netsh wlan show interfaces
ECHO.
ECHO                 [PRESSIONE QUALQUER TECLA PARA TESTAR CONEXÃO]
PAUSE >NUL
ECHO.
ECHO.
ECHO               SERÁ UM TESTE DE 10 PINGS, QUALQUER PERDA SERÁ CONTADA.
ECHO               APÓS SERÁ UM TESTE DE 30 PINGS
ECHO                [PRESSIONE QUALQUER TECLA PARA TESTAR CONEXÃO]
PAUSE >NUL
ECHO.
ECHO.
ping 8.8.8.8 -n 10
ECHO  CONCLÚIDO
tracert 8.8.8.8
ECHO.
ECHO           [PRESSIONE QUALQUER TECLA PARA TESTAR CONEXÕES ATIVAS E USO DE REDE]
ECHO.
PAUSE >NUL
ECHO.
ECHO.
netstat -e
ECHO.
ECHO                        [QUALQUER TECLA PARA CONTINUAR]
PAUSE >NUL
ECHO.
ECHO.
netstat -ano
ECHO                     [PRESSIONE QUALQUER TECLA PARA VOLTAR]
PAUSE >NUL
GOTO MENU

:3
sfc /scannow
DISM /Online /Cleanup-Image /CheckHealth
ipconfig /release
ipconfig /flushdns
netsh int ip reset
netsh winsock reset
ECHO CONLUIDO!
MSG "*" "reinicie o computador para aplicar correções"
ECHO [PRESSIONE QUALQUER TECLA PARA VOLTAR]

:X
%menu%                                                                                                                                                                                                                                                                                                                                                                                                         
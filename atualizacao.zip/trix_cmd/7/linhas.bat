@echo off
chcp 65001
for /F %%a in ('"prompt $E & for %%b in (1) do rem"') do set "ESC=%%a"
set rd=%%ESC%%[31m
set nl=%%ESC%%[30m
set gr=%%ESC%%[32m
set yw=%%ESC%%[33m
set bl=%%ESC%%[34m
set pl=%%ESC%%[35m
set ci=%%ESC%%[36m
set we=%%ESC%%[37m
set sd=%%ESC%%[0m
set ln=%gr%
set cl=%pl%
set c11=%userprofile%\dados\pers\cor\cl
set L11=%userprofile%\dados\pers\cor\ln
if exist %c11%\rd.txt (
   set cl=%rd%
)
if exist %c11%\nl.txt (
   set cl=%nl%
)
if exist %c11%\gr.txt (
   set cl=%gr%
)
if exist %c11%\yw.txt (
   set cl=%yw%
)
if exist %c11%\bl.txt (
   set cl=%bl%
)
if exist %c11%\pl.txt (
   set cl=%pl%
)
if exist %c11%\ci.txt (
   set cl=%ci%
)
if exist %c11%\we.txt (
   set cl=%we%
)
if exist %c11%\sd.txt (
   set cl=%sd%
)
::linhas
if exist %L11%\rd.txt (
   set ln=%rd%
)
if exist %l11%\nl.txt (
   set ln=%nl%
)
if exist %l11%\gr.txt (
   set ln=%gr%
)
if exist %l11%\yw.txt (
   set ln=%yw%
)
if exist %l11%\bl.txt (
   set ln=%bl%
)
if exist %l11%\pl.txt (
   set ln=%pl%
)
if exist %l11%\ci.txt (
   set ln=%ci%
)
if exist %l11%\we.txt (
   set ln=%we%
)
if exist %l11%\sd.txt (
   set ln=%sd%
)
:in
set caminho=%userprofile%\dados\pers\cor\ln
set conquistas=c:\trix_conquistas\[R].txt
set /p menu=<c:\trix_cmd\0\menu.txt
set corc=c:\users\%username%\dados\pers\cor\ln\*.txt
set opca=c:\users\%username%\dados\pers\opcao.txt
if not exist %corc% mkdir %corc%
cls
timeout /t 2 >nul
echo inicio
color 2
:admin
cls
call ECHO %cl%================================%ln%
call echo          TRIX OPÇÕES%cl%
call echo =================================%gr%
call echo [1] %ln%azul%gr%     [4] %ln%roxo %gr%
call echo [2] %ln%verde%gr%    [5] %ln%amarelo%gr%
call echo [3] %ln%vermelho%gr% [6] %ln%ciano%gr%
if exist %corc% call echo [R] %ln%reiniciar cores
call echo %cl%==================================%yw%
call echo [observação] as cores escolhidas
call echo só mudarão menus e telas menos
call echo úteis
call echo %cl%-----------------------------------%gr%
call echo [0] %rd%voltar ao menu%yw%
set /p opc= escolha uma cor para personalizar! 
if "%opc%"=="1" goto deletador
if "%opc%"=="2" goto deletador 
if "%opc%"=="3" goto deletador
if "%opc%"=="4" goto deletador 
if "%opc%"=="5" goto deletador
if "%opc%"=="6" goto deletador
if /i "%opc%"=="r" goto r
if "%opc%"=="t" goto tema
if "%opc%"=="0" goto v
call echo %rd%
call echo opção inválida, tente novamente
timeout /t 2 >nul
goto in

:deletador
echo deletador
echo %opc% > c:\users\%username%\dados\pers\opcao.txt
cls
if exist %corc% (
   powershell remove-item -path "%corc%" -recurse -force
)
set /p opcao=<%opca%
echo %opcao%
echo caminho
pause
goto %opcao%
pause 
timeout /t 2 >nul 
pause
goto in

:1
cls
if not exist %conquistas% (
   echo i lose my mind and i lose control
   timeout /t 2 >nul
   echo i see your eyes look through my soul
   timeout /t 2 >nul
   echo don't be surprise, this is all  know
   timeout /t 2 >nul
   echo  i felt the highs and they felt like you
   timeout /t 2 >nul
   echo see, a love like mineis too good to be true
   timeout /t 2 >nul
   echo and you too divine to just be mine
   timeout /t 2 >nul
   echo you remind me of the color blue
   timeout /t 5 >nul
   echo [pressione qualquer tecla para continuar]
   pause >nul
   echo conquista desbloqueada
   echo [R]
   timeout /t 2 >nul
   echo J: querida R, você me lembra a cor azul > %conquistas%
   cls
)
echo azul > %caminho%\bl.txt
goto in
echo erro
goto in

:2
echo verde > %caminho%\gr.txt
goto in

:3
if not exist c:\users\%username%\dados\secretos\[A].txt (
   goto arii
)
if not exist c:\trix_conquistas\[A].txt (
   goto arii
)
echo vermelho > %caminho%\rd.txt
goto in

:arii
if exist c:\trix_conquistas\[A].txt goto 3
cls
echo cause my insides are red 
timeout /t 2 >nul
echo and yours are too
timeout /t 2 >nul
echo and the red on my face 
timeout /t 2 >nul
echo is matching you
timeout /t 2 >nul
echo and goodness your're bleeding
timeout /t 2 >NUL
echo what a wonderful feeling
timeout /t 2 >NUL
echo you're down and you're pleading
timeout /t 2 >Nul
echo my head is just reeling
timeout /t 2 >nul
echo the red means i love you!
timeout /t 2 >Nul
echo [pressione qualquer tecla para continuar]
pause >nul
echo J: love you brother! > c:\trix_conquistas\[A].txt
cls
goto 3

:4
echo roxo > %caminho%\pl.txt
goto in
echo erro

:5
echo amarelo > %caminho%\yw.txt
goto in
echo erro

:6
echo ciano > %caminho%\ci.txt
goto in

:r
if not exist %corc% (
   echo as cores já estão normais!
)
if exist %corc% (
   echo voltando as cores normais..
   powershell remove-item %corc% -recurse -force
)
timeout /t 3 >nul
goto in
echo erro
pause
:tema
cls
set /p opcao=<c:\users\%username%\dados\pers\opcao.txt
if exist %escuroc% (
   powershell remove-item %escuroc% -recurse -force
   echo tema alterado para tema branco
   timeout /t 2 >nul
   echo claro > %brancoc%
   goto %opcao%
)
timeout /t 2 >nul
goto in

:v
cls
echo voltando..
call c:\trix_cmd\7\menu.bat
@echo off
chcp 65001
set /p menu=<c:\trix_cmd\0\menu.txt
for /F %%a in ('"prompt $E & for %%b in (1) do rem"') do set "ESC=%%a"
set rd=%%ESC%%[31m
set nl=%%ESC%%[30m
set gr=%%ESC%%[32m
set yw=%%ESC%%[33m
set bl=%%ESC%%[34m
set pl=%%ESC%%[35m
set ci=%%ESC%%[36m
set we=%%ESC%%[37m
set sd=%%ESC%%[0m
set c11=%userprofile%\dados\pers\cor\cl
set L11=%userprofile%\dados\pers\cor\ln
set cl=%pl%
set ln=%gr%
if exist %c11%\rd.txt (
   set cl=%rd%
)
if exist %c11%\nl.txt (
   set cl=%nl%
)
if exist %c11%\gr.txt (
   set cl=%gr%
)
if exist %c11%\yw.txt (
   set cl=%yw%
)
if exist %c11%\bl.txt (
   set cl=%bl%
)
if exist %c11%\pl.txt (
   set cl=%pl%
)
if exist %c11%\ci.txt (
   set cl=%ci%
)
if exist %c11%\we.txt (
   set cl=%we%
)
if exist %c11%\sd.txt (
   set cl=%sd%
)
::linhas
if exist %L11%\rd.txt (
   set ln=%rd%
)
if exist %l11%\nl.txt (
   set ln=%nl%
)
if exist %l11%\gr.txt (
   set ln=%gr%
)
if exist %l11%\yw.txt (
   set ln=%yw%
)
if exist %l11%\bl.txt (
   set ln=%bl%
)
if exist %l11%\pl.txt (
   set ln=%pl%
)
if exist %l11%\ci.txt (
   set ln=%ci%
)
if exist %l11%\we.txt (
   set ln=%we%
)
if exist %l11%\sd.txt (
   set ln=%sd%
)

:menu
cls
call echo %cl%====================================%ln%
call echo         MENU DE CORES%cl%
call echo ====================================%gr%
call echo [1] %ln% cores de opções %gr%
call echo [2] %ln% cores de colunas %gr%
call echo [3] %rd% voltar %gr%
if exist %userprofile%\dados\pers\cor\* call echo [R] %ln%reiniciar todas as cores
if exist c:\trix_conquistas\[noisy_boy].txt call echo %pl%[N] %yw% noisy boy
call echo %cl%====================================%yw%
set /p opc=escolha um tipo de cor: 
if "%opc%"=="1" goto 1
if "%opc%"=="2" goto 2
if "%opc%"=="3" goto 3
if /i "%opc%"=="r" goto r
if /i "%opc%"=="noisyboy" goto 2018
if /i "%opc%"=="n" goto n
if /i "%opc%"=="atom" echo muito fera esse também & timeout /t 2 >nul & goto menu
call echo %rd%
call echo opção inválida, tente novamente!
timeout /t 2 >nul
goto menu

:n
if not exist c:\trix_conquistas\[noisy_boy].txt goto f1
call echo mudando tema para noisy boy
echo roxo > %c11%\pl.txt
echo amarelo > %l11%\yw.txt
timeout /t 2 >nul
goto menu
:f1
echo opção barrada, desbloqueie a conquista "noisy boy" primeiro
timeout /t 2 >nul
goto menu

:2
cls
echo cores de colunas escolhida, a cor mudada será das divisorias de menus e etc...
echo exemplo de quais divisorias serão mudadas: =,-
timeout /t 2 >nul
echo [pressione qualquer tecla]
pause >nul
call c:\trix_cmd\7\cores.bat

:1
cls
echo cores de opções escolhida, a cor mudada será das opções ou pontos importantes
echo exemplo de quais linhas serão mudadas: [1] opção
timeout /t 2 >nul
echo [pressione qualquer tecla]
pause >nul
call c:\trix_cmd\7\linhas.bat

:3
echo voltando ao menu!
timeout /t 1 >nul
%menu%

:r
echo reiniciando cores...
if exist %userprofile%\dados\pers\cor\cl\*.txt (
   echo colunas reinicadas
   powershell remove-item -path %userprofile%\dados\pers\cor\cl\*.txt -recurse -force
)
if exist %userprofile%\dados\pers\cor\ln\*.txt (
   echo opções reiniciadas
   powershell remove-item -path %userprofile%\dados\pers\cor\ln\*.txt -recurse -force
)
timeout /t 2 >nul
goto menu

:2018
if exist c:\trix_conquistas\[NOISY_BOY].txt goto f
echo ============================================
echo Noisy Boy > c:\trix_conquistas\[NOISY_BOY].txt
echo conquista desbloqueada! mudando tema para noisy boy!
echo ==============================================
echo roxo > %c11%\pl.txt
echo amarelo > %l11%\yw.txt
timeout /t 2 >nul
echo [pressione qualquer tecla]
pause >nul
goto menu
:f
echo a conquista já foi desblqueada! verifique no menu de conquistas
timeout /t 2 >nul
echo [pressione qualquer tecla]
pause >nul
goto menu
@echo off
chcp 65001
@echo off
set /p menu=<C:\trix_cmd\0\menu.txt
:menu
cls
echo OPÇÃO AINDA EM DESENVOLVIMENTO, VOCÊ PODERÁ AUMENTAR A FONTE POR ENQUANTO
ECHO APERTANDO A TECLA "ctrl & +"[Ctrl e mais] PARA DIMINUIR A FONTE APERTE
echo "ctrl & -"[ctrl e menos] OU SEGURE CTRL E GIRE O SCROLL DO MOUSE
ECHO.
ECHO               [QUALQUER LETRA PARA VOLTAR]
pause >nul
call C:\trix_cmd\0\configuracoes.bat
echo =====================================
echo configurar tamanho das letras do menu
echo =====================================
echo [1]mudar tamanho
echo [x] voltar
set /p "opc=>"
if "%opc%"=="1" goto FONTE
if /i "%opc%"=="x" %menu%
:FONTE
echo ":)"
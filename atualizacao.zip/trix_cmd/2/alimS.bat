﻿@echo off
set dstatus=%userprofile%\dados\status\dstatus.txt
if exist %dstatus%  powershell remove-item %dstatus% -recurse -force
if not exist C:\trix_cmd schtasks /delete /tn "limpezaauto" /f
mkdir C:\users\%username%\dados\status\limpeza-automatica

reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v enableprefetcher /t REG_DWORD /d 0 /f
sc config sysmain start= disabled 
sc stop sysmain 
takeown /f "C:\users\%username%\appdata\local\temp" /a /r /d y
icacls "C:\users\%username%\appdata\local\temp" /grant administrators:f /t /c /q
rd /s /q C:\users\%username%\appdata\local\temp

takeown /f "C:\Windows\Prefetch" /a /r /d y
icacls "C:\Windows\Prefetch" /grant administrators:f /t /c /q
rd /s /q C:\Windows\Prefetch

takeown /f "C:\users\%username%\appdata\roaming\microsoft\windows\recent" /a /r /d y 
icacls "C:\users\%username%\appdata\roaming\microsoft\windows\recent" /grant adminstators:f /t /c /q
rd /s /q C:\users\%username%\appdata\roaming\microsoft\windows\recent

takeown /f "C:\users\%username%\appdata\local\aplication data" /a /r /d y
icacls "C:\users\%username%\appdata\local\aplication data" /grant administrators:f /t /c /q
rd /s /q C:\users\%username%\appdata\local\aplication data

takeown /f "C:\users\%username%\appdata\local\history" /a /r /d y
icacls "C:\users\%username%\appdata\local\history" /grant administrators:f /t /c /q
rd /s /q C:\users\%username%\appdata\local\history

takeown /f "C:\users\%username%\appdata\local\microsoft\windows\temporary" /a /r /d y
icacls "C:\users\%username%\appdata\local\windows\temporary" /grant administrators:f /t /c /q
rd /s /q C:\users\%username%\appdata\local\microsoft\windows\temporary

takeown /f "C:\users\%username%\appdata\local\temporary internet files" /a /r /d y
icacls "C:\users\%username%\appdata\local\temporary internet files" /grant administrators:f /t /c /q
rd /s /q C:\users\%username%\appdata\local\temporary internet files

takeown /f "C:\windows\serviceprofiles\localservice\appdata\local\microsoft\ngc\" /a /r /d y
icacls "C:\windows\serviceprofiles\localservice\appdata\local\microsoft\ngc\" /grant administrators:f /t /c /q
rd /s /q C:\windows\serviceprofiles\localservice\appdata\local\microsoft\ngc\

takeown /f "C:\windows\system32\config\systemprofile\appdata\local\microsoft\windows\inetcache\content.ies\" /a /r /d y
icacls "C:\windows\system32\config\systemprofile\appdata\local\microsoft\windows\inetcache\content.ies\" /grant administrators:f /t /c /q
rd /s /q C:\windows\system32\config\systemprofile\appdata\local\microsoft\windows\inetcache\content.ies\

takeown /f "C:\windows\system32\logfiles\wmi\rtbackup" /a /r /d y
icacls "C:\windows\system32\logfiles\wmi\rtbackup" /grant administrators:f /t /c /q
rd /s /q C:\windows\system32\logfiles\wmi\rtbackup

rd /s /q "C:\users\%username%\appdata\local\temp"
rd /s /q "C:\Windows\Prefetch"
rd /s /q "C:\users\%username%\appdata\roaming\microsoft\windows\recent"

takeown /f "C:\windows\prefetch"
takeown "%temp%"
takeown /f "C:\users\%username%\appdata\local\temp"
takeown /f "C:\Windows\Prefetch"
takeown /f "C:\users\%username%\appdata\roaming\microsoft\windows\recent"
takeown /f "C:\windows\temp"
takeown /f "C:\windows\temp"

del /f /s /q "C:\windows\prefetch\*.*"
del /f /s /q "%temp%\*.*"
del /f /s /q "C:\users\%username%\appdata\local\temp\*.*"
del /f /s /q "C:\Windows\Prefetch\*.*"
del /f /s /q "C:\users\%username%\appdata\roaming\microsoft\windows\recent\*.*"
del /f /s /q "C:\windows\temp\*.*"
del /f /s /q "C:\windows\temp\*.*"

powershell remove-item -path "%temp%\*" -recurse -force
powershell remove-item -path "C:\Windows\Prefetch\*" -recurse -force
powershell remove-item -path "C:\users\%username%\appdata\roaming\microsoft\windows\recent\*" -recurse -force
powershell remove-item -path C:\windows\temp\* -recurse -force
powershell remove-item -path C:\users\%username%\appdata\local\temp\* -recurse -force
powershell remove-item -path C:\windows\temp\* -recurse -force

del /q /f /s %temp%\*
del /q /f /q "C:\users\%username%\appdata\local\temp\*"
del /q /f /q "C:\Windows\Prefetch\*"
del /q /f /q "C:\users\%username%\appdata\roaming\microsoft\windows\recent\*"
del /q /f /q "C:\windows\temp\*"
del /q /f /q "C:\users\%username%\appdata\local\temp\*"

wevtutil el > C:\trix_cmd\cache\temp_logs.txt
for /f "tokens=*" %%G IN (temp_logs.txt) DO (
     echo limpando log:%%G 
     wevtutil cl "%%G"
)
del C:\trix_cmd\cache\temp_logs.txt
:: Executa a limpeza em segundo plano
start /min cleanmgr /sagerun:1

:: Aguarda a conclusão da limpeza (tempo estimado, ajuste se necessário)
timeout /t 60 >nul

:: Obtém a data e hora atuais
for /f "tokens=2 delims==" %%A in ('wmic os get localdatetime /value') do set datetime=%%A
set data=%datetime:~6,2%-%datetime:~4,2%-%datetime:~0,4%
set hora=%datetime:~8,2%:%datetime:~10,2%:%datetime:~12,2%

:: Cria um arquivo de log na Área de Trabalho com a hora da conclusão
echo Limpeza silenciosa concluída em %data% às %hora%> "C:\users\%username%\dados\status\limpeza-automatica\verS.txt"
echo limpeza silenciosa esta ativa > C:\trix_cmd\cache\limpeza-silenciosa.txt

:: Toca um som de sino
echo ^G
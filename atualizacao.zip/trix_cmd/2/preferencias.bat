﻿@echo off >nul
chcp 65001 >nul
@echo off >nul
set menu=<C:\trix_cmd\menu.txt
:menu
cls
set preferencias=%userprofile%\dados\status\limpeza-preferencias
mkdir %preferencias%
echo ================================================
echo as configurações podem ser mudadas depois, não se
echo preocupe.
echo as configurações de limpeza ficam na opção
echo [10] configurações ou [C] configurações
echo ================================================
echo  para uma melhor limpeza, responda as perguntas
echo ================================================
if not exist %preferencias%\prefetch.txt (
   echo [1] desabilitar prefetch na limpeza
   ) else ( 
   echo [1] reabilitar prefetch na limpeza
)
if not exist %preferencias%\RN.txt echo [2] recusar reinicialização automaticamente
if not exist %preferencias%\RS.txt echo [3] aceitar reinicialização automaticamente
if not exist %preferencias%\FL.txt (
   echo [4] ativar limpeza profunda [isso pode causar problemas com alguns apps]
   ) else (
   echo [4] desativar limpeza profunda [recomendado]
)
if not exist %preferencias%\CL.txt (
   echo [5] desativar correção de arquivos corrompidos após limpeza
   ) else (
      echo [5] reativar correção de arquivos corrompidos após limpeza
   )
if exist %preferncias%\RN.txt (
   echo [R] fazer pergunta de reinicialização
   ) else (
     if exist %preferncias%\RS.txt (
        echo [R] fazer pergunta de reinicialização
     )
   )
echo [x] voltar
echo ================================================
set /p "opc=>"
if "%opc%"=="1" goto 1
if "%opc%"=="2" goto 2
if "%opc%"=="3" goto 3
if "%opc%"=="4" goto 4
if "%opc%"=="5" goto 5
if /i "%opc%"=="p" goto cf
if /i "%opc%"=="x" goto x
if /i "%opc%"=="r" goto R
echo opção inválida, tente novamente
goto menu

:5
if not exist %preferencias%\CL.txt (
   echo > %preferencias%\CL.TXT
   ) else (
   powershell remove-item "%preferencias%\cl.txt" -recurse -force
   )
goto menu 

:4
if not exist %preferencias%\FL.txt (
   echo > %preferencias%\TFL.txt
   echo > %preferencias%\FL.txt
   ) else (
   powershell remove-item %preferencias%\FL.txt -recurse -force
   powershell remove-item %preferencias%\TFL.txt -recurse -force
)
goto menu

:1
if not exist %preferencias%\prefetch.txt (
   echo > %preferencias%\tprefetch.txt
   echo > %preferencias%\prefetch.txt
   echo o prefetch será desabilitado após limpeza
   timeout /t 2 >nul
   ) else ( 
   powershell remove-item %preferencias%\prefetch.txt -recurse -force
   powershell remove-item %preferencias%\tprefetch.txt -recurse -force
)
goto menu

:2
if exist %preferencias%\RS.txt powershell remove-item %preferencias%\RS.txt -recurse -force
echo > %preferencias%\RN.txt
goto menu

:3
if exist %preferencias%\RN.txt powershell remove-item %preferencias%\RN.txt -recurse -force
echo > %preferencias%\RS.txt
goto menu

:cf
echo > %preferencias%/config.txt
call C:\trix_cmd\2\2trix-limpeza.bat

:r
powershell remove-item %preferencias%\RS.txt -recurse -force
powershell remove-item %preferencias%\RN.txt -recurse -force
goto menu

:x
if exist C:\trix_cmd\cache\limpeza.txt (
   goto per
   ) else (
   goto fim
)
:per
echo deseja ver essa mensagem novamente? 
echo [1] sim [recomendado caso haja algum problema]
echo [2] não
set /p "opc=>"
if "%opc%"=="1" goto 111
if "%opc%"=="2" goto cf
echo opção inválida
timeout /t 2 >nul
goto x

:111
echo > %preferencias%\tconfig.txt
goto cf

:fim
%menu%
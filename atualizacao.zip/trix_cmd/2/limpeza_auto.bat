@echo off
chcp 65001
color 2
:menu
cls
echo váriaveis normais
set dstatus=%userprofile%\dados\status\dstatus.txt
set istatus=%userprofile%\dados\status\istatus.txt
set /p tempo=<c:\users\%username%\dados\status\inftempo.txt
set /p tipo=<c:\users\%username%\dados\status\tipo.txt
set /p menu=<C:\trix_cmd\0\menu.txt
set tempo1=c:\users\%username%\dados\status\tempo.txt
set 2tempo=c:\users\%username%\dados\status\inftempo.txt
set 1tipo=c:\users\%username%\dados\status\tipo.txt
cls
echo ==========================
if not exist %dstatus% (
   echo ativar limpeza automática?
) else (
   echo dessativar limpeza automática?
)
echo ==========================
if not exist %dstatus% (
   echo [1] ativar
) else (
   echo [1] desativar 
)
if exist %istatus%  (
   echo [x] não ativar e voltar
) else (
   echo [x] deixar ativado e voltar
)
if exist %2tempo% (
   echo ==========================
   echo a [%tipo%] já
   echo está ativada, com uma pausa
   echo de %tempo% minutos
)
echo ==========================
set /p "opc=escolha uma opção: "
if "%opc%"=="1" goto 1
if /i "%opc%"=="x" goto x
echo opção inválida, tente novamente!
timeout /t 2 >nul
goto menu

:1
cls
if exist %dstatus% (
   schtasks /delete /tn "limpezaauto" /f
   cls
   echo desativado!
   timeout /t 2 >Nul
   powershell remove-item %dstatus% -recurse -force
   powershell remove-item %2tempo% -recurse -force
   echo > %istatus%
   goto menu
)
echo ótimo! quer que a limpeza seja silenciosa ou que peça confirmação?
echo [1] silenciosa
echo [2] com confirmação
set /p "op=escolha uma opção: "
if "%op%"=="1" goto s
if "%op%"=="2" cls & goto c
echo opção inválida, tente novamente 
timeout /t 2 >nul
cls
goto 1


:cancelamento
cls
powershell remove-item -path c:\users\%username%\dados\status\inftempo.txt -recurse -force
if not exist c:\trix_conquistas\[CANCELAMENTO].txt (
   echo passe por um estear egg sem notar > c:\trix_conquistas\[CANCELAMENTO].txt
)
cls
goto menu

:torn0
cls
if not exist %dstatus% (
   echo > %dstatus%
)
goto menu

:s
cls
echo iniciou
if not exist "%dsatus%" (
   echo > "%dstatus%"
   powershell remove-item "%tempo1%" -recurse -force
   powershell remove-item "%istatus%" -recurse -force
   powershell remove-item "%1tipo%" -recurse -force
)
echo passou
echo limpeza silenciosa> c:\users\%username%\dados\status\tipo.txt
echo s > c:\users\%username%\dados\status\1verif.txt
cls
echo  qual o tempo de intervalo entre a limpeza sileciosa?
echo  o tempo que demorará para a limpeza ser executada novamente
echo. 
echo  ATENÇÃO: quanto menor o tempo mais memória ram será usada
echo  recomendável mais de 10 minutos
echo.
echo  [pressione "C" para cancelar]
echo.
set /p "tempo= defina o tempo para a limpeza ser executada novamente: "
if "%tempo%"=="c" goto cancelamento
echo %tempo% > c:\users\%username%\dados\status\tempo.txt
echo %tempo% > c:\users\%username%\dados\status\inftempo.txt
echo %tempo%| findstr /r "^[0-9][0-9]*$*" >nul || (
     echo opção inválida apenas números são aceitos
     pause
     goto s
)
echo a limpeza terá o intervalo de %tempo% minutos...
echo agendando limpeza!
timeout /t 2 >nul
cls
schtasks /create /tn "limpezaauto" /tr "c:\trix_cmd\2\agendamento_limpeza_silenciosa.vbs" /sc minute /mo %tempo% /f
goto torn0

:3
call c:\trix_cmd\2\limpeza_auto.bat
timeout /t 2 >nul
exit
goto 3

:c
echo limpeza com confirmação > C:\users\%username%\dados\status\tipo.txt
if exist c:\users\%username%\dados\status\tempo.txt (
   powershell remove-item -path "c:\users\%username%\dados\status\tempo.txt" -recurse -force
)
cls
echo  qual o tempo de intervalo entre a limpeza?
echo  o tempo que demorará para a limpeza automática ser executada novamente
echo.
echo  ATENÇÃO: quanto menor o tempo, maior será o uso da memória ram
echo  recomendável mais de 10 minutos
echo.
echo [pressione "C" para canecelar]
echo.
set /p "tempo=defina o tempo de intervalo: "
if "%tempo%"=="c" goto cancelamento
echo %tempo% > c:\users\%username%\dados\status\tempo.txt
echo %tempo% > c:\users\%username%\dados\status\inftempo.txt
echo %tempo%| findstr /r "^[0-9][0-9]*$*" >nul || (
     echo opção inválida apenas números são aceitos
     pause
     goto c
)
echo a limpeza terá o intervalo de %tempo% minutos...
echo agendando limpeza!
echo > %userprofile%\dados\status\exluirlim.txt
schtasks /delete /tn "limpezaauto" 
schtasks /create /tn "limpezaauto" /tr "c:\trix_cmd\2\agendamento_limpeza.vbs" /sc minute /mo %tempo% /f
timeout /t 1 >nul
cls
goto torn0


:x
if exist "c:\users\%username%\dados\status\limpeza_aberta.txt" (
   powershell remove-item -path "c:\users\%username%\dados\status\limpeza_aberta.txt" -recurse -force
)
cls
timeout /t 2 >nul
%menu%
goto menu


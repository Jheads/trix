﻿@echo off
chcp 65001
cls
echo começando limpeza rápida! não irá demorar muito. A limpeza rápida só limpa arquivos temporários e cachês
timeout /t 3 >nul
echo.
echo   [aguardando confirmação para a iniciar, pressione qualquer tecla para confirmar]
echo.
pause >nul

echo limpeza de arquivos temporários...

takeown /f "C:\users\%username%\appdata\local\temp" /a /r /d y
icacls "C:\users\%username%\appdata\local\temp" /grant administrators:f /t /c /q
rd /s /q C:\users\%username%\appdata\local\temp

takeown /f "C:\Windows\Prefetch" /a /r /d y
icacls "C:\Windows\Prefetch" /grant administrators:f /t /c /q
rd /s /q C:\Windows\Prefetch

takeown /f "C:\users\%username%\appdata\roaming\microsoft\windows\recent" /a /r /d y 
icacls "C:\users\%username%\appdata\roaming\microsoft\windows\recent" /grant adminstators:f /t /c /q
rd /s /q C:\users\%username%\appdata\roaming\microsoft\windows\recent

takeown /f "C:\users\%username%\appdata\local\aplication data" /a /r /d y
icacls "C:\users\%username%\appdata\local\aplication data" /grant administrators:f /t /c /q
rd /s /q C:\users\%username%\appdata\local\aplication data

takeown /f "C:\users\%username%\appdata\local\history" /a /r /d y
icacls "C:\users\%username%\appdata\local\history" /grant administrators:f /t /c /q
rd /s /q C:\users\%username%\appdata\local\history

takeown /f "C:\users\%username%\appdata\local\microsoft\windows\temporary" /a /r /d y
icacls "C:\users\%username%\appdata\local\windows\temporary" /grant administrators:f /t /c /q
rd /s /q C:\users\%username%\appdata\local\microsoft\windows\temporary

takeown /f "C:\users\%username%\appdata\local\temporary internet files" /a /r /d y
icacls "C:\users\%username%\appdata\local\temporary internet files" /grant administrators:f /t /c /q
rd /s /q C:\users\%username%\appdata\local\temporary internet files

takeown /f "C:\windows\serviceprofiles\localservice\appdata\local\microsoft\ngc\" /a /r /d y
icacls "C:\windows\serviceprofiles\localservice\appdata\local\microsoft\ngc\" /grant administrators:f /t /c /q
rd /s /q C:\windows\serviceprofiles\localservice\appdata\local\microsoft\ngc\

takeown /f "C:\windows\system32\config\systemprofile\appdata\local\microsoft\windows\inetcache\content.ies\" /a /r /d y
icacls "C:\windows\system32\config\systemprofile\appdata\local\microsoft\windows\inetcache\content.ies\" /grant administrators:f /t /c /q
rd /s /q C:\windows\system32\config\systemprofile\appdata\local\microsoft\windows\inetcache\content.ies\

takeown /f "C:\windows\system32\logfiles\wmi\rtbackup" /a /r /d y
icacls "C:\windows\system32\logfiles\wmi\rtbackup" /grant administrators:f /t /c /q
rd /s /q C:\windows\system32\logfiles\wmi\rtbackup

rd /s /q "C:\users\%username%\appdata\local\temp"
rd /s /q "C:\Windows\Prefetch"
rd /s /q "C:\users\%username%\appdata\roaming\microsoft\windows\recent"

takeown /f "C:\windows\prefetch"
takeown "%temp%"
takeown /f "C:\users\%username%\appdata\local\temp"
takeown /f "C:\Windows\Prefetch"
takeown /f "C:\users\%username%\appdata\roaming\microsoft\windows\recent"
takeown /f "C:\windows\temp"
takeown /f "C:\windows\temp"

del /f /s /q "C:\windows\prefetch\*.*"
del /f /s /q "%temp%\*.*"
del /f /s /q "C:\users\%username%\appdata\local\temp\*.*"
del /f /s /q "C:\Windows\Prefetch\*.*"
del /f /s /q "C:\users\%username%\appdata\roaming\microsoft\windows\recent\*.*"
del /f /s /q "C:\windows\temp\*.*"
del /f /s /q "C:\windows\temp\*.*"

del /q /f /s %temp%\*
del /q /f /q "C:\users\%username%\appdata\local\temp\*"
del /q /f /q "C:\Windows\Prefetch\*"
del /q /f /q "C:\users\%username%\appdata\roaming\microsoft\windows\recent\*"
del /q /f /q "C:\windows\temp\*"
del /q /f /q "C:\users\%username%\appdata\local\temp\*"

wevtutil cl application
wevtutil cl security
wevtutil cl system
takeown /f C:windows\logs\* /r /d y
icacls C:windows\logs\* /grant administrators:f /t
for /d %%x in (C:\windows\logs\*) do rd /s /q "%%x"
del /s /q C:\windows\logs\CBS\*
del /s /q C\windows\logs\DISM\*
del /f /s /q "C:\windows\prefetch\*.*"
del /f /s /q "%temp%\*.*"
del /f /s /q "C:\users\%username%\appdata\local\temp\*.*"
del /f /s /q "C:\Windows\Prefetch\*.*"
del /f /s /q "C:\users\%username%\appdata\roaming\microsoft\windows\recent\*.*"
del /f /s /q "C:\windows\temp\*.*"
del /f /s /q "C:\windows\temp\*.*"
del /f /s /q "C:\trix_cmd\cache\*"
del /f /s /q "C:\trix_cmd\2\temp_logs.txt
rd /s /q C:\$recycle.bin
taskkill /f /im explorer.exe & start explorer.exe
defrag 
msg "*" "limpeza rápida, conclúida!"
%menu%
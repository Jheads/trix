﻿@echo off 
@echo off
chcp 65001
echo realizando limpeza de arquivos temporários

del /q /f C:\windows\prefetch\*
del /f /s /q "C:\windows\prefetch\*.*"
del /f /s /q "%temp%\*.*"
del /f /s /q "C:\users\%username%\appdata\local\temp\*.*"
del /f /s /q "C:\Windows\Prefetch\*.*"
del /f /s /q "C:\users\%username%\appdata\roaming\microsoft\windows\recent\*.*"
del /f /s /q "C:\windows\temp\*.*"
del /f /s /q "C:\windows\temp\*.*"
del /f /s /q "C:\trix_cmd\cache\*"
del /f /s /q "C:\trix_cmd\2\temp_logs.txt

del /q /f /s %temp%\*
del /q /f /q "C:\users\%username%\appdata\local\temp\*"
del /q /f /q "C:\Windows\Prefetch\*"
del /q /f /q "C:\users\%username%\appdata\roaming\microsoft\windows\recent\*"
del /q /f /q "C:\windows\temp\*"
del /q /f /q "C:\users\%username%\appdata\local\temp\*"
timeout /t 2 >nul
echo > c:\trix_cmd\cache\s.txt
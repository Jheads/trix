@echo off
chcp 65001
:inicio
cls
echo =================================================================
echo parece que temos algum disco ou partição corrompida ou com erros
echo vou fazer o que posso para ajuadar!
echo[1] verificar disco
echo[2] voltar ao menu
echo =================================================================
echo digite 1 para ver se o disco aparece, se aparecer, então o problema pode ser em o disco estar corrompido.
set /p "vr=Selecione o disco para fazer a verificação (Ex: D:): "
if "%vr%"=="1" goto 1
if "%vr%"=="2" goto 2

for /f "tokens=* delims= " %%a in ("%vr%") do set vr=%%a
if not "%vr:~1,1%"==":" set "vr=%vr%:"

echo Você digitou: "%vr%"
pause

if exist "%vr%\*" (
    echo O disco foi encontrado!
    echo mesmo assim iremos agendar uma verificação só por preocaução do disco estar corrompido!
    chkdsk %vr% /f /r /x
    timeout /t 2 >nul
    goto inicio
) else (
    echo Erro: O disco %disk% não foi encontrado, ou não esta sendo lido!
    pause
    chkdsk %vr% /f /r /x
    timeout /t 2 >nul
    goto inicio
)
echo %vr% > "%USERPROFILE%\dados\status\vr.txt"
echo pressione qualquer tecla para voltar
pause >nul
goto inicio

:2
echo voltando.........
call c:\trix_cmd\2\backup.bat

:1
wmic logicaldisk get deviceid, volumename, description
echo pressione qualquer tecla para voltar
pause >nul
goto inicio
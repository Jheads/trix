﻿
set /p menu=<c:\trix_cmd\0\menu.txt
set preferencias=%userprofile%\dados\status\limpeza-preferencias
if not exist %preferencias%\tprefetch.txt echo > %preferencias%\prefetch.txt
if not exist %preferencias%\tfl.txt echo > %preferencias%\tfl.txt 
echo verificando trava das preferencias
net session >nul 2>&1
if %errorlevel% neq 0 (
   echo solicitando privilégios de adm...
   powershell -command "start-process cmd -argumentlist '/c \"%~f0\"' -verb runas"
   echo rodando com privilégios de administrador
   timeout /t 2 >nul
   exit
)
if exist %userprofile%\dados\status\limpeza-preferencias/config.txt (
    goto continue
    ) else ( 
    echo > C:\trix_cmd\cache\limpeza.txt
    call C:\trix_cmd\2\preferencias.bat
)
exit
:continue
echo iniciado com privilégios
echo 
cls
@echo off
chcp 65001
powershell remove-item C:\trix_cmd\cache -recurse -force
mkdir C:\trix_cmd\cache
color a
cls
if exist %userprofile%\dados\status\limpeza-preferencias\prefetch.txt (
   echo desligando prefetch
   reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v enableprefetcher /t REG_DWORD /d 0 /f
   sc config sysmain start= disabled
   sc stop sysmain 
) else (
  echo ignorando prefetch
  reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v enableprefetcher /t REG_DWORD /d 1 /f
  sc config sysmain start= disabled
  sc stop sysmain 
)
echo aguardando reinicialização 
echo limpeza de arquivos temporários...

timeout /t 5 >nul

ECHO VERIFICANDO PREFERENCIAS DA LIMPEZA...
if exist %userprofile%\dados\status\limpeza-preferencias\FL.txt goto fl

ECHO.
echo ETAPA [01/11]
ECHO.

echo forçando permissão de pasta em temp, isso pode demorar um pouco. aguarde...
takeown /f "C:\users\%username%\appdata\local\temp" /a /r /d y
icacls "C:\users\%username%\appdata\local\temp" /grant administrators:f /t /c /q
rd /s /q C:\users\%username%\appdata\local\temp
powershell remove-item C:\users\%username%\appdata\local\temp -recurse -force

ECHO.
echo ETAPA [02/11]
ECHO.
echo forçando permissão de pasta em prefetch, isso pode demorar um pouco. aguarde..
takeown /f "C:\Windows\Prefetch" /a /r /d y
icacls "C:\Windows\Prefetch" /grant administrators:f /t /c /q
rd /s /q C:\Windows\Prefetch\*
powershell remove-item C:\windows\prefetch\* -recurse -force

ECHO.
echo ETAPA [03/11]
ECHO.
echo forçando permissão de pasta em recent, isso pode demorar um pouco. aguarde.
takeown /f "C:\users\%username%\appdata\roaming\microsoft\windows\recent" /a /r /d y 
icacls "C:\users\%username%\appdata\roaming\microsoft\windows\recent" /grant adminstators:f /t /c /q
rd /s /q C:\users\%username%\appdata\roaming\microsoft\windows\recent
powershell remove-item C:\users\%username%\appdata\roaming\microsoft\windows\recent -recurse -force

ECHO.
echo ETAPA [04/11]
ECHO.
echo forçando permissão de pasta em aplication data, isso pode demorar um pouco. aguarde..
takeown /f "C:\users\%username%\appdata\local\aplication data" /a /r /d y
icacls "C:\users\%username%\appdata\local\aplication data" /grant administrators:f /t /c /q
rd /s /q C:\users\%username%\appdata\local\aplication data
powershell remove-item "C:\users\%username%\appdata\local\aplication data\*" -recurse -force

ECHO.
echo ETAPA [05/11]
ECHO.
echo forçando permissão de pasta em history , issso pode demorar um pouco. aguarde...
takeown /f "C:\users\%username%\appdata\local\history" /a /r /d y
icacls "C:\users\%username%\appdata\local\history" /grant administrators:f /t /c /q
rd /s /q C:\users\%username%\appdata\local\history
powershell remove-item "C:\users\%username%\appdata\local\history\*" -recurse -force

ECHO.
echo ETAPA [06/11]
ECHO.
echo forçando permissão de pasta em temporary, isso pode demorar um pouco. aguarde..
takeown /f "C:\users\%username%\appdata\local\microsoft\windows\temporary" /a /r /d y
icacls "C:\users\%username%\appdata\local\windows\temporary" /grant administrators:f /t /c /q
rd /s /q C:\users\%username%\appdata\local\microsoft\windows\temporary
powershell remove-item "C:\users\%username%\appdata\local\microsoft\windows\temporary\*" -recurse -force

ECHO.
echo ETAPA [07/11]
ECHO.
echo forçando permissão de pasta em cache internet, isso pode demorar um pouco. aguarde.
takeown /f "C:\users\%username%\appdata\local\temporary internet files" /a /r /d y
icacls "C:\users\%username%\appdata\local\temporary internet files" /grant administrators:f /t /c /q
rd /s /q C:\users\%username%\appdata\local\temporary internet files
powershell remove-item "C:\users\%username%\appdata\local\temporary internet files\*" -recurse -force

ECHO.
echo ETAPA [07/11]
ECHO.
echo forçando permissão de pasta em ngc, isso pode demorar um pouco. aguarde..
takeown /f "C:\windows\serviceprofiles\localservice\appdata\local\microsoft\ngc\" /a /r /d y
icacls "C:\windows\serviceprofiles\localservice\appdata\local\microsoft\ngc\" /grant administrators:f /t /c /q
rd /s /q C:\windows\serviceprofiles\localservice\appdata\local\microsoft\ngc\
powershell remove-item "C:\windows\serviceprofiles\localservice\appdata\local\microsoft\ngc\*" -recurse -force

ECHO.
echo ETAPA [08/11]
ECHO.
echo forçando permissão de pasta em content.ies, isso pode demorar um pouco. aguarde...
takeown /f "C:\windows\system32\config\systemprofile\appdata\local\microsoft\windows\inetcache\content.ies\" /a /r /d y
icacls "C:\windows\system32\config\systemprofile\appdata\local\microsoft\windows\inetcache\content.ies\" /grant administrators:f /t /c /q
rd /s /q C:\windows\system32\config\systemprofile\appdata\local\microsoft\windows\inetcache\content.ies\
powershell remove-item "C:\windows\system32\config\systemprofile\appdata\local\microsoft\windows\inetcache\content.ies\*" -recurse -force

ECHO.
echo ETAPA [09/11]
ECHO.
echo forçando permissão de pasta em rtbackup, isso pode demorar um pouco. aguarde..
takeown /f "C:\windows\system32\logfiles\wmi\rtbackup" /a /r /d y
icacls "C:\windows\system32\logfiles\wmi\rtbackup" /grant administrators:f /t /c /q
rd /s /q C:\windows\system32\logfiles\wmi\rtbackup

rd /s /q "C:\users\%username%\appdata\local\temp"
rd /s /q "C:\Windows\Prefetch"
rd /s /q "C:\users\%username%\appdata\roaming\microsoft\windows\recent"

ECHO.
echo ETAPA [10/11]
ECHO.
echo revisando permissões, aguarde...
takeown /f "C:\windows\prefetch"
takeown "%temp%"
takeown /f "C:\users\%username%\appdata\local\temp"
takeown /f "C:\Windows\Prefetch"
takeown /f "C:\users\%username%\appdata\roaming\microsoft\windows\recent"
takeown /f "C:\windows\temp"
takeown /f "C:\windows\temp"
ECHO.
:fl
echo =============================
echo         SUCESSO
ECHO =============================

ECHO.
echo ETAPA [11/11]
ECHO.
echo excluindo lixo das pastas permitidas
del /f /s /q "C:\windows\prefetch\*.*"
del /f /s /q "%temp%\*.*"
del /f /s /q "C:\users\%username%\appdata\local\temp\*.*"
del /f /s /q "C:\Windows\Prefetch\*.*"
del /f /s /q "C:\users\%username%\appdata\roaming\microsoft\windows\recent\*.*"
del /f /s /q "C:\windows\temp\*.*"
del /f /s /q "C:\windows\temp\*"
powershell remove-item "C:\windows\temp\*" -recurse -force
powershell remove-item "C:\Windows\Prefetch\*.*" -recurse -force
powershell remove-item "%temp%" -recurse -force

del /q /f /s %temp%\*
del /q /f /q "C:\users\%username%\appdata\local\temp\*"
del /q /f /q "C:\Windows\Prefetch\*"
del /q /f /q "C:\users\%username%\appdata\roaming\microsoft\windows\recent\*"
del /q /f /q "C:\windows\temp\*"
del /q /f /q "C:\users\%username%\appdata\local\temp\*"
powershell remove-item "C:\users\%username%\appdata\roaming\microsoft\windows\recent\*" -recurse -force

wevtutil cl application
wevtutil cl security
wevtutil cl system
takeown /f C:windows\logs\* /r /d y
icacls C:windows\logs\* /grant administrators:f /t
for /d %%x in (C:\windows\logs\*) do rd /s /q "%%x"
del /s /q C:\windows\logs\CBS\*
del /s /q C\windows\logs\DISM\*

net stop wuauserv 
rd /s /q C:\windows\softwaredistribution
net start wuauserv

wevtutil cl application
wevtutil cl system
wevtutil cl security
wevtutil cl setup
wevtutil cl forwardedevents
del /s /q /f "%TEMP%\*"
del /s /q /f  "C:\windows\temp\*"

echo limpando logs 
wevtutil el > temp_logs.txt
for /f "tokens=*" %%G IN (temp_logs.txt) DO (
     echo limpando log:%%G 
     wevtutil cl "%%G"
)
del temp_logs.txt
echo logs limpos

bcdedit /set testsigning off
echo ativando a tela novamente... 
echo pode demorar alguns minutos...


(
      echo verificando espaço livre e arquivos recentes...
      powershell -command "get-psdrive C | select-object free"
      echo.
      echo arquivos recentes no C:\powershell -command "get-childitem C:\ -recurse | sort-object lastwritetime -descending | select-object -first 20 fullname, length, lastwritetime"
) > C:\espaco_arquivos.txt
echo resultado salvo em C:\espaço_arquivos.txt

echo limpando cache do DNS...
color 4
ipconfig /flushdns

color 5
echo limpeza chkdsk

echo s | chkdsk C: /f /x >nul 2>&1 

echo aguardando reinicialização....

color 5
echo limpando arquivos temporários
color 4
del /q /f /s %temp%\*

color 4
echo reiniciando serviços
net stop wuauserv && net start wuauserv

color 5

del /f /s /q "C:\windows\prefetch\*.*"
del /f /s /q "%temp%\*.*"
del /f /s /q "C:\users\%username%\appdata\local\temp\*.*"
del /f /s /q "C:\Windows\Prefetch\*.*"
del /f /s /q "C:\users\%username%\appdata\roaming\microsoft\windows\recent\*.*"
del /f /s /q "C:\windows\temp\*.*"
del /f /s /q "C:\windows\temp\*.*"

echo ESSA AÇÃO SÓ LIMPARÁ O DISCO C
msg * "selecione todos os quadrados da limpeza de disco, os "arquivos a serem excluídos". não se preocupe isso não apagará nada importante, apenas arquivos inúteis"
msg * "clique em "limpar arquivos do sistema" e depois que carregar clique em "ok", se não tiver a opção "limpar arquivos do sistema" clique diretamente em "ok""
TIMEOUT /T 1 >NUL
echo SELECIONE TODOS OS QUADRADADOS DA LIMPEZA DE DISCO, OS "ARQUIVOS A SEREM EXCLUÍDOS". NÃO SE PREOCUPE ISSO NÃO APAGARÁ NADA IMPORTANTE, APENAS ARQUIVOS INÚTEIS"
ECHO CLIQUE EM "LIMPAR ARQUIVOS DO SISTEMA" DEPOIS QUE CARREGAR CLIQUE EM "OK", SE NÃO TIVER A OPÇÃO "LIMPAR ARQUIVOS DO SISTEMA "CLIQUE DIRETAMENTE EM "OK""
ECHO ==============================================================================
ECHO          CONCLÚIDO ETAPA 1/5 LIMPEZA DE DISCO
ECHO ==============================================================================
start "" cleanmgr /sageset:1
msg * "selecione todas as caixas para limpar completamente os arquivos temporários."
echo ESPERE A JANELA FECHAR PARA CONTINUAR
echo SE ESTIVER DEMORANDO MUITO PARA A JANELA FECHAR, PASSE O MOUSE POR CIMA DA JANELA, SE A LIMPEZA TRAVAR
ECHO CLIQUE AQUI [clique aqui] E PRESSIONE ENTER
ECHO ==============================================================================
ECHO          CONCLÚIDO ETAPA 2/5 LIMPEZA DE DISO
ECHO ==============================================================================
start "" cleanmgr /sagerun:1
start "" cleanmgr
ECHO ==============================================================================
ECHO          CONCLÚIDO ETAPA 3/5 LIMPEZA DE DISO
ECHO ==============================================================================
ECHO ESPERE A JANELA FECHAR PARA CONTINUAR
echo SE ESTIVER DEMORANDO MUITO PARA A JANELA FECHAR, PASSE O MOUSE POR CIMA DA JANELA, SE A LIMPEZA TRAVAR
ECHO CLIQUE AQUI [clique aqui] E PRESSIONE ENTER
TIMEOUT /T 2 >NUL
ECHO ==============================================================================
ECHO          CONCLÚIDO ETAPA 4/5 LIMPEZA DE DISCO
ECHO ==============================================================================
start "" cleanmgr /VERYLOWDISK
ECHO ==============================================================================
ECHO          CONCLÚIDO ETAPA 5/5 LIMPEZA DE DISCO
ECHO ==============================================================================
start "" cleanmgr /AUTOCLEAN
cleanmgr /sageset:655535 & cleanmgr /sagerun:65535
ECHO ==============================================================================
ECHO                      APAGANDO CACHE DA LIMPEZA.....
ECHO =============================================================================
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v PagingFiles /t REG_MULTI_SZ /d "" /f
powershell -Command "Set-WmiInstance -Class Win32_PageFileSetting -Arguments @{Name='C:\pagefile.sys'} -ErrorAction Ignore; Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name PagingFiles -Value ''"
ECHO ==============================================================================
ECHO [-------------------------------100%-----------------------------------------]          
ECHO ==============================================================================


ECHO CONCLUÍDO

echo limpando componentes antigos do windows update

if exist %preferencias%\cl.txt (
   echo ================================================================================
   echo [----------------------VERFICIANDO PREFERENCIAS--------------------------------] 
   ECHO ================================================================================
   timeout /t 2 >nul
   goto clskip
)
ECHO VERIFICANDO E CORRIGINDO ARQUIVOS CORROMPIDOS, IMAGEM DO WINDOWS E DESATIVANDO ARMAZENAMENTO RESERVADO DO SISTEMA ISSO PODE DEMORAR ALGUMAS HORAS...
dism /online /cleanup-image /startcomponentcleanup /quiet
dism /online /cleanup-image /startcomponentcleanup /resetbase
timeout /t 1 >nul
ECHO ==============================================================================
ECHO                 CORRIGINDO ARQUIVOS DO SISTEMA.
ECHO ==============================================================================
ECHO          CONCLÚIDO ETAPA 1/5 MANUTENÇÃO DE IMAGENS DE IMPORTAÇÃO
ECHO ==============================================================================
dism /online /cleanup-image /startcomponentcleanup /resetbase
timeout /t 1 >nul
ECHO ==============================================================================
ECHO          CONCLÚIDO ETAPA 2/5 MANUTENÇÃO DE IMAGENS DE IMPORTAÇÃO 
ECHO ==============================================================================
dism /online /cleanup-image /startcomponentcleanup /restorehealth
timeout /t 1 >nul
:clskip
ECHO ==============================================================================
ECHO          CONCLÚIDO ETAPA 3/5 DESATIVANDO ARMAZENAMENTO RESERVADO
ECHO ==============================================================================
dism /online /set-reservedstoragestate /state:disabled
ECHO ==============================================================================
ECHO          CONCLÚIDO ETAPA 4/5 ESPERANDO CONFIRMAÇÃO DE DESATIVAÇÃO...
ECHO ==============================================================================
dism /online /get-reservedstoragestate
ECHO ==============================================================================
ECHO          CONCLÚIDO ETAPA 5/5 CONFIRMAÇÃO EFETAUDA! CONCLUINDO....
ECHO ==============================================================================
timeout /t 3 >nul
ECHO ==============================================================================
ECHO [-------------------------------100%-----------------------------------------]          
ECHO ==============================================================================
ECHO CARREGANDO PRÓXIMO SERVIÇO DE LIMPEZA...
color 5

if exist %preferencias%\cl.txt goto clskip1
ECHO VERIFICANDO ARQUIVOS E CORRIGINDO
sfc /scannow
ECHO CONCLUÍDO
timeout /t 1 >nul
:clskip1
powercfg /hibernate off
echo desativando hibernação e inicialização rápida
color 4

ECHO AGENDANDO LIMPEZA AO INICIAR...
defrag C:

echo FORÇANDO MANUTENÇÃO OCIOSA 
Rundll32.exe advapi32.dll,ProcessIdleTasks

ECHO AJUSTANDO PRIORIDADE DA CPU
reg add HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl /v Win32PrioritySeparation /t REG_DWORD /d 38 /f

ECHO DEFININDO ALTO DESEMPENHO 
powercfg /setactive scheme_min

timeout /t 1 >nul

color 0A

rd /s /q C:\$recycle.Bin
del /f /s /q "C:\windows\prefetch\*.*"
del /f /s /q "%temp%\*.*"
del /f /s /q "C:\users\%username%\appdata\local\temp\*.*"
del /f /s /q "C:\Windows\Prefetch\*.*"
del /f /s /q "C:\users\%username%\appdata\roaming\microsoft\windows\recent\*.*"
del /f /s /q "C:\windows\temp\*.*"
del /f /s /q "C:\windows\temp\*.*"
echo =============================== LIMPEZA CONCLUIDA !!!!!!!!!!  ====================================

msg * "SERVIÇOS FINALIZADOS, FINALIZANDO TRIX!!!"
ECHO SERVIÇOS FINALIZADOS !!!
ECHO FINALIZANDO TRIX LIMPEZA
ECHO ABRINDO MENU DA LIMPEZA EM 20 SEGUNDOS
ECHO %COMPUTERNAME% ESTÁ QUASE LIMPO.
wmic computersystem where
name="%computername%" set
rd /s /q C:\$recycle.bin
taskkill /f /im explorer.exe & start explorer.exe
cls
set preferencias=%userprofile%\dados\status\limpeza-preferencias
if not exist %preferencias%\tconfig.txt (
   powershell remove-item %preferencias%\config.txt -recurse -force
)
if exist %preferencias%\rs.txt goto sim
if exist %preferencias%\rn.txt goto nao
echo =====================================================================================================
echo  AO CONTINUAR SEU COMPUTADOR SERÁ REINICIADO APÓS ALGUNS AVISOS PARA APLICAR COMPLETAMENTE A LIMPEZA.
echo =====================================================================================================
echo %nome% reiniciar o computador agora para finalizar a limpeza? pressione (S) para sim e (N) para não
set /p "opc= reinciar? "

if "%opc%"=="s" goto sim
if "%opc%"=="sim" goto sim
if "%opc%"=="n" goto nao 
if "%opc%"=="não" goto nao
if "%opc%"==="nao" goto nao

:nao
echo ok, a proxima vez que ele for desligado irei finalizar a limpeza.
echo voltando
timeout /t 2 >nul 
%menu%

:sim
echo entendido, em 10 segundos seu computador irá ser reiniciado, se tiver algo não salvo, salve-o
timeout /t 10 /nobreak
call C:\trix_cmd\2\informacoes.bat
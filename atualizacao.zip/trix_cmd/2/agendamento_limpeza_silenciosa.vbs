set objshell = createobject("wscript.shell")
objshell.run "C:\trix_cmd\2\alims.bat", 0, false
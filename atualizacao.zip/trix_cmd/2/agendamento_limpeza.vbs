set objshell = createobject("wscript.shell")
objshell.run "C:\trix_cmd\2\alimc.bat", 0, false
﻿@echo off
chcp 65001
set /p menu=<c:\trix_cmd\0\menu.txt
setlocal enabledelayedexpansion

set "configDir=C:\users\%username%\dados\config\status"
set "statusFile=%configDir%\status.txt"

if not exist "%configDir%" mkdir "%configDir%"
:menu
cls
echo ================ INICIAR LIMPEZA? =========================
echo [1] limpeza completa ( pode causar falhas em alguns apps)
echo [2] limpeza de cachê/rápida (limpeza padrão)
echo [3] limpar personalizações do sistema trix
echo [4] correção de imagem e arquivos corrompidos
echo [5] limpeza automática
echo [x] Não, voltar ao menu
echo ===========================================================
set /p opt=Escolha uma opção: 

if "%opt%"=="1" goto introducao
if "%opt%"=="2" goto lr
if "%opt%"=="3" goto 3
if "%opt%"=="4" goto 4
if /i "%opt%"=="x" goto back

echo Opção inválida!
pause
goto menu

:5
call c:\trix_cmd\2\limpeza_auto.bat
goto menu

:4
echo executando limpeza minima
cleanmgr
echo executando sfc scannow
sfc /scannow
echo executando dism
powershell DISM /Online /Cleanup-Image /RestoreHealthCopied!   
goto menu

:3
cls
echo reiniciando preferências, isso pode demorar um pouco...
set /p "opc=limpar preferências? (S\N)
if "%opc%"=="s" goto sp
if "%opc%"=="n" goto np

:np
cls
echo ok, voltando para as configurações...
timeout /t 3 >nul
pause
cls
goto menu

:sp
cls
del /s /q "C:\users\%username%\dados\pers\*.*" >nul
echo limpo com sucesso!
timeout /t 3 >nul 
pause
cls
goto menu

:lr
cls
echo iniciando limpeza rápida!
timeout /t 2 >nul
call c:\trix_cmd\2\limpeza_rapida.bat
cls
pause >nul
goto menu

:introducao
cls


if not exist "%statusFile%" (
    echo 1 > "%statusFile%"
    call C:\trix_cmd\2\2trix-introducao.bat
    goto limpeza
)

:pergunta_intro
cls
echo ========== Deseja ver a introdução novamente? =============
echo [1] Sim
echo [2] Não
echo ===========================================================
set /p inOpt=Escolha uma opção: 

if "%inOpt%"=="1" (
    call C:\trix_cmd\2\2trix-introducao.bat
    goto limpeza
) 
if "%inOpt%"=="2" goto limpeza

echo Opção inválida!
pause
goto pergunta_intro

:limpeza
cls
echo iniciando...
call C:\trix_cmd\2\2trix-limpeza.bat
timeout /t 2 >nul
goto menu

:back
if exist c:\trix_cmd\0\0_menu.bat (
  %menu%
)
exit

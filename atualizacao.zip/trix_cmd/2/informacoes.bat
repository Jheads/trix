@echo off
chcp 65001
echo verificando integridade dos códigos...
echo testando códigos...
setlocal enabledelayedexpansion

if exist "C:\trix_cmd\nome.txt" (
   for /f "usebackq delims=" %%a in ("C:\trix_cmd\nome.txt") do (
       set  nome=%%a
   )
)
echo nome: "%nome%"

for /F "tokens=1 delims=:" %%H in ("%TIME%") do (
    set hora=%%H
)
set hora=%hora: =%
if "%hora:~0,1%"=="0" set hora=%hora:~1%
set msg=Boa noite!
if %hora% GEQ 5 if %hora% LSS 12 set msg=Bom dia!
if %hora% GEQ 12 if %hora% LSS 18 set msg=Boa tarde!

echo %msg% %nome%
color 17

cls
echo caro %nome%, após o computador ser reiniciado ele pode entrar em uma tela azul. clique em "restart" ou "reiniciar" que ele terminará a limpeza, mas não se preocupe essa tela azul não afetará o computador e nem seus arquivos, ela faz parte da restauração da imagem do computador e ele poderá entrar em modo recovery para finalizar essa função. tenha um(a) %msg% e uma boa limpeza, até logo!
echo pressione qualquer tecla para iniciar a contagem de reinicialização. salve qualquer arquivo antes de reiniciar
pause
color 02
cls
echo iniciando contagem, se tiver algo não salvo, salve antes de reiniciar
timeout /t 20 >nul
shutdown /r /f /t 0

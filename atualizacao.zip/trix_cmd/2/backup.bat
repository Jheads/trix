@echo off
chcp 65001
set /p "c:\users\%username%\dados\nome\nome.txt"
set /p menu=<"c:\trix_cmd\0\menu.txt"
 
color 07
:inicio
cls
echo ================================
echo qual backup deseja fazer %nome%?
echo ================================
echo certifique-se de ter pelo menos 20gb livres para fazer os backups
echo [1]backup automático
echo [2]backup do windows
echo [3]backup dos dois
echo [4] fazer dowload do backup
echo [5]voltar ao menu
set /p "opc=escolha uma opção: "
if "%opc%"=="1" cls & goto 1
if "%opc%"=="2" cls & goto 2
if "%opc%"=="3" cls & goto 3
if "%opc%"=="4" cls & goto 4
if "%opc%"=="5" cls & goto 5
echo opção inválida, tente novamente
timeout /t 2 >nul
goto inicio

:1
cls
echo você tem algum ssd, hd ou pendrive para fazer o backup?
set /p "ssd=escolha S para sim e N para não(S/N): "
if /i "%ssd%"=="sim" goto s
if /i "%ssd%"=="s" goto s
if /i "%ssd%"=="nao" goto n
if /i "%ssd%"=="não" goto n
if /i "%ssd%"=="n" goto n
echo opção inválida, tente novamente!
timeout /t 2 >nul
goto 1

:s
setlocal enabledelayedexpansion

wmic logicaldisk get deviceid, volumename, description
echo.
echo Em qual desses discos você quer fazer o backup %nome%?
echo se não aparecer pode ser que seu ssd, hd ou pendrive esteja corrompido ou com problemas.
echo seu ssd, hd ou pendrive apareceu? 
set /p "per=S para sim N para não (S/N)"
if /i "%per%"=="sim" goto s1
if /i "%per%"=="s" goto s1
if /i "%per%"=="nao" call c:\trix_cmd\2\verificacao.bat
if /i "%per%"=="não" call c:\trix_cmd\2\verificacao.bat
if /i "%per%"=="n" call c:\trix_cmd\2\verficacao.bat

:S1
set /p "disk=Selecione o disco para fazer o backup (Ex: D:): "

for /f "tokens=* delims= " %%a in ("%disk%") do set disk=%%a
if not "%disk:~1,1%"==":" set "disk=%disk%:"

echo Você digitou: "%disk%"
pause

if exist "%disk%\*" (
    echo O disco foi encontrado!
) else (
    echo Erro: O disco %disk% não foi encontrado!
    pause
    goto 1
)

echo %disk% > "%USERPROFILE%\dados\status\backup.txt"

mkdir "%disk%\backup_trix"

xcopy "%APPDATA%" "%disk%\Backup_trix\AppData_Roaming" /E /I /H /Y
xcopy "%LOCALAPPDATA%" "%disk%\Backup_trix\AppData_Local" /E /I /H /Y
xcopy "%USERPROFILE%" "%disk%\Backup_trix\Perfil" /E /I /H /Y

echo Backup feito com sucesso!
pause
timeout /t 2 >nul
goto inicio

:n
echo desculpe, mas não será possivell fazer um backup sem um ssd, hd ou pendrive
timeout /t 2 >nul
goto inicio

:2
echo fazendo backup aguarde....
powershell -Command "Checkpoint-Computer -Description 'Ponto de Restauração' -RestorePointType 'MODIFY_SETTINGS'"
echo backup do windows feito com sucesso!
pause
timeout /t 2 >nul
goto inicio

:3
echo fazendo backup dos dois!
powershell -Command "Checkpoint-Computer -Description 'Ponto de Restauração' -RestorePointType 'MODIFY_SETTINGS'"
goto 1
timeout /t 2 >nul
goto inicio

:4
cls
echo ===========================
echo deseja manter o backup?
echo ===========================
echo [1] manter dados após fazer o backup
echo [2] excluir dados após fazer o backup

:1
xcopy "%disk%\Backup_trix\AppData_Roaming" "%APPDATA%" /E /I /H /Y
xcopy "%disk%\Backup_trix\AppData_Local" "%LOCALAPPDATA%" /E /I /H /Y
xcopy "%disk%\Backup_trix\Perfil" "%USERPROFILE%" /E /I /H /Y
echo Backup restaurado com sucesso!
pressione qualquer tecla para voltar ao menu
pause >nul
goto inicio

:2
echo fazendo dowload dos arquivos para o disco C!
echo procurando arquivos... 
robocopy "%disk%\Backup_trix\AppData_Roaming" "%APPDATA%" /E /MOVE /NFL /NDL
robocopy "%disk%\Backup_trix\AppData_Local" "%LOCALAPPDATA%" /E /MOVE /NFL /NDL
robocopy "%disk%\Backup_trix\Perfil" "%USERPROFILE%" /E /MOVE /NFL /NDL
echo backup feito e excluido, com sucesso!
pressione qualquer tecla para voltar ao menu
pause >nul
goto inicio

:5
echo voltando!
timeout /t 2 >nul
%menu%
echo algo deu errado...
timeout /t 2 >nul
goto incio

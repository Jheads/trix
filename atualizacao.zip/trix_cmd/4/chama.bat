if exist c:\trix_cmd\scrcpy-win64-v3.3.1 cd c:\trix_cmd\scrcpy-win64-v3.3.1 
if exist c:\trix_cmd\scrcpy-win64-v3.3.1 start c:\trix_cmd\scrcpy-win64-v3.3.1\start.bat 
if exist c:\trix_cmd\scrcpy-win32-v3.3.1 cd c:\trix_cmd\scrcpy-win32-v3.3.1 
if exist c:\trix_cmd\scrcpy-win32-v3.3.1 start c:\trix_cmd\scrcpy-win32-v3.3.1\start.bat 

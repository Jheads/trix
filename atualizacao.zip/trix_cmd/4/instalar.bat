@echo off
chcp 65001
:menu
cls
if not exist c:\trix_cmd\variavel (
   mkdir C:\trix_cmd\variavel
)
powershell remove-item c:\trix_cmd\*.zip -recurse -force
set /p vsr=<c:\trix_cmd\variavel\vsr.txt
set /p vssr=<c:\trix_cmd\variavel\vssr.txt
set /p vs=<c:\trix_cmd\0\vs.txt
set scpy32=c:\trix_cmd\scrcpy-win32-v3.3.1
set scpy64=c:\trix_cmd\scrcpy-win64-v3.3.1
set "pasta=C:\users\%username%\documents"
set "destino=%pasta%\rainmeter.zip"
set "link=https://github.com/joaoPHD/trix/raw/refs/heads/main/Rainmeter.zip"
set "adb=https://dl.google.com/android/repository/platform-tools-latest-windows.zip?hl=pt-br"
set "scrpy32=https://github.com/Genymobile/scrcpy/releases/download/v3.3.1/scrcpy-win32-v3.3.1.zip"
set "scrpy64=https://github.com/Genymobile/scrcpy/releases/download/v3.3.1/scrcpy-win64-v3.3.1.zip"
set dados=c:\users\%username%\dados
set conquistas=c:\trix_conquistas
set testes=c:\trix_cmd\testes
set trix=c:\trix_cmd
set /p menu=<C:\trix_cmd\0\menu.txt
set rainmeter=c:\users\%username%\documents\rainmeter
set jax=c:\users\%username%\documents\rainmeter\skins\#jaxcore
set scrpy=c:\ausencia
set mond=%rainmeter%\skins\mond
  =< \   
set ptbr=%userprofile%\dados\status\ptbr.txt
if exist c:\trix_cmd\scrcpy-win64-v%vs% (
   set scrpy=c:\trix_cmd\scrcpy-win64-v%vs%
   set scrpycc=c:\trix_cmd\scrcpy-win64-v%vs%\start.bat
)
if exist c:\trix_cmd\scrcpy-win32-v%vs% (
   set scrpy=c:\trix_cmd\scrcpy-win32-v%vs%
   set scrpycc=c:\trix_cmd\scrcpy-win32-v%vs%\start.bat
)
set destino=c:\trix_cmd
set adbc=c:\trix_cmd\platform-tools
set adbcc=c:\trix_cmd\platform-tools\start.bat
if exist %userprofile%\dados\status\5.txt (
   powershell remove-item %userprofile%\dados\status\5.txt -recurse -force
)
if exist %userprofile%\dados\status\6.txt (
   powershell remove-item %userprofile%\dados\status\6.txt -recurse -force
)
if exist c:\trix_cmd\Copyright\instalar.txt goto menu2
if not exist c:\trix_cmd\Copyright\instalar.txt (
   cls
   echo 1 > c:\trix_cmd\Copyright\instalar.txt
   echo.
   echo    seja bem vind%g% a loja da trix, iremos abrir um documento para 
   echo    esclarecer algumas informações sobre as implementações e copyrights da loja :)
   echo    aconselho que leia os termos para evitar processos desnecessários
   echo.
   pause
   echo.
   call c:\trix_cmd\Copyright\C.PDF
)
:menu2
color a
cls
ping -n 1 www.google.com >nul 2>nul
if errorlevel 1 (
   cls
   echo [SEM CONEXÃO COM INTERNET]
) else (
   echo [INTERNET DISPONÍVEL]
)
echo =========================
echo       instalar
echo =========================
if not exist %conquistas% echo [1] instalar conquistas
if not exist %dados% echo [2] instalar dados
if not exist %ptbr% echo [3] instalar rainmeter ptbr
if exist %ptbr% (
   if not exist %jax% (
      echo [4] instalar extensão jaxcore (rainmeter)
   )
)
if not exist %adbc% echo [5]instalar adb
if exist %adbc% (
   if not exist %adbcc% echo [5] instalar iniciador adb
)
if not exist %scrpy% echo [6]instalar scrcpy
if exist %scrpy% (
   if not exist %scrpycc% echo [6] instalar iniciador scrcpy
)
echo [x]voltar
echo ============================
set /p "opc=escolha uma opção: "
if "%opc%"=="1" goto net
if "%opc%"=="2" goto net
if "%opc%"=="3" goto net
if "%opc%"=="4" goto net
if "%opc%"=="5" goto ver
if "%opc%"=="6" goto ver
if "%opc%"=="7" goto net
if /i "%opc%"=="x" call c:\trix_cmd\4\loja.bat
echo opção inválida, tente novamente! 
timeout /t 2 >nul
goto menu2

:net 
ping -n 1 www.google.com >nul 2>nul
if errorlevel 1 (
   cls
   echo sem internet, tente novamente
   if exist %userprofile%\dados\status\6.txt powershell remove-item %userprofile%\dados\status\6.txt -recurse -force
   if exist %userprofile%\dados\status\5.txt powershell remove-item %userprofile%\dados\status\5.txt -recurse -force
   timeout /t 2 >Nul
   goto menu2
) else (
   if exist %userprofile%\dados\status\6.txt start c:\trix_cmd\4\verificacao.bat & exit
   if exist %userprofile%\dados\status\5.txt start c:\trix_cmd\4\verificacao.bat & exit
   goto %opc%
)
echo erro de caminho
timeout /t 2 >nul
goto menu2

:ver
echo %opc% > %userprofile%\dados\status\%opc%.txt
goto net

:3
if exist %ptbr% (
   echo rainmeter ptbr já esta instalado, se estiver com problemas o desinstale e instale novamente
   echo limpando cache...
   timeout /t 4 >nul
   goto cache
)
if not exist "c:\program files\rainmeter\rainmeter.exe" (
   curl -L -o "c:\trix_cmd\rainmeter-%vsr%.exe" "https://github.com/rainmeter/rainmeter/releases/download/v%vssr%/Rainmeter-%vsr%.exe"
   start "" "c:\trix_Cmd\rainmeter-%vsr%.exe"
)
:exe
if not exist "c:\program files\rainmeter\rainmeter.exe" (
   pause
   goto exe
)
if not exist %mond% (
   curl -L -o "c:\trix_cmd\mond.rmskin" "https://visualskins.com/media/p/565/mond.rmskin"
   start "" "c:\trix_Cmd\mond.rmskin"
)
:mond
if not exist %mond% (
   pause
   goto mond
)
taskkill /im rainmeter.exe /f
curl -L -o "c:\trix_cmd\rainmeter.zip" "https://github.com/joaoPHD/trix/raw/refs/heads/main/Rainmeter.zip"
powershell remove-item %userprofile%\documents\rainmeter\skins\mond\@resources\language\english.inc -recurse -force
powershell -command "expand-archive" 'c:\trix_cmd\Rainmeter.zip' -destinationpath  '%userprofile%\documents\rainmeter\skins\mond\@resources\language' -force"
powershell -command "expand-archive" 'c:\trix_cmd\Rainmeter.zip' -destinationpath  '%userprofile%\dados' -force"
:cache
if exist %userprofile%\dados\english.inc (
   echo 1 > %userprofile%\dados\status\ptbr.txt 
   powershell remove-item %userprofile%\dados\english.inc -recurse -force
)
if exist c:\trix_cmd\rainmeter.zip powershell remove-item -path c:\trix_cmd\rainmeter.zip -recurse -force
if exist %userprofile%\documents\rainmeter.zip powershell remove-item -path %userprofile%\documents\rainmeter.zip -recurse -force
if exist c:\trix_cmd\mond.rmskin powershell remove-item c:\trix_cmd\mond.rmskin -recurse -force
if exist c:\trix_cmd\rainmeter-%vsr%.exe powershell remove-item c:\trix_cmd\rainmeter-%vsr%.exe -recurse -force
echo pacote ptbr instalado!
start "" "c:\program files\rainmeter\rainmeter.exe"
timeout /t 2 >nul
goto menu2

:4
echo Y | powershell -ExecutionPolicy Bypass -Command "iwr -UseBasicParsing 'https://raw.githubusercontent.com/Jax-Core/JaxCore/master/CoreInstaller.ps1' | iex"
goto menu2

:1
mkdir %conquistas%
echo instalado!
goto menu2

:2
mkdir %dados%
echo instalado!
goto menu2
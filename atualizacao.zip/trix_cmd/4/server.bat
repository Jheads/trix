@echo off
set /p menu=<c:\trix_cmd\0\menu.txt
taskkill /im adb.exe /f & start adb.exe
%menu%
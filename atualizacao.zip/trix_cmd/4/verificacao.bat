@echo off
chcp 65001
:menu
if not exist c:\trix_cmd\variavel (
   mkdir C:\trix_cmd\variavel
)
powershell remove-item c:\trix_cmd\*.zip -recurse -force
set /p vs=<c:\trix_cmd\0\vs.txt
set scpy32=c:\trix_cmd\scrcpy-win32-v3.3.1
set scpy64=c:\trix_cmd\scrcpy-win64-v3.3.1
set "pasta=C:\users\%username%\documents"
set "destino=%pasta%\rainmeter.zip"
set "link=https://github.com/joaoPHD/trix/raw/refs/heads/main/Rainmeter.zip"
set "adb=https://dl.google.com/android/repository/platform-tools-latest-windows.zip?hl=pt-br"
set "scrpy32=https://github.com/Genymobile/scrcpy/releases/download/v3.3.1/scrcpy-win32-v3.3.1.zip"
set "scrpy64=https://github.com/Genymobile/scrcpy/releases/download/v3.3.1/scrcpy-win64-v3.3.1.zip"
set dados=c:\users\%username%\dados
set conquistas=c:\trix_conquistas
set testes=c:\trix_cmd\testes
set trix=c:\trix_cmd
set /p menu=<C:\trix_cmd\0\menu.txt
set rainmeter=c:\users\%username%\documents\rainmeter
set ptbr=%rainmeter%\skins\mond\@resources\language\ptbr.inc
set jax=c:\users\%username%\documents\rainmeter\skins\#jaxcore
set scrpy=c:\ausencia
set mond=%rainmeter%\skins\mond
set destino=c:\trix_cmd
set adbc=c:\trix_cmd\platform-tools\start.bat

if exist c:\trix_cmd\scrcpy-win64-v%vs% (
   set scrpy=c:\trix_cmd\scrcpy-win64-v%vs%
)
if exist c:\trix_cmd\scrcpy-win32-v%vs% (
   set scrpy=c:\trix_cmd\scrcpy-win32-v%vs%
)
:ver
if exist %userprofile%\dados\status\5.txt (
   if exist %scrpy% goto 2
   goto s
)
if exist %userprofile%\dados\status\6.txt ( 
   if exist c:\trix_cmd\platform-tools goto 1
   goto zz
)
goto menu2
cls

:1
cls
echo adb está instalado, pode haver conflito entre pacotes
echo desinstale o adb se houver falhas
echo.
echo [1] sim
echo [2] não
set /p oop=deseja instalar mesmo assim? 
if "%oop%"=="1" goto zz
if "%oop%"=="2" goto menu2
echo opção inválida, tente novamente
timeout /t 2 >nul
goto 1

:2
cls
color 4
echo scrcpy está instalado, pode haver conflito entre pacotes
echo desinstale-o se houver falhas
echo.
echo [1] sim
echo [2] não
set /p oop=deseja instalar mesmo assim? 
if "%oop%"=="1" goto s
if "%oop%"=="2" goto menu2
echo opção inválida, tente novamente
timeout /t 2 >nul
goto 2

:3
cls
color 4
echo scrcpy está instalado, pode haver conflito entre pacotes
echo desinstale-o se houver falhas
echo.
echo [1] sim
echo [2] não
set /p opc=deseja instalar mesmo assim? 
if "%opc%"=="1" goto s
if "%opc%"=="2" goto menu2
echo opção inválida, tente novamente
timeout /t 2 >nul
goto 3

:s
call c:\trix_cmd\4\adb.bat
:zz
call c:\trix_cmd\4\scpy.bat
:menu2
call c:\trix_cmd\4\instalar.bat
@echo off
chcp 65001
if not exist c:\trix_cmd\variavel (
   mkdir C:\trix_cmd\variavel
)
powershell remove-item c:\trix_cmd\*.zip -recurse -force
set /p vs=<c:\trix_cmd\0\vs.txt
set scpy32=c:\trix_cmd\scrcpy-win32-v3.3.1
set scpy64=c:\trix_cmd\scrcpy-win64-v3.3.1
set "pasta=C:\users\%username%\documents"
set "destino=%pasta%\rainmeter.zip"
set "link=https://github.com/joaoPHD/trix/raw/refs/heads/main/Rainmeter.zip"
set "adb=https://dl.google.com/android/repository/platform-tools-latest-windows.zip?hl=pt-br"
set "scrpy32=https://github.com/Genymobile/scrcpy/releases/download/v3.3.1/scrcpy-win32-v3.3.1.zip"
set "scrpy64=https://github.com/Genymobile/scrcpy/releases/download/v3.3.1/scrcpy-win64-v3.3.1.zip"
set dados=c:\users\%username%\dados
set conquistas=c:\trix_conquistas
set testes=c:\trix_cmd\testes
set trix=c:\trix_cmd
set /p menu=<C:\trix_cmd\0\menu.txt
set rainmeter=c:\users\%username%\documents\rainmeter
set ptbr=%rainmeter%\skins\mond\@resources\language\ptbr.inc
set jax=c:\users\%username%\documents\rainmeter\skins\#jaxcore
set scrpy=c:\ausencia
set mond=%rainmeter%\skins\mond
if exist c:\trix_cmd\scrcpy-win64-v3.3.1 (
   set scrpy=c:\trix_cmd\scrcpy-win64-v3.3.1
)
if exist c:\trix_cmd\scrcpy-win32-v3.3.1 (
   set scrpy=c:\trix_cmd\scrcpy-win32-v3.3.1
)
set destino=c:\trix_cmd
set adbc=c:\trix_cmd\platform-tools\start.bat

cls
if exist %destino%\platform-tools\start.bat (
   echo opção inválida, tente novamente
   echo adb já está instalado em c:\trix_cmd\platform-tools
   pause
   goto menu
)
curl -L -o "%destino%\platform-tools-latest-windows.zip" "%adb%"
tar -xf %destino%\platform-tools-latest-windows.zip -C c:\trix_cmd
if exist %destino%\platform-tools-latest-windows.zip (
   powershell remove-item %destino%\platform-tools-latest-windows.zip -recurse -force 
)
curl -L -o "%destino%\platform-tools\start-adb.zip" "https://github.com/joaoPHD/trix/raw/refs/heads/main/start-adb.zip"
tar -xf %destino%\platform-tools\start-adb.zip -C c:\trix_cmd\platform-tools
if exist "%destino%\platform-tools\start-adb.zip" (
   powershell remove-item "%destino%\platform-tools\start-adb.zip" -recurse -force 
)
if not exist c:\trix_cmd\platform-tools (
   echo erro de download
   goto menu
)
echo adb foi instalado!
timeout /t 2 >nul
:menu
call c:\trix_cmd\4\instalar.bat

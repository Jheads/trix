@echo off 
chcp 65001
set /p menu=<c:\trix_cmd\0\menu.txt
if not exist c:\trix_cmd\jogos mkdir c:\trix_cmd\jogos

:menu
cls
call echo todos os jogos não são de
call echo TRX company, cada jogo é 
call echo instalado de uma distribuidora
call echo open-source ou não
pause
cls
:jogos
call echo ===========================
call echo      MENU DE JOGOS
call echo ===========================
call echo [1] ver jogos 
call echo [2] instalar jogos
call echo [3] desinstalar jogo
call echo [x] voltar
call echo ===========================
set /p "opc=> "
if "%opc%"=="2" call c:\trix_cmd\4\jogos.bat
if "%opc%"=="1" call c:\trix_cmd\4\jogos-instalados.bat
if "%opc%"=="3" call c:\trix_cmd\4\jogos-unin.bat
if /i "%opc%"=="x"
call echo opção inválida, tente novamente
goto jogos

@echo off
chcp 65001
:menu
cls
if not exist c:\trix_cmd\variavel (
   mkdir C:\trix_cmd\variavel
)
set "pasta=C:\users\%username%\documents"
set "destino=%pasta%\rainmeter.zip"
set "link=https://github.com/joaoPHD/trix/raw/refs/heads/main/Rainmeter.zip"
set "adb=https://dl.google.com/android/repository/platform-tools-latest-windows.zip?hl=pt-br"
set "scrpy32=https://github.com/Genymobile/scrcpy/releases/download/v3.3.1/scrcpy-win32-v3.3.1.zip"
set "scrpy64=https://github.com/Genymobile/scrcpy/releases/download/v3.3.1/scrcpy-win64-v3.3.1.zip"
set dados=c:\users\%username%\dados
set conquistas=c:\trix_conquistas
set testes=c:\trix_cmd\testes
set trix=c:\trix_cmd
set /p menu=<C:\trix_cmd\0\menu.txt
set rainmeter=c:\users\%username%\documents\rainmeter
set ptbr=%userprofile%\dados\status\ptbr.txt
set jax=c:\users\%username%\documents\rainmeter\skins\#jaxcore
set scrpy=c:\ausente
if exist c:\trix_cmd\scrcpy-win64-v3.3.1 (
   set scrpy=c:\trix_cmd\scrcpy-win64-v3.3.1
)
if exist c:\trix_cmd\scrcpy-win32-v3.3.1 (
   set scrpy=c:\trix_cmd\scrcpy-win32-v3.3.1
)
set destino=c:\trix_cmd
set adbc=c:\trix_cmd\platform-tools

:menu1
color c
cls
echo =========================
echo       desinstalar
echo =========================
echo [1] desinstalar trix
if exist %testes% echo [2] remover testes
if exist %conquistas% echo [3] reiniciar conquistas
if exist %dados% echo [4] reiniciar dados
if exist %rainmeter% echo [5]desinstalar rainmeter
if exist %rainmeter% (
   if exist %jax% (
      echo [6] desinstalar extensão jaxcore 
   )
)
if exist %scrpy% echo [7] desinstalar scrpy
if exist %adbc% echo [8] desinstalar adb
echo [x] voltar
echo =========================
echo instalados:
echo ========================
if exist %dados% echo dados estão normais
if exist %conquistas% echo conquistas está instalada
if exist %testes% echo testes estão instalados
if exist %ptbr% echo Rainmeter em ptbr já está instalado
if exist %jax% echo Jaxcore está instalado
if exist %scpry% echo Scrpy está instalado
if exist %adbc% echo Adb está instalado
echo =============================
echo desinstalados:
echo =============================
if not exist %rainmeter% echo Rainmeter não está instalado
if exist %rainmeter% (
   if not exist %jax% echo jaxcore não está instalado
)
if not exist %dados% echo dados já foi exclúido
if not exist %conquistas%  echo conquistas já foram excluidas
if not exist %testes% echo testes já foram exclúidos
if not exist %adbc% echo adb não está instalado
if not exist %scrpy% echo scrpy não está instalado
echo ============================

set /p "opc=escolha uma opção: "
if "%opc%"=="1" goto 1
if "%opc%"=="2" goto 2
if "%OPC%"=="3" goto 3
if "%opc%"=="4" goto 4
if "%opc%"=="5" goto 5
if "%opc%"=="6" goto 6
if "%opc%"=="7" goto 7
if "%opc%"=="8" goto 8
if /i "%opc%"=="x" call c:\trix_cmd\4\loja.bat
echo opção inválida, tente novamente! 
timeout /t 2 >nul
goto menu1

:7
taskkill /im adb.exe /f
echo desinstalando scrcpy...
if not exist c:\trix_cmd\scrcpy-win64-v3.3.1 (
   if not exist c:\trix_cmd\scrcpy-win32-v3.3.1 (
      echo opção inválida, scrcpy não está no sistema
      goto ffff
   )
)
if not exist c:\trix_cmd\scrcpy-win32-v3.3.1 (
   if not exist c:\trix_cmd\scrcpy-win64-v3.3.1 (
       echo opção inválida, scrcpy não está no sistema
       goto ffff
   )
)

if exist c:\trix_cmd\scrcpy-win64-v3.3.1 (
   powershell remove-item c:\trix_cmd\scrcpy-win64-v3.3.1 -recurse -force
)
if exist c:\trix_cmd\scrcpy-win32-v3.3.1 (
   powershell remove-item c:\trix_cmd\scrcpy-win32-v3.3.1 -recurse -force
)
:ffff
timeout /t 2 >nul
goto menu

:8
echo desinstalando adb
timeout /t 2 >nul
taskkill /im adb.exe /f
takeown /f "c:\trix_cmd\platform-tools\*" /r /d y
powershell remove-item c:\trix_cmd\platform-tools -recurse -force
goto menu

:2
powershell remove-item -path "%testes%" -recurse -force
%final%
goto menu1

:3
powershell remove-item -path "%conquistas%" -recurse -force
%final%
goto menu1

:4
powershell remove-item -path "%dados%" -recurse -force
goto menu1

:5
powershell remove-item %ptbr% -recurse -force
start "" "c:\program files\rainmeter\uninst.exe
if exist %rainmeter% powerhsell remove-item -path c:\users\%username%\documents\rainmeter -recurse -force
goto menu1

:6
takeown /f "%userprofile%\Documents\Rainmeter" /r /d y
icacls "%userprofile%\Documents\Rainmeter" /grant "%username%:F" /t
taskkill /f /im Rainmeter.exe
powershell remove-item -path c:\users\%username%\documents\rainmeter\* -recurse -force
takeown /f "%userprofile%\Documents\Rainmeter" /r /d y
icacls "%userprofile%\Documents\Rainmeter" /grant "%username%:F" /t
taskkill /f /im Rainmeter.exe
curl -L -o "%destino%" "%link%"
powershell -Command "Expand-Archive -Path '%destino%' -DestinationPath '%pasta%' -Force"
tar -xf %destino% -C %pasta%
start "" "C:\program files\rainmeter\rainmeter.exe"
cls
powershell remove-item -path c:\users\%username%\documents\rainmeter.zip -recurse -force
echo pacote ptbr instalado!
echo abra o rainmeter e mude a linguagem de inglês para ptbr
timeout /t 2 >nul
goto menu1

:1
powershell remove-item -path "%dados%" -recurse -force
echo dados do usuario excluidos
powershell remove-item -path "%conquistas%" -recurse -force
echo conquistas removidas
echo deletado
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v enableprefetcher /f
echo habilitando...
reg add "hkey_local_machine\system\currentcontrolset\control\session manager\memory management\prefetchparameters" /v enableprefetcher /t reg_dword /d 3 /f
sc config sysmain start=auto 
echo ativando prefetch
schtasks /delete /tn "limpezaauto" /f
echo removendo limpeza automatica...
:delete
rd /q c:\trix_cmd
powershell remove-item -path "c:\trix_cmd" -recurse -force
if exist c:\trix_cmd goto delete
echo deletando trix...
if not exist "%trix%" echo trix desinstalada, reinicie seu computador para aplicar as mudanças! até logo!
pause
exit 

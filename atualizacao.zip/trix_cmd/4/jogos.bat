@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo opção em teste
echo pirataria não será aceita por direitos autorais
tiemout /t 2 >nul
:pesquisa
set /p menu=<c:\trix_cmd\0\menu.txt
cls
call echo [OPÇÃO EM TESTE]
call echo ========================================================
call echo              JOGOS DISPONÍVEIS
call echo ========================================================
call echo [x] voltar
call echo [T] ver todos os jogos
call echo ========================================================
set "pasta=C:\trix_cmd\biblioteca-jogos"
echo escreva "/help" se precisar de ajuda
set /p filtro="Digite letra ou palavra da opção que deseja procurar: "
set contador=1

if /i "%filtro%"=="/help" goto help
if /i "%filtro%"=="x" echo voltando..... & timeout /t 2 >nul & %menu%
if /i "%filtro%"=="t" (
   if not exist "c:\trix_cmd\biblioteca-jogos\*.txt" (
      call echo [BIBLIOTECA DE JOGOS VAZIA]
      dir /b "%pasta%\*.txt"
      goto pesquisa
   )
)
:: Lista arquivos filtrados e numera
for /f "delims=" %%f in ('dir /b "%pasta%\*.txt" ^| findstr /i "%filtro%"') do (
    echo [!contador!] %%~nf
    set "arquivo[!contador!]=%%f"
    set /a contador+=1
)

:: Se não encontrou nenhum arquivo
if %contador%==1 (
    echo Nenhum jogo encontrado com "%filtro%"
    timeout /t 2 >nul
    goto pesquisa
)

:: Pede para o usuário escolher o número
set /p escolha="Escolha o numero do arquivo: "

:: Lê o arquivo correspondente e coloca em uma variável

set "arquivoEscolhido=!arquivo[%escolha%]!"
set "arquivocaminho=c:\trix_cmd\biblioteca-jogos\!arquivo[%escolha%]!"
set /p arquiv=<c:\trix_cmd\biblioteca-jogos\!arquivo[%escolha%]!

if exist "!arquivocaminho!" (
    set /p conteudo=<"!arquivoEscolhido!"
    echo indo ao destino...
    timeout /t 2 >nul
    START "" "%arquiv%"
) else (
    echo Numero invalido ou arquivo nao encontrado
    timeout /t 2 >nul
)
goto pesquisa
:help
cls
echo =============================================
echo                 AJUDA
ECHO =============================================
echo pesquise o nome da opção ou a letra de inicio
echo.
echo                   MENU
echo.
echo para voltar ao menu escreva menu
echo.
echo escreva T para ver todos as opções,
echo.
echo opção em desenvolvimento, poderá haver bugs
echo.
echo   [pressione qualquer tecla para voltar]
pause >nul
goto pesquisa
@echo off
chcp 65001 >nul
:menu0
set "pasta=C:\users\%username%\documents"
set "destino=%pasta%\rainmeter.zip"
set "link=https://github.com/joaoPHD/trix/raw/refs/heads/main/Rainmeter.zip"
set dados=c:\users\%username%\dados
set conquistas=c:\trix_conquistas
set testes=c:\trix_cmd\testes
set trix=c:\trix_cmd
set /p menu=<C:\trix_cmd\0\menu.txt
set rainmeter=c:\users\%username%\documents\rainmeter
set ptbr=%rainmeter%\skins\mond\@resources\language\ptbr.inc
set jax=c:\users\%username%\documents\rainmeter\skins\#jaxcore
set scrpy=c:\trix_cmd\scrpy\start.bat
set adb=c:\trix_cmd\abd\start.bat
 
color 3
cls
:loja
echo ========================
echo        LOJA
echo ========================
echo [1] jogos
echo [2] componentes
echo [x] voltar ao menu
echo ========================
set /p "lj=> "
if /i "%lj%"=="1" call c:\trix_cmd\4\menu-jogos.bat
if /i "%lj%"=="2" goto com
if /i "%lj%"=="x" echo voltando.... & timeout /t 2 >nul & %menu%
echo opção inválida, tente novamente
timeout /t 2 >nul
goto loja
:com
cls
echo ========================
echo      componentes
echo ========================
echo [1] desinstalar componentes
echo [2] instalar componentes
echo [x] voltar ao menu
echo =========================
if /i "%opc%"=="x" echo voltando.... & timeout /t 2 >nul & %menu%
echo instalados:
echo ========================
if exist %dados% echo dados estão normais
if exist %conquistas% echo conquistas está instalada
if exist %testes% echo testes estão instalados
if exist %ptbr% echo Rainmeter em ptbr já está instalado
if exist %jax% echo Jaxcore está instalado
if exist %adb% echo adb está instalado
if exist %scrpy% echo scrpy está instalado
echo =============================
echo desinstalados:
echo =============================
if not exist %rainmeter% echo Rainmeter não está instalado
if exist %rainmeter% (
   if not exist %jax% echo jaxcore não está instalado
)
if not exist %scrpy% echo scrpy não está instalado
if not exist %adb% echo adb não está instalado
if not exist %dados% echo dados já foi exclúido
if not exist %conquistas%  echo conquistas já foram excluidas
if not exist %testes% echo testes já foram exclúidos
echo ============================
set /p "opc=escolha uma opção: "
if "%opc%"=="1" call c:\trix_cmd\4\desinstalar.bat
if "%opc%"=="2" call c:\trix_cmd\4\instalar.bat
if /i "%opc%"=="x" echo voltando.... & timeout /t 2 >nul & %menu%
echo opção inválida, tente novamente
timeout /t 2 >nul
goto com
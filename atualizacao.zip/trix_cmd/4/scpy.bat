@echo off
chcp 65001
if not exist c:\trix_cmd\variavel (
   mkdir C:\trix_cmd\variavel
)
powershell remove-item c:\trix_cmd\*.zip -recurse -force
set /p vs=<c:\trix_cmd\0\vs.txt
set scpy32=c:\trix_cmd\scrcpy-win32-v3.3.1
set scpy64=c:\trix_cmd\scrcpy-win64-v3.3.1
set "pasta=C:\users\%username%\documents"
set "destino=%pasta%\rainmeter.zip"
set "link=https://github.com/joaoPHD/trix/raw/refs/heads/main/Rainmeter.zip"
set "adb=https://dl.google.com/android/repository/platform-tools-latest-windows.zip?hl=pt-br"
set "scrpy32=https://github.com/Genymobile/scrcpy/releases/download/v3.3.1/scrcpy-win32-v3.3.1.zip"
set "scrpy64=https://github.com/Genymobile/scrcpy/releases/download/v3.3.1/scrcpy-win64-v3.3.1.zip"
set dados=c:\users\%username%\dados
set conquistas=c:\trix_conquistas
set testes=c:\trix_cmd\testes
set trix=c:\trix_cmd
set /p menu=<C:\trix_cmd\0\menu.txt
set rainmeter=c:\users\%username%\documents\rainmeter
set ptbr=%rainmeter%\skins\mond\@resources\language\ptbr.inc
set jax=c:\users\%username%\documents\rainmeter\skins\#jaxcore
set scrpy=c:\ausencia
set mond=%rainmeter%\skins\mond

set "psScript=%TEMP%\CreateShortcut.ps1"
set "statusFile=C:\Users\%USERNAME%\dados\status\status.txt"
set "shortcutName=scrcpy.lnk"
set "desktop=%USERPROFILE%\Desktop"
set "statusFolder=C:\Users\%USERNAME%\dados\status"
set "lockFile=%statusFolder%\script.lock"
set "atalho=%desktop%\%shortcutName%"
set "atalhoAtivo=%USERPROFILE%\dados\pers\atalho-ativo.txt"
set "atalhoDesativo=%USERPROFILE%\dados\pers\atalho-desativo.txt"
set "inicial=%APPDATA%\Microsoft\Windows\Start Menu\Programs\"
if exist c:\trix_cmd\scrcpy-win64-v%vs% (
   set scrpy=c:\trix_cmd\scrcpy-win64-v%vs%
   set "targetPath=c:\trix_cmd\scrcpy-win64-v%vs%\scrcpy.exe"
)
if exist c:\trix_cmd\scrcpy-win32-v%vs% (
   set scrpy=c:\trix_cmd\scrcpy-win32-v%vs%
   set "targetPath=c:\trix_cmd\scrcpy-win32-v%vs%\scrcpy.exe"
)
set destino=c:\trix_cmd
set adbc=c:\trix_cmd\platform-tools\start.bat

:menu0
taskkill /im adb.exe /f
if exist c:\trix_cmd\scrcpy-win32-v%vs% (
   powershell remove-item -path c:\trix_cmd\scrcpy-win32-v%vs% -recurse -force
)
if exist c:\trix_cmd\scrcpy-win64-v%vs% (
   powershell remove-item -path c:\trix_cmd\scrcpy-win64-v%vs% -recurse -force
)

cls
echo =============================
echo seu computador é:
wmic os get osarchitecture
echo ============================
echo [1] scrcpy 64 bits
echo [2] scrcpy 32 bits
echo ============================
echo aviso: algumas versões android podem não funcionar no scrcpy
echo versões como, android 8 abaixo, androids 32 bits e 
echo androids Go version
set /p "opca=escolha qual scrcpy é compativel com seu computador 
if "%opca%"=="1" goto 64 
if "%opca%"=="2" goto 32
echo opção inválida, tente novamente
timeout /t 2 >nul
goto menu0

:64
cls
echo 64 > c:\trix_cmd\variavel\vs.txt
if exist %scpy64% (
   takeown /f "%scpy32%" /r /d y
   icacls "%scpy32%" /grant "%scpy32%:F" /t
   if exist %scpy32% powershell remove-item -path %scpy32% -recurse -force
   echo scrcpy já está instalado, verificando instalador...
   goto sta
)
curl -L -o "%scpy64%.zip" "%scrpy64%"
echo 1 > c:\trix_cmd\variavel\64.txt
tar -xf %scpy64%.zip -C c:\trix_cmd
if exist %scpy64%.zip (
   powershell remove-item -path %scpy64%.zip -recurse -force
)
if not exist %scpy64% (
   echo erro ao instalar
   powershell remove-item c:\trix_cmd\variavel\vs.txt -recurse -force
)
echo scrcpy 64 bits instalado
timeout /t 2 >nul
goto sta

:sta
cls
if exist c:\trix_cmd\scrcpy-win64-v%vs%\start.bat (
   powershell remove-item c:\trix_cmd\scrcpy-win64-v%vs%\start.bat -recurse -force
)
if exist c:\trix_cmd\scrcpy-win32-v%vs%\start.bat ( 
   powershell remove-item c:\trix_cmd\scrcpy-win32-v%vs%\start.bat -recurse -force
)
if exist c:\trix_cmd\4\chama.bat (
   powershell remove-item c:\trix_cmd\4\chama.bat -recurse -force
)
if exist c:\trix_cmd\scrcpy-win64-v%vs% (
   echo if exist c:\trix_cmd\scrcpy-win64-v%vs% cd c:\trix_cmd\scrcpy-win64-v%vs% >> c:\trix_cmd\4\chama.bat
   echo if exist c:\trix_cmd\scrcpy-win64-v%vs% start c:\trix_cmd\scrcpy-win64-v%vs%\start.bat >> c:\trix_cmd\4\chama.bat
   echo if exist c:\trix_cmd\scrcpy-win32-v%vs% cd c:\trix_cmd\scrcpy-win32-v%vs% >> c:\trix_cmd\4\chama.bat
   echo if exist c:\trix_cmd\scrcpy-win32-v%vs% start c:\trix_cmd\scrcpy-win32-v%vs%\start.bat >> c:\trix_cmd\4\chama.bat

   echo @echo off >> c:\trix_cmd\scrcpy-win64-v%vs%\start.bat
   echo chcp 65001 >> c:\trix_cmd\scrcpy-win64-v%vs%\start.bat
   echo cls >> c:\trix_cmd\scrcpy-win64-v%vs%\start.bat
   echo cd c:\trix_cmd\scrcpy-win64-v%vs% >> c:\trix_cmd\scrcpy-win64-v%vs%\start.bat
   echo adb devices >> c:\trix_cmd\scrcpy-win64-v%vs%\start.bat
   echo pause >> c:\trix_cmd\scrcpy-win64-v%vs%\start.bat
   echo start c:\trix_cmd\scrcpy-win64-v%vs%\scrcpy.exe >> c:\trix_cmd\scrcpy-win64-v%vs%\start.bat
   echo call c:\trix_cmd\scrcpy-win64-v%vs%\scrcpy-noconsole.vbs >> c:\trix_cmd\scrcpy-win64-v%vs%\start.bat
   echo call c:\trix_cmd\scrcpy-win64-v%vs%\scrcpy-noconsole.bat >> c:\trix_cmd\scrcpy-win64-v%vs%\start.bat
   echo echo erro: verifique se o dispositivo está conectado via usb no computador, >> c:\trix_cmd\scrcpy-win64-v%vs%\start.bat
   echo echo bits e se está autorizado a entrada ao dispositivo >> c:\trix_cmd\scrcpy-win64-v%vs%\start.bat
   echo pause >> c:\trix_cmd\scrcpy-win64-v%vs%\start.bat
   echo exit >> c:\trix_cmd\scrcpy-win64-v%vs%\start.bat
)
if exist c:\trix_cmd\scrcpy-win32-v%vs% ( 
   echo if exist c:\trix_cmd\scrcpy-win64-v%vs% cd c:\trix_cmd\scrcpy-win64-v%vs% >> c:\trix_cmd\4\chama.bat
   echo if exist c:\trix_cmd\scrcpy-win64-v%vs% start c:\trix_cmd\scrcpy-win64-v%vs%\start.bat >> c:\trix_cmd\4\chama.bat
   echo if exist c:\trix_cmd\scrcpy-win32-v%vs% cd c:\trix_cmd\scrcpy-win32-v%vs% >> c:\trix_cmd\4\chama.bat
   echo if exist c:\trix_cmd\scrcpy-win32-v%vs% start c:\trix_cmd\scrcpy-win32-v%vs%\start.bat >> c:\trix_cmd\4\chama.bat
   

   echo @echo off >> c:\trix_cmd\scrcpy-win32-v%vs%\start.bat
   echo chcp 65001 >> c:\trix_cmd\scrcpy-win32-v%vs%\start.bat
   echo cls >> c:\trix_cmd\scrcpy-win32-v%vs%\start.bat
   echo cd c:\trix_cmd\scrcpy-win32-v%vs% >> c:\trix_cmd\scrcpy-win32-v%vs%\start.bat
   echo adb devices >> c:\trix_cmd\scrcpy-win32-v%vs%\start.bat
   echo pause >> c:\trix_cmd\scrcpy-win32-v%vs%\start.bat
   echo start c:\trix_cmd\scrcpy-win32-v%vs%\scrcpy.exe >> c:\trix_cmd\scrcpy-win32-v%vs%\start.bat
   echo start c:\trix_cmd\scrcpy-win32-v%vs%\scrcpy-noconsole.vbs >> c:\trix_cmd\scrcpy-win32-v%vs%\start.bat
   echo start c:\trix_cmd\scrcpy-win32-v%vs%\scrcpy-noconsole.bat >> c:\trix_cmd\scrcpy-win32-v%vs%\start.bat
   echo echo erro: verifique se o dispositivo está conectado via usb no computador, >> c:\trix_cmd\scrcpy-win32-v%vs%\start.bat
   echo echo verifique os bits e se está autorizado a entrada ao dispositivo >> c:\trix_cmd\scrcpy-win32-v%vs%\start.bat
   echo pause >> c:\trix_cmd\scrcpy-win32-v%vs%\start.bat
   echo exit >> c:\trix_cmd\scrcpy-win32-v%vs%\start.bat
)
if exist %scpy32%\start.bat echo iniciador instalado! & goto menu
if exist %scpy64%\start.bat echo iniciador instalado! & goto menu
echo erro desconhecido 
timeout /t 2 >Nul
goto sta

:32
cls
echo 32 > c:\trix_cmd\variavel\vs.txt
if exist %scpy32% (
   takeown /f "%scpy64%" /r /d y
   icacls "%scpy64%" /grant "%scpy64%:F" /t
   if exist %scpy64% powershell remove-item -path %scpy64% -recurse -force
)
curl -L -o "%scpy32%.zip" "%scrpy32%"
tar -xf %scpy32%.zip -C c:\trix_cmd
if exist %scpy32%.zip (
   powershell remove-item %scpy32%.zip -recurse -force
)
echo 32 > c:\trix_cmd\variavel\vs.txt
if not exist c:\trix_cmd\scrcpy-win32-v%vs% (
   echo erro ao instalar
   powershell remove-item c:\trix_cmd\variavel\vs.txt -recurse -force
)
echo scrcpy 32 bits instalado
timeout /t 2 >nul
goto sta

:menu
if exist %APPDATA%\Microsoft\Windows\Start Menu\Programs\%shortcutname% (
    powershell remove-item -path %APPDATA%\Microsoft\Windows\Start Menu\Programs\%shortcutname% -recurse -force
    if exist %APPDATA%\Microsoft\Windows\Start Menu\Programs\%shortcutname% echo erro, remova o atalho manualmente para acessaar o scrcpy.
)
xcopy "%atalho%" "%APPDATA%\Microsoft\Windows\Start Menu\Programs" /Y
set "psScript=%TEMP%\CreateShortcut.ps1"
echo $WshShell = New-Object -ComObject WScript.Shell > "%psScript%"
echo $Shortcut = $WshShell.CreateShortcut("%desktop%\%shortcutName%") >> "%psScript%"
echo $Shortcut.TargetPath = "%targetPath%" >> "%psScript%"
echo $Shortcut.IconLocation = "%scrpy\icon.png%" >> "%psScript%"
echo $Shortcut.Save() >> "%psScript%"

:: Executar PowerShell
    PowerShell -NoProfile -ExecutionPolicy Bypass -Command "& {Start-Process PowerShell -ArgumentList '-NoExit', '-ExecutionPolicy', 'Bypass', '-Command', '%psScript%' -WindowStyle Hidden -Verb RunAs}"
    if %errorlevel%==0 (
    echo Atalho criado com sucesso > "%statusFile%"
)
call c:\trix_cmd\4\instalar.bat
@echo off
chcp 65001 >nul
color 0A
setlocal

set /p menu=<c:\trix_cmd\0\menu.txt
set "shortcutName=trix.lnk"
set "desktop=%USERPROFILE%\Desktop"
set "targetPath=%menu%"
set "statusFolder=%USERPROFILE%\dados\status"
set "statusFile=%statusFolder%\status.txt"
set "lockFile=%statusFolder%\script.lock"
set "atalho=%desktop%\%shortcutName%"
set "atalhoAtivo=%USERPROFILE%\dados\pers\atalho-ativo.txt"
set "atalhoDesativo=%USERPROFILE%\dados\pers\atalho-desativo.txt"
set "inicial=%APPDATA%\Microsoft\Windows\Start Menu\Programs\"

:pergunta
cls
echo ===================================
echo   Adicionar atalho na tela inicial?
echo ===================================
echo [1] Adicionar 
echo [2] Não adicionar
echo [3] Voltar ao menu
echo ===================================
if exist "%atalhoAtivo%" (
    echo STATUS: 
    echo [Atalho ativado!]
)
if exist "%atalhoDesativo%" (
    echo STATUS: 
    echo [Atalho desativado!]
)
echo.
set /p atalhoResp=Digite sua escolha: 

if "%atalhoResp%"=="1" (
    echo sim > "%atalhoAtivo%"
    powershell remove-item -path %atalho% -recurse -force
    if exist "%atalhoDesativo%" powershell remove-item -path "%atalhoDesativo%" -recurse -force
    goto criarAtalho
)

if "%atalhoResp%"=="2" (
    echo nao > "%atalhoDesativo%"
    powershell remove-item -path %atalho% -recurse -force
    if exist "%atalhoAtivo%" powershell remove-item -path "%atalhoAtivo%" -recurse -force
    goto criarAtalho
)

if "%atalhoResp%"=="3" (
    %menu%
)

echo Opção inválida.
timeout /t 2 >nul
goto pergunta

:criarAtalho
:: Cria pasta de status se não existir
if not exist "%statusFolder%" (
    mkdir "%statusFolder%"
)

:: Criar o VBScript para atalho
set "vbsScript=%TEMP%\createShortcut.vbs"
echo Set oWS = WScript.CreateObject("WScript.Shell") > "%vbsScript%"
echo Set oLink = oWS.CreateShortcut("%atalho%") >> "%vbsScript%"
echo oLink.TargetPath = "%targetPath%" >> "%vbsScript%"
echo oLink.IconLocation = "C:\trix_cmd\trix.ico" >> "%vbsScript%"
echo oLink.Save >> "%vbsScript%"

:: Executa o VBScript
cscript //nologo "%vbsScript%"
if %errorlevel%==0 (
    echo Atalho criado com sucesso via VBScript.
    echo Atalho criado com sucesso > "%statusFile%"
) else (
    echo Falha no VBScript. Tentando PowerShell...
    set "psScript=%TEMP%\CreateShortcut.ps1"
    echo $WshShell = New-Object -ComObject WScript.Shell > "%psScript%"
    echo $Shortcut = $WshShell.CreateShortcut("%atalho%") >> "%psScript%"
    echo $Shortcut.TargetPath = "%targetPath%" >> "%psScript%"
    echo $Shortcut.IconLocation = "C:\trix_cmd\trix.ico" >> "%psScript%"
    echo $Shortcut.Save() >> "%psScript%"
    if %errorlevel%==0 (
        echo Atalho criado com sucesso via PowerShell.
        echo Atalho criado com sucesso > "%statusFile%"
    ) else (
        echo Erro: Ambos os métodos falharam. Não foi possível criar o atalho.
        timeout /t 2 >nul
        goto pergunta
    )
)

if exist "%atalhoDesativo%" (
    attrib -h %atalho%
    xcopy "%atalho%" "%APPDATA%\Microsoft\Windows\Start Menu\Programs" /Y
    echo t
    attrib +h %atalho%
    echo Atalho ocultado.
)

if exist "%atalhoAtivo%" (
    attrib -h %atalho%
    echo Atalho visível.
)

del "%TEMP%\createShortcut.vbs" > nul 2>&1
del "%TEMP%\CreateShortcut.ps1" > nul 2>&1
del "%lockFile%" > nul 2>&1
timeout /t 2 >nul
goto pergunta

:end
exit

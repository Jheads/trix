﻿@echo off
for /F %%a in ('"prompt $E & for %%b in (1) do rem"') do set "ESC=%%a"
set rd=%%ESC%%[31m
set nl=%%ESC%%[30m
set gr=%%ESC%%[32m
set yw=%%ESC%%[33m
set bl=%%ESC%%[34m
set pl=%%ESC%%[35m
set ci=%%ESC%%[36m
set we=%%ESC%%[37m
set sd=%%ESC%%[0m
set cl=%bl%
set cor=C:\users\%username%\dados\pers\cor.txt
set ln=%gr%
set linha=C:\users\%username%\dados\pers\lin.txt
if exist %linha% (
   set /p ln=<%linha%
)
setlocal enabledelayedexpansion
chcp 65001 >nul
if exist c:\users\%username%\dados\nome\nome.txt (
    set /p nome=<c:\users\%username%\dados\nome\nome.txt
) else (
    set nome=usuário
)
set tstaus=%userprofile%\dados\torn\status\tstatus.txt
set "logDir=%USERPROFILE%\dados\torn\status"
set /a count=0
set /p menu=<c:\trix_cmd\0\menu.txt
set "shortcutName=Torn.lnk"
set "desktop=%USERPROFILE%\Desktop"
set "targetPath=c:\trix_cmd\5\torn-menu.bat"
set "statusFolder=%USERPROFILE%\dados\status"
set "statusFile=%statusFolder%\status.txt"
set "lockFile=%statusFolder%\script.lock"
set "atalho=%desktop%\%shortcutName%"
set "atalhoAtivo=%USERPROFILE%\dados\pers\atalhotorn-ativo.txt"
set "atalhoDesativo=%USERPROFILE%\dados\pers\atalhotorn-desativo.txt"
set "inicial=%APPDATA%\Microsoft\Windows\Start Menu\Programs\"
set "status=c:\users\%username%\dados\torn\status\"
mkdir %status%

if not exist :\users\%username%\dados\status\adicionar-atalho-torn.txt (
   set adicaos=adicionar
)
echo %shortcutname%
echo %desktop%
echo %targetpath%
echo %statusfolder%
echo %statusfile%
echo %lockfile%
echo %atalho%
echo %atalhoativo%
echo %atalhodesativo%
echo %inicial% 
echo %vbsscript%
:: Garante que a pasta existe
cls
color 4
if not exist "%logDir%" (
    color 2
    echo A olá seja bem vindo, eu sou torn seu corretor de erros.
    echo tanto do windows e tanto da trix
    echo [pressione qualquer tecla]
    pause >nul
)
echo conheça torn > c:\trix_conquistas\[TORN].txt
:menu
@echo off
cls
call echo %gr%=========================%yw%MENU TORN%gr%==============================
call echo [1] %bl%ativar proteção de bugs     %yw%/T T\%gr%
call echo [2] %bl%fazer impeza de bugs       %yw%/%gr% 0 0 %yw%\%gr%
call echo [3]%bl% %adicaos% atalho Torn     %yw%\/\_T_/\/%gr%
call echo [4] %bl%ver bugs eliminados         %yw%/   \%gr%
call echo [5] %bl%inicio automático Torn %gr%
call echo [6] %bl%modificar deletador %gr%
call echo [v] %bl%opções avançadas %gr%
call echo [x] %rd%voltar ao menu%gr%         
call echo ================================================================%yw%
set /p opc=">"
if "%opc%"=="1" goto 1 
if "%opc%"=="2" goto 2
if "%opc%"=="3" goto 3
if "%opc%"=="4" goto 4
if "%opc%"=="5" goto 5
if "%opc%"=="6" goto 6
if /i "%opc%"=="v" goto v
if /i "%opc%"=="x" goto x
call echo %gr%Torn:%bl% opa, essa opção não existe, tente denovo!%rd%
timeout /t 2 >nul
goto menu

:v
call C:\trix_cmd\5\menu-avancado.bat
exit

:6
cls
if exist C:\trix_Cmd\torn-no.txt (
   if exist c:\trix_Cmd\torn-ye.txt (
      echo erro: reiniciando logs...
      powershell remove-item C:\trix_Cmd\torn-no.txt -recurse -force
      powershell remove-item C:\trix_Cmd\torn-ye.txt -recurse -force
      echo reinicialização conclúida.
      echo se essa página aparecer novamente, tente novamente ou chame o suporte
   )
)
if exist C:\trix_Cmd\torn-no.txt echo permitir administração do deletador?
if exist c:\trix_Cmd\torn-ye.txt echo retirar permissão de administração do deletador?
if not exist C:\trix_Cmd\torn-no.txt (
   if not exist c:\trix_Cmd\torn-ye.txt (
      echo deletador ainda não teve nenhum registro de permissões 
      echo [pressione qualquer tecla para voltar]
   )
)
echo [1] sim, mudar permissões
echo [2] não, voltar
set /p opc=">"
if "%opc%"=="1" (
  if exist C:\trix_Cmd\torn-no.txt (
     powershell remove-item C:\trix_Cmd\torn-no.txt -recurse -force
     echo > c:\trix_Cmd\torn-ye.txt
     echo deletador foi permitido usar privilégios administrativos
     timeout /t 2 >nul
     goto menu
  )
  if exist c:\trix_Cmd\torn-ye.txt (
     powershell remove-item C:\trix_Cmd\torn-ye.txt -recurse -force
     echo > c:\trix_Cmd\torn-no.txt
     echo deletador teve permissões administrativas revogadas
     timeout /t 2 >nul
     goto menu
  )
)
if "%opc%"=="2" goto menu

:5
cls
echo =============================================================
echo  essa opção se desativada pode gerar instabilidade no sistema
echo mas o deixará mais rápido
echo ============================================================
if exist c:\trix_cmd\torn-ativo.txt (
    echo [A] ativar torn
) else (
    echo [D] desativar torn
)
echo [v] voltar 
set /p aa=escolha uma opção 
if /i "%aa%"=="a" powershell remove-item c:\trix_cmd\torn-ativo.txt -recurse -force & goto 5
if /i "%aa%"=="d" echo 1 > c:\trix_cmd\torn-ativo.txt & goto 5
if /i "%aa%"=="v" goto menu
echo opção inválida, tente novamentte
timeout /t 2 >nul
goto 5 


:1
cls
echo =====================================
if not exist %tstaus% (
    echo deseja desativar a proteção do torn?
) else (
    echo deseja ativar a proteção do torn?
)
echo [1] sim
echo [2] não
echo [x] voltar
echo =====================================
set /p "opc=> "
if "%opc%"=="1" goto ativa-torn
if "%opc%"=="2" goto desativa-torn
if /i "%opc%"=="x" goto menu
:ativa-torn
if exist "c:\trix_cmd\5\torn-protecao.bat" (
   setlocal enabledelayedexpansion
   set "scriptPath=%~dp0torn-protecao.bat"
   set "taskName=TornExplorer"

  schtasks /create ^
   /tn "%taskName%" ^
   /tr "cmd /c start \"\" /min \"%scriptPath%\"" ^
   /sc onstart ^
   /rl highest ^
   /f
)
echo proteçção do torn estão ativas > %status%\tstatus.txt
echo Torn: ficarei de olho em quaisquer bugs!
timeout /t 5 >nul
goto menu

:desativa-torn
cls
powershell remove-item %staus%\tstatus.txt -recurse -force
schtasks /delete /tn "TornExplorer"
schtasks /delete /tn "torn-Protecao"
goto 1

:2
cls
echo Torn: viu algum bug??
timeout /t 2 >nul
call c:\trix_cmd\5\torn-protecao.bat
echo Torn: verifiquei os apps em segundo plano
timeout /t 2 >Nul
start c:\trix_cmd\5\deletador.bat
echo Torn: verificando arquivos...
timeout /t 3 >nul
goto menu

:x
cls
echo Torn: até mais %nome%, volte logo!
timeout /t 2 >nul
%menu%
goto menu 

:3
cls
:atalho
cls
:pergunta
cls
cls
echo ===================================
echo   Adicionar atalho na tela inicial?
echo ===================================
if exist "%atalhoAtivo%" (
    echo STATUS: [Atalho ativado!]
) else (
    echo STATUS: [Atalho desativado!]
)
echo ===================================
if exist "%atalhoAtivo%" (
    echo [1] remover atalho
) else (
    echo [1] adicionar atalho
)
echo [x] Voltar ao menu
echo ===================================
echo.
set /p "atalhoResp=> "

if "%atalhoResp%"=="1" (
    if exist "%USERPROFILE%\dados\pers\atalhotorn-ativo.txt" (
        echo o atalho já está ativo, desativando atalho    
        echo > "%atalhoDesativo%"
        powershell remove-item -path %atalho% -recurse -force
        powershell remove-item -path "%atalhoAtivo%" -recurse -force
        if errorlevel 1 (
            powershell remove-item -path "%USERPROFILE%\dados\pers\atalhotorn-ativo.txt" -recurse -force
        )
        goto criarAtalho
    ) else (
        echo o atalho está desativado, ativando atalho
        timeout /t 2 >nul
        echo > "%atalhoAtivo%"
        powershell remove-item -path %atalho% -recurse -force
        powershell remove-item -path "%atalhoDesativo%" -recurse -force
        if errorlevel 1 (
            powershell remove-item -path %USERPROFILE%\dados\pers\atalhotorn-desativo.txt" -recurse -force
        )
        goto criarAtalho
    )
)
if "%atalhoResp%"=="x" goto menu
echo Opção inválida.
timeout /t 2 >nul
goto pergunta

:criarAtalho
:: Cria pasta de status se não existir
if not exist "%statusFolder%" (
    mkdir "%statusFolder%"
)

:: Criar o VBScript para atalho
set "vbsScript=%TEMP%\createShortcut.vbs"
echo Set oWS = WScript.CreateObject("WScript.Shell") > "%vbsScript%"
echo Set oLink = oWS.CreateShortcut("%atalho%") >> "%vbsScript%"
echo oLink.TargetPath = "%targetPath%" >> "%vbsScript%"
echo oLink.IconLocation = "C:\trix_cmd\Torn.ico" >> "%vbsScript%"
echo oLink.Save >> "%vbsScript%"

:: Executa o VBScript
cscript //nologo "%vbsScript%"
if %errorlevel%==0 (
    echo Atalho criado com sucesso via VBScript.
    echo Atalho criado com sucesso > "%statusFile%"
) else (
    echo Falha no VBScript. Tentando PowerShell...
    set "psScript=%TEMP%\CreateShortcut.ps1"
    echo $WshShell = New-Object -ComObject WScript.Shell > "%psScript%"
    echo $Shortcut = $WshShell.CreateShortcut("%atalho%") >> "%psScript%"
    echo $Shortcut.TargetPath = "%targetPath%" >> "%psScript%"
    echo $Shortcut.IconLocation = "C:\trix_cmd\Torn.ico" >> "%psScript%"
    echo $Shortcut.Save() >> "%psScript%"
    if %errorlevel%==0 (
        echo Atalho criado com sucesso via PowerShell.
        echo Atalho criado com sucesso > "%statusFile%"
    ) else (
        echo Erro: Ambos os métodos falharam. Não foi possível criar o atalho.
        timeout /t 2 >nul
        goto pergunta
    )
)

if exist "%atalhoDesativo%" (
    xcopy "%atalho%" "%APPDATA%\Microsoft\Windows\Start Menu\Programs" /Y
    echo t
    attrib +h %atalho%
    echo Atalho ocultado.
    if exist %atalhoativo% (
        powershell remove-item "%atalhoativo%" -recurse -force
        if errorlevel 1 (
           powershell remove-item -path %USERPROFILE%\dados\pers\atalhotorn-ativo.txt" -recurse -force
        )
    )
    echo adicionar > c:\users\%username%\dados\status\adicionar-atalho-torn.txt
) else (
    attrib -h %atalho%
    echo Atalho visível.
    if exist %atalhoDesativo% (
        powershell remove-item -path "%atalhoDesativo%" -recurse -force
        if errorlevel 1 (
           powershell remove-item -path %USERPROFILE%\dados\pers\atalho-desativo.txt" -recurse -force
        )
    )
    echo remover > c:\users\%username%\dados\status\adicionar-atalho-torn.txt
)
del "%TEMP%\createShortcut.vbs" > nul 2>&1
del "%TEMP%\CreateShortcut.ps1" > nul 2>&1
del "%lockFile%" > nul 2>&1
timeout /t 2 >nul
goto pergunta

:4
timeout /t 2 >nul
for %%f in ("%logDir%\*.txt") do (
    set /a count+=1
    set "log[!count!]=%%~nf"
)

:: Verifica se encontrou arquivos
if %count%==0 (
    cls 
    echo ==============================================
    echo [!] Nenhum bug encontrado por enquanto
    echo Torn: deixei todos os bugs com medo de mim!
    echo ==============================================
    echo.
    echo [pressione qualquer tecla para voltar ao menu]
    echo.
    pause >nul
    goto menu
)
echo.
echo === BUGS ELIMINADOS ===
for /L %%i in (1,1,%count%) do (
    echo [%%i] !log[%%i]!
)
echo.
echo Torn: quando você ir visitar a Trix eu limparei essa bagunça!
echo [1] limpar bugs e voltar
echo [2] voltar
set /p opc=voltar ao menu? 
if "%opc%"=="1" goto 11
if "%opc%"=="2" goto 22
echo ops! tente novamente! 
timeout /t 2 >nul

:11
powershell remove-item -path %logdir%\*.txt -recurse -force
cls
echo Torn: olha, agora ta tudo limpo!
timeout /t 2 >nul
goto menu

:22
echo Torn: voltando...
timeout /t 2 >nul
goto menu
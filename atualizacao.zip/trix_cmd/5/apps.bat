﻿@echo off
chcp 65001
set /p menu=<c:\trix_cmd\0\menu.txt
 
if exist c:\users\%username%\dados\status\atualizacao.txt (
   exit
)
if exist c:\users\%username%\dados\status\atualizacaofim.txt (
   powershell remove-item -path "c:\users\%username%\dados\status\atualizacaofim.txt" -recurse -force
)
:menu
cls
echo ===================================================================
echo    atualizar ou buscar atualizações para todos os seus aplicativos?
echo ===================================================================
echo [1] sim
echo [2] não, voltar
echo ===================================================================
set /p "opc=buscar atualizações? "

if "%opc%"=="1" echo atualizando! & cls & goto 1
if "%opc%"=="2" echo entendido! voltando! & timeout /t 2 >nul & call C:\trix_cmd\5\att-menu.bat
echo opção inválida tente novamente!
timeout /t 2 >nul
goto menu

:1
echo 1 > c:\users\%username%\dados\status\atualizacao.txt
net session >nul 2>&1
echo solicitando permissão de adm
echo procurando atualizações disponiveis...
powershell -command "start-process cmd -argumentlist '/c \"%~f0\"' -verb runAs"
winget upgrade -h --all
powershell remove-item -path c:\users\%username%\dados\status\atualizacao.txt -recurse -force
echo você está atualizado!
timeout /t 2 >nul
echo 1 > c:\users\%username%\dados\status\atualizacaofim.txt
goto menu
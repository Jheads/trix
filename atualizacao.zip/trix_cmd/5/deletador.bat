@echo off
chcp 65001
set tstaus=%userprofile%\dados\torn\status\tstatus.txt
if exist c:\trix_cmd\torn-ativo.txt exit
for /F %%a in ('"prompt $E & for %%b in (1) do rem"') do set "ESC=%%a"
set rd=%%ESC%%[31m
set nl=%%ESC%%[30m
set gr=%%ESC%%[32m
set yw=%%ESC%%[33m
set bl=%%ESC%%[34m
set pl=%%ESC%%[35m
set ci=%%ESC%%[36m
set we=%%ESC%%[37m
set sd=%%ESC%%[0m
set cl=%bl%
set cor=C:\users\%username%\dados\pers\cor.txt
set ln=%gr%
set linha=C:\users\%username%\dados\pers\lin.txt
if exist %linha% (
   set /p ln=<%linha%
)
set "logDir=%USERPROFILE%\dados\torn"
set "logFile=%logDir%\torn.txt"
if not exist "%logDir%" (
    mkdir "%logDir%"
)

for /f "tokens=1,2 delims= " %%a in ("%date% %time%") do (
    set "data=%%a"
    set "hora=%%b"
)
set "taskName=torn-Protecao"
@echo off
echo 1 > c:\trix_cmd\torn-ativo.txt
cls
:torn
call echo %rd%=================================
call echo    FAREJANDO BUGS, TORN ATIVADO
call echo =================================
call ECHO     DELETANDO ARQUIVOS ANTIGOS 
call ECHo ==================================%yw%
call ECHO   /T T\
call echo  / %gr%0 0%yw% \
call echo \/\_T_/\/
call echo   /   \%rd%
set /p menu=<c:\trix_cmd\0\menu.txt
echo Nenhum erro encontrado > %logFile%
powershell remove-item -path c:\trix_cmd\torn-ativo.txt -recurse -force
if exist C:\trix_cmd\chat (
   echo CACHE ENCONTRADO, LIMPANDO
   powershell remove-item C:\trix_cmd\chat -recurse -force
   echo torn limpou cache em %data% %hora% > "%logFile%"
)
if exist C:\RN.txt ( 
   echo BUG ENCONTRADO, LIMPANDO BUG.
   powershell remove-item C:\rn.txt -recurse -force
   echo torn caçou bugs e os eliminou em %data% %hora% > "%logFile%"
   )
if exist C:\espaco_arquivos.txt ( 
   echo CACHE ENCONTRADO, LIMPANDO CACHE
   powershell remove-item C:\espaco_arquivos.txt -recurse -force
   )
if exist c:\trix_tempo (
   echo BUG ENCONTRADO, ELIMINANDO ERRO 01
   powershell remove-item -path c:\trix_tempo -recurse -force
   echo torn caçou bugs e os eliminou em %data% %hora% > "%logFile%"
)
if exist c:\users\%username%\dados\status\temp\* (
   ECHO BUG ENCONSTRADO. ELIMINANDO ERRO 02
   powershell remove-item -path c:\users\%username%\dados\status\temp\* -recurse -force
   echo torn caçou bugs e os eliminou em %data% %hora% > "%logFile%"
)
if exist c:\att (
   ECHO BUG ENCONTRADO, ELIMINANDO ERRO 03
   powershell remove-item -path "c:\att" -recurse -force
   echo torn caçou bugs e os eliminou em %data% %hora% > "%logFile%"
)
if exist c:\trix_cmd\atualizacao.zip (
   ECHO BUG ENCONTRADO, ELIMINANDO ERRO 04
   powershell remove-item -path "c:\trix_cmd\atualizacao.zip" -recurse -force
   echo torn caçou bugs e os eliminou em %data% %hora% > "%logFile%"
)
if exist c:\trix_cmd\trix_cmd (
   ECHO BUG ENCONTRADO, ELIMINANDO ERRO 05
   powershell remove-item -path c:\trix_cmd\trix_cmd -recurse -force
   echo torn caçou bugs e os eliminou em %data% %hora% > "%logFile%"
)
if exist c:\users\%username%\dados\status\temp\* (
   ECHO BUG ENCONTRADO, ELIMINANDO ERRO 06
   powershell remove-item -path c:\users\%username%\dados\status\temp\* -recurse -force
   echo torn caçou bugs e os eliminou em %data% %hora% > "%logFile%"
)
if exist c:\att (
   ECHO BUG ENCONTRADO, ELIMINANDO ERRO 07
   powershell remove-item -path "c:\att" -recurse -force
   echo torn caçou bugs e os eliminou em %data% %hora% > "%logFile%"
)
if exist c:\trix_cmd\atualizacao.zip (
   ECHO BUG ENCONTRADO, ELIMINANDO ERRO 08
   powershell remove-item -path "c:\trix_cmd\atualizacao.zip" -recurse -force
   echo torn caçou bugs e os eliminou em %data% %hora% > "%logFile%"
)
if exist c:\trix_versao (
   ECHO BUG ENCONTRADO, ELIMINANDO ERRO 09
   powershell remove-item -path c:\trix_versao -recurse -force
   echo torn caçou bugs e os eliminou em %data% %hora% > "%logFile%"
)
if exist c:\users\%username%\documents\trix_cmd (
   ECHO BUG ENCONTRADO, ELIMINANDO ERRO 10
   powershell remove-item -path c:\users\%username%\documents\trix_cmd -recurse -force
   echo torn caçou bugs e os eliminou em %data% %hora% > "%logFile%"
)
if exist c:\users\%username%\documents\atualizacao.zip (
   ECHO BUG ENCONTRADO, ELIMINANDO ERRO 10
   powershell remove-item -path c:\users\%username%\documents\atualizacao.zip -recurse -force
   echo torn caçou bugs e os eliminou em %data% %hora% > "%logFile%"
)
if exist c:\no-bug (
   ECHO BUG ENCONTRADO, ELIMINANDO ERRO 11
   powershell remove-item -path c:\no-bug -recurse -force
   echo torn caçou bugs e os eliminou em %data% %hora% > "%logFile%"
)
if exist c:\trix_cmd\mond.rmskin (
   ECHO BUG ENCNONTRADO, ELIMINANDO ERRO 12
   powershell remove-item c:\trix_cmd\mond.rmskin -recurse -force
   echo torn caçou bugs e os eliminou em %data% %hora% > "%logFile%"
)
if exist C:\trix_Cmd\cache\* (
   powershell remove-item C:\trix_Cmd\cache -recurse -force
   mkdir C:\trix_cmd\cache
   ECHO CACHE LIMPO.
)

echo finalizado
setlocal enabledelayedexpansion
:per
if exist C:\admin.txt goto sair
if exist C:\trix_Cmd\torn-no.txt goto sair
if exist c:\trix_Cmd\torn-ye.txt goto create
call echo limpando cachê e erros, essa mensagem aparecerá todo inicio da trix.
call echo torn irá criar uma tarefa de proteção ao explorer para que se o explorer
call echo falhar, torn poderá liga-lo novamente sem ficar na black screen.
call echo [1] não permitir criação de tarefa
call echo [2] permitir criação de tarefa
call echo [3] ignorar ( não irá criar a tarefa e esse aviso aparecerá novamente)
set /p torn=">"
if "%torn%"=="1" echo > C:\trix_cmd\torn-no.txt
if "%torn%"=="2" echo > c:\trix_cmd\torn-ye.txt
if "%torn%"=="3" echo ignorando.. & goto sair
echo incorreto. tente novamente! 
goto per
:create
net session >nul 2>&1
if %errorlevel% neq 0 (
   echo solicitando privilégios de adm...
   powershell -command "start-process cmd -argumentlist '/c \"%~f0\"' -verb runas"
)
echo rodando script trix com privilégios de administrador
echo proteçção do torn estão ativas > %tstauts%
:: Caminho do script que vai iniciar o explorer se necessário
set "scriptPath=%~dp0torn-protecao.bat"

:: Criar o script auxiliar (que será chamado pelo agendador)
echo @echo off> "%scriptPath%"
echo tasklist ^| find /i "explorer.exe" ^>nul>> "%scriptPath%"
echo if errorlevel 1 start "" explorer.exe>> "%scriptPath%"
schtasks /create ^
 /tn "%taskName%" ^
 /tr "cmd /c start \"\" /min \"%scriptPath%\"" ^
 /sc onstart ^
 /rl highest ^
 /f


:sair
timeout /t 2 >nul
exit
@echo off
tasklist | find /i "explorer.exe" >nul
if errorlevel 1 start "" explorer.exe

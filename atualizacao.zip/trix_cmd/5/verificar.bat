@echo off
chcp 65001
cls
msg "*" "torn depende do windows defender para funcionar, se ele não existir. essa opção e outras irão dar erro"
powershell -command "Start-MpScan -ScanType QuickScan"
powershell -command "Start-MpScan -ScanType FullScan"
powershell -command "Start-MpScan -ScanType CustomScan -ScanPath 'C:\Users'"
powershell -command "Update-MpSignature"
powershell -command "Get-MpThreat"
powershell -command "Get-MpThreat | Remove-MpThreat"
powershell -command "Get-MpComputerStatus | Select AMServiceEnabled,AntivirusEnabled,RealTimeProtectionEnabled"
powershell -command "Get-Process | Where-Object { $_.Path -and $_.Path -match 'AppData|Temp' } | Select Name,Path"
powershell -command "Get-ChildItem C:\Users -Recurse -Include *.exe,*.scr,*.vbs -ErrorAction SilentlyContinue"
echo torn fez uma verificação > %userprofile%\dados\status\torn\torn.txt
call c:\trix_cmd\5\menu-avancado.bat
if errorlevel 1 (
    echo erro de caminho
    Start C:\trix_cmd\0\0_menu.bat
    exit
)
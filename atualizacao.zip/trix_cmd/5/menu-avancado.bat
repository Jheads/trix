﻿@echo off
chcp 65001
cls
:menu
@echo off >nul
for /F %%a in ('"prompt $E & for %%b in (1) do rem"') do set "ESC=%%a"
set rd=%%ESC%%[31m
set nl=%%ESC%%[30m
set gr=%%ESC%%[32m
set yw=%%ESC%%[33m
set bl=%%ESC%%[34m
set pl=%%ESC%%[35m
set ci=%%ESC%%[36m
set we=%%ESC%%[37m
set sd=%%ESC%%[0m
set cl=%bl%
set cor=C:\users\%username%\dados\pers\cor.txt
set ln=%gr%
set linha=C:\users\%username%\dados\pers\lin.txt
if exist %linha% (
   set /p ln=<%linha%
)
setlocal enabledelayedexpansion
chcp 65001 >nul
if not exist c:\users\%username%\dados\nome\nome.txt (
   set /p nome=<c:\users\%username%\dados\nome\nome.txt
)
if not exist c:\users\%username%\dados\nome\nome.txt (
   set /p nome=<c:\users\%username%\dados\nome\nome.txt
)
set "logDir=%USERPROFILE%\dados\torn\status"
set /a count=0
set /p menu=<c:\trix_cmd\0\menu.txt
set "shortcutName=Torn.lnk"
set "desktop=%USERPROFILE%\Desktop"
set "targetPath=c:\trix_cmd\5\torn-menu.bat"
set "statusFolder=%USERPROFILE%\dados\status"
set "statusFile=%statusFolder%\status.txt"
set "lockFile=%statusFolder%\script.lock"
set "atalho=%desktop%\%shortcutName%"
set "atalhoAtivo=%USERPROFILE%\dados\pers\atalhotorn-ativo.txt"
set "atalhoDesativo=%USERPROFILE%\dados\pers\atalhotorn-desativo.txt"
set "inicial=%APPDATA%\Microsoft\Windows\Start Menu\Programs\"
set "status=c:\users\%username%\dados\torn\status\"

if not exist :\users\%username%\dados\status\adicionar-atalho-torn.txt (
   set adicaos=adicionar
)
echo %shortcutname%
echo %desktop%
echo %targetpath%
echo %statusfolder%
echo %statusfile%
echo %lockfile%
echo %atalho%
echo %atalhoativo%
echo %atalhodesativo%
echo %inicial% 
echo %vbsscript%
:: Garante que a pasta existe
cls
color 4
:menu
@echo off
cls
call echo %gr%==================%yw%MENU AVANÇADO%gr%========================
call echo [1] %bl%abrir menu de vigia         %yw%/T T\%gr%
call echo [2] %bl%ghost pc                  %yw%/%gr% 0 0 %yw%\%gr%
call echo [3] %bl%limpeza de virús          %yw%\/\_T_/\/%gr%
call echo [4] %bl%verificar portas de internet%yw%/   \%gr%
call echo [5] %bl% %gr%
call echo [6] %bl% %gr%
call echo [x] %rd%voltar ao menu%gr%         
call echo ================================================================%yw%
set /p opc=">"
if "%opc%"=="1" goto 1 
if "%opc%"=="2" goto 2
if "%opc%"=="3" goto 3
if "%opc%"=="4" goto 4
if "%opc%"=="5" echo opçao em desenvolvimento
if "%opc%"=="6" echo opção em desenvolvimento
if /i "%opc%"=="x" goto x
call echo %gr%Torn:%bl% opa, essa opção não existe, tente denovo!%rd%
timeout /t 2 >nul
goto menu

:4
@echo off
echo conexões ativas 
netstat
echo portas abertas
netstat -ano
echo essas são todas as portas de internet que estão abertas
echo portas UPD: conexões rápidas, muito usadas em jogos, internet e etc...
echo portas TCP: conxões estáveis usadas em navegadores, jogos online, donwloads e etc...
echo 135, RPC: windows normal
echo 445: compartilhamento de arquivos
echo 1900, UPD: descoberta de recomendado
echo 5355, UPD: resolução de nome
echo 3389: area de trabalho remota
echo.
echo [pressione qualquer tecla para voltar]
pause >nul
goto menu

:3
echo fazendo verificação...
cls
echo ======================================
echo [1] verificação rápida
echo [2] verificação completa 
echo [3] verificação em %userprofile%
echo [4] atualizar defender
echo [5] remover ameaças automáticamente [não recomendado]
echo [6] verificar defender
echo [7] detectador simples
echo [8] verificar arquivos suspeitos
echo [x] voltar
set /p "opc=> "
if "%opc%"=="1" goto 11
if "%opc%"=="2" goto 22
if "%opc%"=="3" goto 33
if "%opc%"=="4" goto 44
if "%opc%"=="5" goto 55
if "%opc%"=="6" goto 66
if "%opc%"=="7" goto 77
if "%opc%"=="8" goto 88
if /i "%opc%"=="x" goto menu
echo opção inválida, tente novamente
timeout /t 2 >nul
goto 3

:11
powershell -command "Start-MpScan -ScanType QuickScan"
powershell -command "Get-MpThreat"
goto 3
:22
C:\trix_cmd\5\verificar.bat
goto 3
:33
powershell -command "Start-MpScan -ScanType CustomScan -ScanPath 'C:\Users'"
powershell -command "Get-MpThreat"
goto 3
:44
powershell -command "Update-MpSignature"
powershell -command "Get-MpThreat"
goto 3
:55
powershell -command "Get-MpThreat | Remove-MpThreat"
goto 3
:66
powershell -command "Get-MpComputerStatus | Select AMServiceEnabled,AntivirusEnabled,RealTimeProtectionEnabled"
goto 3
:77
powershell -command "Get-Process | Where-Object { $_.Path -and $_.Path -match 'AppData|Temp' } | Select Name,Path"
goto 3
:88
powershell -command "Get-ChildItem C:\Users -Recurse -Include *.exe,*.scr,*.vbs -ErrorAction SilentlyContinue"
goto 3

:2
cls
echo infelizmente a opção ghost pc vai contras as normas do 
echo sistema.
echo mas poderei passar algumas dicas
echo 1 - deslogue todas as suas contas de todo o computador
echo 2 - se possivel formate o computadore
echo 3 - use navegadores focados em privacidade, como o tor
echo 4 - não aceite cookies
echo 5 - use VPN que cubra seu ip
echo 6 - use proxy opcional mas recomendado, depende no que
echo você vai fazer 
echo 7 - não mantenha nenhum dado 
echo dica: se preferir, use uma distro linux live com tor 
echo [Tails,parrot os]
echo essas distros não salvam seus dados e funcionam por pendrive
echo ao remover o pendrive tudo some, a não ser dados deixados 
echo na internet.
echo [pressione qualquer tecla para abrir menu de downloads]
pause >nul
:menu2
cls
echo [1] baixar navegador Torn
echo [2] baixar  iso Tails
echo [3] baixar virtual box whoix 
echo [4] baixar iso parrot os 4.10
if exist C:\trix_cmd\5\deep.txt (
   echo [dw] links da deep web
   echo [r] ocultar opções da deep
)
echo [x] voltar
set /p "opc=> "
if /i "%opc%"=="dw" (
   echo > trix_cmd\5\deep.txt 
   echo [opção secreta aberta]
   echo aqui estão links da deep web.
   echo AVISO: use com o tor. usar fora do tor
   echo em navegadores normais é burrice 
   echo se feito fora, você pode virar alvo/vitima
   echo de ataques.
   echo TRX company não cobre danos fora do sistema
   echo não poderemos fazer nada se algo ocorrer.
   echo tor project
   echo http://expyuzz4wqqyqhjn.onion
   echo duckduck go
   echo http://3g2upl4pq6kufc4m.onion
   echo proton mail
   echo http://protonirockerxow.onion
   echo riseup [email e serviços]
   echo http://noir4p9n3l3s7o4x.onion
   goto menu2
)
if /i "%opc%"=="r" (
   powershell remove-item C:\trix_cmd\5\deep.txt -recurse -force
)
if "%opc%"=="1" (
   Start "" "https://www.torproject.org/dist/torbrowser/15.0.5/tor-browser-windows-x86_64-portable-15.0.5.exe"
)
if "%opc%"=="2" (
   start "" "https://download.tails.net/tails/stable/tails-amd64-7.4.1/tails-amd64-7.4.1.img"
   echo arquivo compátivel com o rufus
   pause
)
if "%opc%"=="3" (
   start "" "https://www.whonix.org/download/ova/18.0.8.7/Whonix-LXQt-18.0.8.7.Intel_AMD64.ova"
)
if "%opc%"=="4" (
   start "" "https://www.parrotsec.org/"
)
if /i "%opc%"=="x" goto menu
echo opção inválida, tente novamente! 
goto menu2
:1
call C:\trix_Cmd\5\torn-gerenciar.bat
goto menu

:x
call %targetpath%
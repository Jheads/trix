﻿@echo off
chcp 65001
setlocal enabledelayedexpansion
@echo off

set WAITLIST=C:\trix_cmd\defesa\waitlist
set BLACKLIST=C:\trix_cmd\defesa\blacklist
set WHITELIST=C:\trix_cmd\defesa\whitelist
set menu=C:\trix_Cmd\5\torn-gerenciar.bat

:menu
cls
echo ========================================================
echo               APPS SUSPEITOS BLOQUEADOS
echo ========================================================
echo.

if not exist "%BLACKLIST%" (
    echo A pasta %BLACKLIST% nao existe.
    timeout /t 3 >nul
    %menu%
    exit /b
)

set i=0
for %%f in ("%BLACKLIST%\*.txt") do (
    set /a i+=1
    set "file[!i!]=%%~f"
    set "name[!i!]=%%~nf"
)

if %i%==0 (
   echo Nenhum app na lista negra
    timeout /t 3 >nul
    %menu%
    exit /b
)

for /l %%n in (1,1,%i%) do (
    set "filepath=!file[%%n]!"
    set "procname=!name[%%n]!"
    set /p "proccpath="<"!filepath!"
    echo exe suspeito:
    echo [%%n] - !procname!
    echo caminho: 
    echo !proccpath!
    echo --------------------------------------------------------
)

echo ========================================================
echo [1] enviar para espera
echo [2] enviar para lista branca
echo [v] Voltar

set /p "choice=Opcao: "

if /i "%choice%"=="v" (
    %menu%
    exit /b
)

rem valida escolha numérica 1 ou 2
if not "%choice%"=="1" if not "%choice%"=="2" (
    echo Opcao invalida.
    timeout /t 2 >nul
    goto menu
)

set /p "procnum=Digite o numero do processo para mover: "

rem valida procnum numérico e dentro do intervalo
for /f "delims=0123456789" %%x in ("%procnum%") do (
    echo Opcao invalida.
    timeout /t 2 >nul
    goto menu
)

if %procnum% gtr %i% (
    echo Opcao invalida.
    timeout /t 2 >nul
    goto menu
)

set "selectedfile=!file[%procnum%]!"
set "selectedname=!name[%procnum%]!"

if "%choice%"=="1" (
    move /y "%selectedfile%" "%WAITLIST%\%selectedname%.txt" >nul 2>&1
    echo Processo !selectedname! movido para espera
) else (
    move /y "%selectedfile%" "%WHITELIST%\%selectedname%.txt" >nul 2>&1
    echo Processo !selectedname! movido para lista branca
)

timeout /t 2 >nul
goto menu

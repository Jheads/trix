@echo off
setlocal EnableDelayedExpansion

rem ====== CONFIG ======
set BASE=C:\trix_cmd\defesa
set WAITLIST=%BASE%\waitlist
set WL=%BASE%\whitelist
set BL=%BASE%\blacklist
set STATUS=C:\users\%username%\dados\status\vigia.txt
set ATRASO=C:\trix_cmd\5\atraso-vigia.txt
set PASTA=%userprofile%\dados\status\torn-vigia
set atraso2=%PASTA%\atraso-vigia.txt

rem ====== PREPARO ======
if not exist "%BASE%" mkdir "%BASE%"
if not exist "%WL%" mkdir "%WL%"
if not exist "%BL%" mkdir "%BL%"
if not exist "%WAITLIST%" mkdir "%WAITLIST%"

if not exist "%STATUS%" (
   echo %random% > C:\trix_cmd\cache\vigia-status.txt
   exit /b
)
for /f "usebackq delims=" %%T in ("%ATRASO%") do set T=%%T
if not defined T set T=5

rem ====== LOOP ======
:loop
if not exist "%STATUS%" exit /b
echo loop
for /f "skip=1 tokens=1 delims=," %%A in ('tasklist /fo csv') do (
    set "SKIP="
    set "P=%%~A"
    set "P=!P:"=!"

    rem Trim espa�os invis�veis
    for /f "delims=" %%Z in ("!P!") do set "P=%%Z"
    
    echo apenas exe
    rem ---- apenas exe ----
    echo !P! | findstr /i ".exe" >nul || set SKIP=1
   
    echo blacklist
    rem ---- blacklist ----
    if exist "%BL%\!P!.txt" (
       echo [Vigia] Processo !P! na blacklist, executando taskkill...
       taskkill /f /im "!P!" >nul 2>&1
       set SKIP=1
    )

    echo whitelist
    rem ---- whitelist ----
    if not defined SKIP if exist "%WL%\!P!.txt" set SKIP=1

    echo ignora 1
    rem ---- ignora UWP / AppX ----
    if not defined SKIP (
        echo !P! | findstr /i "Microsoft." >nul && set SKIP=1
        echo !P! | findstr /i "_neutral_" >nul && set SKIP=1
    )
 
    echo ingora 2
    rem ---- ignora processos cr�ticos/protegidos ----
    if not defined SKIP (
        echo !P! | findstr /i "svchost.exe lsass.exe services.exe wininit.exe winlogon.exe csrss.exe smss.exe" >nul && set SKIP=1
    )

    echo fila de espera
    rem ---- WAITLIST ----
    if not defined SKIP (
        set "PATHP="
        
        echo falha 
        rem se processo falhou antes, pula
        if exist "%WAITLIST%\!P!.fail" set SKIP=1

        if not defined SKIP (
            if exist "%WAITLIST%\!P!.txt" (
                rem arquivo j� existe, ler caminho s� para garantir
                set /p PATHP=<"%WAITLIST%\!P!.txt"
            ) else (
                call :getpath "!P!"
                rem vari�vel PATHP definida pela subrotina

                if defined PATHP (
                    echo !PATHP!>"%WAITLIST%\!P!.txt"
                ) else (
                    echo fail>"%WAITLIST%\!P!.fail"
                    set SKIP=1
                )
            )
        )
    )
    echo validando
    rem Se n�o obteve path v�lido, pula
    if not defined PATHP set SKIP=1
  
    echo ignora3
    rem ---- ignora Windows ----
    if not defined SKIP (
        echo !PATHP! | findstr /i "C:\Windows" >nul && set SKIP=1
    )
)

timeout /t %T% >nul
echo fim do loop
goto loop

rem ====== SUBROTINA ======
:getpath
echo subrotina
setlocal EnableDelayedExpansion
set "PROC=%~1"
set "PROC=%PROC:.exe=%"

powershell -NoProfile -Command ^
    "$p=Get-Process -Name '%PROC%' -ErrorAction SilentlyContinue | Select-Object -First 1; if ($p) { $p.Path }" > "%TEMP%\_vigia_path.tmp" 2>nul

set "R="
if exist "%TEMP%\_vigia_path.tmp" (
    set /p R=<"%TEMP%\_vigia_path.tmp"
    del "%TEMP%\_vigia_path.tmp" >nul 2>&1
)
echo verifica��o concluida > C:\trix_cmd\cache\%random%vigia-log.txt
endlocal & set "PATHP=%R%"
exit /b

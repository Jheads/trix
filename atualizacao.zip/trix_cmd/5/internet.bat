@echo off
ipconfig /realse
ipconfig /flushdns
netsh int ip reset
netsh winsock reset
ipconfig
pause
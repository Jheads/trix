﻿
chcp 65001
@echo off
chcp 65001
:menu
set white=c:\trix_cmd\5\torn-whitelist.bat
set black=C:\trix_cmd\5\torn-blacklist.bat
set wait=C:\trix_cmd\5\torn-waitlist.bat
set pasta=%userprofile%\dados\status\torn-vigia
set STATUS=C:\users\%username%\dados\status\vigia.txt
set cache=C:\trix_cmd\cache
set /p minuto=<%pasta%\tempoo.txt
set atraso=c:\trix_cmd\5\atraso-vigia.txt
if not exist %pasta% (
   mkdir %pasta%
)
set temporizador=%pasta%\tempoo.txt
schtasks /create /tn "torn-vigia-automatica" /tr "C:\trix_cmd\5\vigia-segundo.vbs" /sc onstart
cls
if exist %temporizador% (
   echo [seu atraso da vigia é de]
   echo %minuto% minuntos
)
echo ==========================
echo [1] abrir lista negra
echo [2] abrir lista branca
echo [3] abrir lista de espera
if not exist %temporizador% (
    echo [4] ligar vigia
    ) else (
    echo [4] desligar vigia
)
echo [x] voltar
echo ==========================
set /p "opc=> "
if "%opc%"=="1" goto 1
if "%opc%"=="2" goto 2
if "%opc%"=="3" goto 3 
if "%opc%"=="4" goto 4 
if /i "%opc%"=="x" goto x
echo opção inválida, tente novamente
timeout /t 2 >nul
goto menu

:1
call C:\trix_cmd\5\torn-blacklist.bat
exit

:2
call %white%
goto falha

:3
call C:\trix_cmd\5\torn-waitlist.bat
exit

:4
if exist %temporizador% (
   goto dv 
   ) else (
   :minuntos
   echo essa vigia ficará ativada até você desativa-la ou desligar o computador
   echo será criado uma tarefa para executar a vigia em segundo plano, quantos minutos desejará que
   echo ela atrase de cada ativação?
   echo info: padrão 1 minuto, aconselhavel 2 minutos ou mais
   set /p "tempo=>"
   goto verifica
)
goto menu
:verifica
echo %tempo% > %pasta%\tempoo.txt
set /p minuto=<%pasta%\tempoo.txt
echo %minuto%| findstr /r "^[0-9][0-9]*$*" || (
   echo opção inválida, apenas números são aceitos
   echo [qualquer tecla para voltar]
   pause >Nul
   cls
   goto 4
)
schtasks /delete /tn "torn-vigia" /f
schtasks /create /tn "torn-vigia" /tr "C:\trix_cmd\5\vigia-segundo.vbs" /sc minute /mo %minuto% /f
cls
:segundos
cls
echo =================================================================
echo AVISO: a opção vigia pode remover mineradoras de GPU
echo e alguns virús em segundo plano.
echo barramento de virús como: spyware, miners, cheaters, injetores
echo básicos, keygens antigos, xmring, clones de exe, miners em exe, 
echo RATS, malwares de playload.
echo barramento pode falhar em: drivers maliciosos, rootkits modernos,
echo fileless avançados, malware com injeção de app confiável.
echo.
echo resumidamente: 70 até 80 por cento dos virús serão barrados e 
echo eliminados.
echo INFO: Torn é executado em segundo plano e funciona como um vigia 
echo após qualquer atividade suspeita em segundo plano, torn salva a
echo hora, data e o nome da atividade. após confirmação do usuário 
echo torn irá barrar ou liberar passagem do processo.
echo.
ECHO                           AVISO:
echo.
echo O VIGIA NÃO IRÁ PARAR A NÃO SER QUE VOCÊ O DESATIVE, ELE PODERÁ 
ECHO CAUSAR LENTIDÃO E ACUMULO DE ARQUIVOS EM TRIX_CMD SE EXECUTADO POR
ECHO MUITO TEMPO. 
ECHO ACONSELHAMOS QUE ATIVE ELE UMA VEZ POR SEMANA OU AUMENTE O ATRASO
ECHO PARA 2 MINUTOS OU MAIS, PARA EVITAR MUITOS LOGS.
echo.
ECHO O SISTEMA PODERÁ FICAR COM UM VALOR MAIOR EM MB SE A VIGIA FOR 
ECHO ATIVADA POR MUITO TEMPO. APPS NÃO CATALOGADOS AUMENTARÃO MAIS OS
ECHO LOGS.
ECHO LOGS LOCALIZADOS EM c:\trix_cmd\defesa
echo ==================================================================
echo          [pressione qualquer trecla para continuar]
pause >nul
cls
echo %minuto% será o seu tempo de atraso de tarefa
echo agora, o tempo de atraso de um loop para o outro na vigia. 
echo em segundos
set /p "segundos=>"
echo %segundos%| findstr /r "^[0-9][0-9]*$*" || (
   echo opção inválida, apenas números são aceitos
   echo [qualquer tecla para voltar]
   pause >Nul
   cls
   goto 4
)
echo %segundos% > %atraso%
echo cada tarefa em segundo plano demorará %minutos% minnutos
echo cada pausa do loop demorará %segundos% segundos
echo esta tudo certo?
echo [1] sim
echo [2] modificar minutos
echo [3] modificar segundos
set /p "opc=>"
if "%opc%"=="1" goto menu
if "%opc%"=="2" goto minutos
if "%opc%"=="3" goto segundos
goto menu


:dv
if exist %status% powershell remove-item %STATUS% -recurse -force
if exist %temporizador% powershell remove-item %temporizador% -recurse -force
echo vigia parada
timeout /t 2 >nul
goto menu

:x
call C:\trix_cmd\5\menu-avancado.bat
exit

:falha
echo falha
pause 
goto menu
@echo off
chcp 65001
set /p menu=<C:\trix_cmd\0\menu.txt
set atualizacao-caminho=%useprofile%\ataualizacao
cls
for /F %%a in ('"prompt $E & for %%b in (1) do rem"') do set "ESC=%%a"
set rd=%%ESC%%[31m
set nl=%%ESC%%[30m
set gr=%%ESC%%[32m
set yw=%%ESC%%[33m
set bl=%%ESC%%[34m
set pl=%%ESC%%[35m
set ci=%%ESC%%[36m
set we=%%ESC%%[37m
set sd=%%ESC%%[0m
:menu
cls
call echo %bl%===================================
call echo        %gr%menu de atualização
call echo %bl%===================================
call echo        %gr%TRIX DA ATUALIZAÇÕES
call echo %gr%===================================%yw%
call echo [1] %gr%receber atualizações pelo email%yw%
call echo [2] %gr%atualizar agora%yw%
call echo [3] %gr%atualizar ao final de semana%bl%
call echo ===================================%gr%
call echo        OUTRAS ATUALIZAÇÕES%bl%
call echo ===================================%yw%
call echo [4] %gr%atualizar apps%bl%
call echo ===================================%yw%
call echo [5] %gr%voltar ao menu%rd%
if exist C:\users\%username%\dados\status\atualizacao.txt (
   call echo [D] %gr%desativar atualização automática%bl%
)
call echo  ===================================%yw%
set /p "opc=escolha uma opção: "
if "%opc%"=="1" goto 1 
if "%opc%"=="2" goto 2 
if "%opc%"=="3" goto 3
if "%opc%"=="4" goto 4
if "%opc%"=="5" %menu%
if /i "%opc%"=="D" goto d
call echo %rd%opção inváida, tente novamente!
timeout /t 2 >nul
goto menu


:1
cls
call c:\trix_cmd\5\atualizacao.bat
timeout /t 2 >nul 
goto menu

:2
cls
echo abrindo atualizações
timeout /t 2 >nul
call c:\trix_cmd\5\atualiza.bat
goto menu

:3
echo entendido, uma atualização será feita toda sexta-feira!
timeout /t 2 >nul
echo 1 > c:\users\%username%\dados\status\atualizacao.txt
schtasks /create /tn "atualizacao_automatica.bat" /tr "c:\trix_cmd\5\atualizacao_automatica.bat" /sc weekly /d FRI /f
goto menu

:4
call c:\trix_cmd\5\apps.bat
goto menu

:D
echo desativando atualização automática...
schtasks /delete /tn "atualizacao_automatica" /f
powershell remove-item -path "c:\users\%username%\dados\status\atualizacao.txt" -recurse -force
goto menu
@echo off
cls
chcp 65001
@echo off
cls
:menu
if %errorlevel% neq 0 (
   echo solicitando privilégios de adm...
   powershell -command "start-process cmd -argumentlist '/c \"%~f0\"' -verb runas"
   exit
)
if exist C:\trix_cmd\0\versao.txt set /p versao=<C:\trix_cmd\0\versao.txt
if exist C:\trix_cmd\versao\versao.txt set /p versao=<C:\trix_cmd\versao\versao.txt
if not exist C:\trix_cmd\versao (
   echo limpando arquivos antigos...
   mkdir C:\trix_cmd\versao
   set /p versao=<C:\trix_Cmd\0\versao.txt
   echo %versao%
   if not defined versao (
      powershell remove-item C:\trix_cmd\versao -recurse -force
      goto menu
   )
   powershell remove-item C:\trix_cmd\0\1*.txt -recurse -force
   powershell remove-item C:\trix_cmd\0\2*.txt -recurse -force
   powershell remove-item C:\trix_cmd\0\%versao%.txt -recurse -force
   powershell remove-item C:\trix_cmd\0\versao.txt -recurse -force
   echo %versao% > C:\trix_cmd\versao\versao.txt
   echo > C:\trix_cmd\versao\%versao%.txt
   set /p versao=<C:\trix_Cmd\versao\versao.tx
   pause
) else (
   set /p versao=<C:\trix_Cmd\versao\versao.txt
   powershell remove-item C:\trix_cmd\versao\*.txt
   echo %versao% > C:\trix_cmd\versao\versao.txt
   echo > C:\trix_cmd\versao\%versao%.txt
   pause
)
mkdir C:\at
mkdir C:\backup-trix
robocopy "C:\trix_cmd" "C:\backup-trix\trix_cmd" /E /COPYALL /R:0 /W:0
echo iniciando reinicialização
set setup=C:\trix_cmd\setup.cmd
set inicio=C:\trix_cmd\0\0-integridade.bat
set pasta=C:\at
set "destino=%pasta%\atualizacao.zip "
set "link=https://github.com/Jheads/trix/raw/main/atualizacao.zip"
curl -L -o "%destino%" "%link%"
tar -xf %destino% -C C:\at
if errorlevel 1 (
    echo erro ao extrair, abortando
    powershell remove-item C:\at -recurse -force
    powershell remove-item C:\atualizacao.zip -recurse -force
    start C:\trix_cmd\0\0_menu.bat
    powershell remove-item %userprofile%\recupera.bat
    exit
) else (
    echo sucesso na extração. verificando integridade dos pacotes...
    if exist C:\at\trix_cmd (
        powershell remove-item C:\trix_cmd -recurse -force
        mkdir C:\trix_cmd
        robocopy "C:\at\trix_cmd" "C:\trix_cmd" /E /COPYALL /R:0 /W:0
        if exist %setup% (
            taskkill /f /im explorer.exe & start explorer.exe
            powershell remove-item C:\at -recurse -force
            powershell remove-item %userprofile%\recupera.bat
            msg "*" "sucesso!"
            call %inicio%
            if not exist %setup% (
                if not exist C:\at\trix_cmd\0\0_menu.bat (
                    mkdir C:\trix_cmd
                    msg "*" "arquivos corrompidos"
                    robocopy "C:\backup-trix\trix_cmd" "C:\trix_cmd" /E /COPYALL /R:0 /W:0
                ) else (
                    robocopy "C:\at\trix_cmd" "C:\trix_cmd" /E /COPYALL /R:0 /W:0
                )
            ) else ( 
                powershell remove-item C:\backup-trix -recurse -force
            )
        ) else (
            msg "*" "erro ao extrair, executando backup..."
            robocopy "C:\backup-trix\trix_cmd" "C:\trix_cmd" /E /COPYALL /R:0 /W:0
            if not exist C:\trix_cmd\backup-trix (
                msg "*" "AVISO: erro critico de integridade, por favor faça a intalação dos sistemas manualmente"
                curl -L -o "%userprofile%\Downloads" "%link%"
                start %userprofile%\Downloads
                pause
                exit
         )
        
        )
    )
)
msg "*" "erro desconhecido"
exit /b
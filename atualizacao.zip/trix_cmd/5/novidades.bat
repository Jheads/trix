@echo off
chcp 65001
for /F %%a in ('"prompt $E & for %%b in (1) do rem"') do set "ESC=%%a"
set rd=%%ESC%%[31m
set nl=%%ESC%%[30m
set gr=%%ESC%%[32m
set yw=%%ESC%%[33m
set bl=%%ESC%%[34m
set pl=%%ESC%%[35m
set ci=%%ESC%%[36m
set we=%%ESC%%[37m
set sd=%%ESC%%[0m
set cl=%bl%
set cor=C:\users\%username%\dados\pers\cor.txt
set ln=%gr%
set linha=C:\users\%username%\dados\pers\lin.txt
if exist %linha% (
   set /p ln=<%linha%
)
set /p menu=<c:\trix_cmd\0\menu.txt
CLS
call echo %gr%========================================================================================================================%bl%
call echo                                                   TORN UPDATE
call echo %yw%========================================================================================================================%gr%
call echo atualização com inclusão de Torn, rainmeter, jaxcore e ascnii
call echo remake de algumas funções como atualização, menu, opções, boas vindas
call echo cores foram desabilitadas e voltarão a funcionar em futuras atualizações!
call echo algumas opções tiveram remake e poderão estar com bugs, mas logo serão consertadas!
call echo a proxima atualização terá o foco nas cores, correções de bugs e adição de mais funções ao Torn
call echo ========================================================================================================================%rd%
call echo Sistema trix estará em breve sendo vendido globalmente com direitos autorais e fundação de um pequeno grupo de desenvolvimento.
call echo com isso o sistema delta se encerrará em breve e as atualizações serão menos frequentes, mas não se preocupe pois quem instalou 
call echo o sistema Trix e o anti-bugs Torn na versão delta aind ficará com eles de graça.
call echo Os próximo sistema poderão serem mais pesado pois sairá da versão delta e entrará em hiato, futuras atualizações demorarão mais 
call echo tempo para serem lançadas por causa do investimento dos nossos novos sistemas e integração ao Google.
call echo atenciosamente equipe de desenvolvimento T.R.X
timeout /t 60 >nul
call echo [pressione qualquer tecla para voltar]
pause >nul
%menu%
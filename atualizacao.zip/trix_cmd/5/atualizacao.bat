@echo off
chcp 65001
set /p nome=<c:\users\%username%\dados\nome\nome.txt
set /p menu=<c:\trix_cmd\0\menu.txt
 
mode con: cols=80 lines=17
:inicio
cls
echo I======================================================I 
echo I %nome% você gostaria de receber ataulizações via email? 
echo I======================================================I
echo I [1] sim                                              I
if exist c:\users\%username%\dados\pers\dv.txt echo I [p]parar de receber atualizações                     I
echo I [2]não, voltar ao menu                               I
echo I======================================================I
echo I se o computador tiver 2 contas gmail logadas         I
echo I o sistema pode não funcionar                         I
echo I======================================================I
set /p "opc=escolha uma opção: "

if "%opc%"=="1" goto 1
if "%opc%"=="2" goto 2
if "%opc%"=="p" goto dv
echo opção inválida, tente novamente
timoeut /t 2 >nul
goto inicio

:dv
echo desativando...
schtasks /delete /tn "avisotrix" /f 
powershell remove-item -path "c:\users\%username%\dados\pers\dv.txt" -recurse -force
timeout /t 2 >nul
goto inicio

:1
echo entendido! abrindo email
start mailto:usua2947@gmail.com?subject=Solicitacao_de_Atualizacoes&body=Quero_receber_atualizacoes_da_Trix
"
schtasks /create /tn "avisoTrix" ^ /tr "cmd /c c:\trix_cmd\0\1.bat" ^ /sc onstart /ru system /f
echo 1 > c:\users\%username%\dados\pers\dv.txt
timeout /t 2 >nul
goto inicio

:2
echo entendido! voltando ao menu
timeout /t 2 >nul
%menu%

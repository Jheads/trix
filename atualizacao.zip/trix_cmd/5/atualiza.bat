@echo off
chcp 65001 >nul
set /p menu=<c:\trix_cmd\0\menu.txt
if not exist c:\att mkdir c:\att
if exist c:\users\%username%\dados\status\1.txt (
   powershell remove-item -path C:\users\%username%\dados\status\1.txt -recurse -force
)
setlocal enabledelayedexpansion

REM Tentativa de pasta principal
set "pasta=C:\trix_cmd"
set /p menu=<%pasta%\0\menu.txt

if exist c:\trix_cmd\atualizacao.zip (
   goto inicio
)

REM Testa se consegue criar no C:
if not exist %pasta% mkdir "%pasta%" >nul 2>&1
if errorlevel 1 (
    echo Nao foi possivel criar em C:\. Salvando em Downloads...

    set "pasta=%USERPROFILE%\Downloads\trix_cmd"
    mkdir "%pasta%"
)

REM Caminho da versao
set /p arquivo=<%pasta%\versao.txt

REM Cria um arquivo de versão falso (caso não exista, só pra fins de teste)
if not exist "%arquivo%" (
    echo delta > "%arquivo%"
)

REM Extrai a versao do nome do arquivo
for %%A in ("%arquivo%") do (
    set "versao=%%~nA"
)
    set "destino=%pasta%\atualizacao.zip"
    set "link=https://github.com/Jheads/trix/raw/main/atualizacao.zip"

    curl -L -o "!destino!" "!link!"

    if exist "!destino!" (
        echo.
        echo Download conclúido com sucesso.
        echo.
        echo Extraindo arquivos...
        powershell -Command "Expand-Archive -Path '!destino!' -DestinationPath '%pasta%' -Force"
        tar -xf c:\trix_cmd\atualizacao.zip -C C:\att
        if errorlevel 1 (
            echo Erro ao extrair. Verifique se à internet.
        ) else (
            echo verificação conclúida com sucesso!
        )
    ) else (
        echo Erro ao verificar atualização.
    )
set /p versao=<c:\trix_cmd\0\versao.txt
:inicio
set /p ver=<c:\trix_cmd\0\versao.txt
if exist c:\att\trix_cmd\0\%ver%.txt goto 11
cls
if exist c:\trix_cmd\atualizacao.zip (
   echo [atualização pendente]
)
echo ===============================
echo        INSTALADOR DO SISTEMA
echo ===============================
echo Versao atual detectada: !versao!
echo Pasta de instalação:    %pasta%
echo ===============================

echo.
echo [1] Baixar e instalar atualizacao
echo [2] Voltar ao menu
echo.

set /p opcao=Escolha uma opção: 
if "!opcao!"=="1" (
    echo 1 > c:\users\%username%\dados\status\%opcao%.txt
    powershell start c:\trix_cmd\5\atualizacao_automatica.bat
    exit
)
if "!opcao!"=="2" (
    powershell remove-item c:\trix_cmd\*.zip -recurse -force
    %menu%
    goto inicio
)
echo Opção inválida.
goto inicio
:11
echo ==========================
echo sistema já está atualizado
echo ==========================
timeout /t 2 >nul
%menu%
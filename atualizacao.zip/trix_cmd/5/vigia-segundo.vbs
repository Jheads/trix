set objshell = createobject("wscript.shell")
objshell.run "C:\trix_cmd\5\vigia.bat", 0, false
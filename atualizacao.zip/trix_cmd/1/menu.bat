echo 1 > %userprofile%\dados\status\menu-inicia.txt
call c:\trix_cmd\1\chama.bat
cls
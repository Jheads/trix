@echo off
chcp 65001
net session >nul 2>&1
if %errorlevel% neq 0 (
   echo solicitando privilégios de adm...
   powershell -command "start-process cmd -argumentlist '/c \"%~f0\"' -verb runas"
   exit
)
if exist C:\trix_cmd\cache\dialogo.txt goto menu
echo AVISO: algumas oções mesmo após desativadas 
echo ficam em ocioso esperando confirmação.
echo isso pode confundir o sistema e acabar
echo aparecendo que a opção esta ativada.
echo para verificar segure a tecla windows + R
echo e digite "services.msc"
echo [PRESIONE QUALQUER TECLA PARA CONTINUAR]
pause >nul
echo > C:\trix_cmd\cache\dialogo.txt
:menu
cls
echo AVISO: ANTES DE DESATIVAR QUALQUER PROCESSO
ECHO PESQUISE O QUE O PROCESSO FAZ E CONCLUA
ECHO SE IRÁ AFETAR O SEU USO DO WINDOWS
echo =========================================
echo recomendação de processos para desativar
echo =========================================
sc query SysMain | findstr "STOPPED" >nul
if errorlevel 1 (
    echo [1] desativar SysMain
) else (
    echo [1] ativar SysMain
)
sc query DiagTrack | findstr  "STOPPED" >nul
if errorlevel 1 (
    echo [2] desativar DiagTrack
) else (
    echo [2] ativar DiagTrack
)
sc query wsearch | findstr "STOPPED" >nul
if errorlevel 1 (
    echo [3] desativar pesquisa do windows
) else (
    echo [3] ativar pesquisa do windows
)
sc query spooler | findstr "STOPPED" >nul
if errorlevel 1 (
    echo [4] desativar serviços de impressão
) else (
    echo [4] ativar serviços de impressão
)
sc query XboxGipSvc | findstr "STOPPED" >nul
if errorlevel 1 (
    echo [5] desativar xbox gamebar
) else (
    echo [5] ativar xbox gamebar
)
sc query walletservice | findstr "STOPPED" >nul
if errorlevel 1 (
    echo [6] desativar windows wallet
) else (
    echo [6] ativar windows wallet
)
sc query TapiSrv | findstr "STOPPED" >nul
if errorlevel 1 (
    echo [7] desativar serviços de telefonia
) else (
    echo [7] ativar serviços de telefonia
)
sc query TermService | findstr "STOPPED" >nul
if errorlevel 1 (
    echo [8] desativar área de trabalho remota
) else (
    echo [8] ativar área de trabalho remota
)
sc query wuauserv | findstr "STOPPED" >nul
if errorlevel 1 (
    echo [9] desativar windows update
) else (
    echo [9] ativar windows update
)
sc query WerSvc | findstr "STOPPED" >nul
if errorlevel 1 (
    echo [10] desativar relatórios do windows 
) else (
    echo [10] ativar relatórios do windows 
)
sc query SENS | findstr "STOPPED" >nul
if errorlevel 1 (
    echo [11] desativar notificações de eventos do windows 
) else (
    echo [11] ativar notificações de eventos do windows 
)
sc query BDESVC | findstr "STOPPED" >nul
if errorlevel 1 (
    echo [12] desativar criptografiade bitlocker
) else (
    echo [12] ativar criptografia de bitlocker
)
sc query WbioSrvc | findstr "STOPPED" >nul
if errorlevel 1 (
    echo [13] desativar biometria do windows
) else (
    echo [13] ativar biometria do windows 
)
sc query RemoteRegistry | findstr "STOPPED" >nul
if errorlevel 1 (
    echo [14] desativar serviço remoto
) else (
    echo [14] ativar serviço remoto
)
sc query EventLog | findstr "STOPPED" >nul
if errorlevel 1 (
    echo [15] desativar logs de eventos do windows
) else (
    echo [15] ativar logs de eventos do windows 
)
sc query edgeupdate | findstr "STOPPED" >nul
if errorlevel 1 ( 
    echo [16] desativar microsoft edge
) else (
    echo [16] ativar microsoft edge
)
sc query ScardSvr | findstr "STOPPED" >nul
if errorlevel 1 ( 
    echo [17] desativar cartão inteligente
) else (
    echo [17] ativar cartão inteligente
)
echo [s] verificar status (caso haja erro de leitura)
echo [P] procurar processos
echo [x] voltar
echo ==========================================
set /p "opc=> "
echo procurando opção...
if "%opc%"=="1" goto 1
echo procurando opção..
if "%opc%"=="2" goto 2
echo procurando opção.
if "%opc%"=="3" goto 3
echo procurando opção..
if "%opc%"=="4" goto 4
echo procurando opção...
if "%opc%"=="5" goto 5
echo procurando um pão de queijo..
if "%opc%"=="6" goto 6
echo procurando opção..
if "%opc%"=="7" goto 7
echo procurando opção.
if "%opc%"=="8" goto 8
echo procurando opção..
if "%opc%"=="9" goto 9
echo procurando opção...
if "%opc%"=="10" goto 10
echo procurando opção..
if "%opc%"=="11" goto 11
echo procurando opção.
if "%opc%"=="12" goto 12
echo procurando opção..
if "%opc%"=="13" goto 13
echo procurando opção...
if "%opc%"=="14" goto 14
echo demora....
if "%opc%"=="15" goto 15
echo procurando opção...
if "%opc%"=="16" goto 16
echo procurando opção
if "%opc%"=="17" goto 17
echo opção não encontrada!
if /i "%opc%"=="R9" goto R9
if /i "%opc%"=="x" goto x
if /i "%opc%"=="p" goto p
if /i "%opc%"=="S" goto status
echo opção inválida, tente novamente
timeout /t 2 >nul
goto menu

:status
echo stopped significa parado
echo start significa iniciado/iniciando 
echo running significa em execução/rodando
echo pending significa pendente
echo =========SysMain
sc query SysMain
echo =========diagtrack
sc query DiagTrack
echo =========pesquisa do windows
sc query wsearch
echo =========serviços de impressão
sc query spooler
echo =========serviços do xbox
sc query XboxGipSvc
sc query XblGameSave
sc query XboxNetApiSvc
sc query XblAuthManager
echo ==========carteira da microsoft
sc query walletservice 
echo ==========serviços de telefonia
sc query TapiSrv
sc query PhoneSvc
echo ==========area de trabalho remota
sc query TermService
echo ==========windows update
sc query wuauserv
echo ==========relatórios do windows 
sc query WerSvc
echo ==========notificações de eventos do Windows
sc query SENS
echo ==========criptografia de bitlocker
sc query BDESVC 
echo ========== biometria do windows 
sc query WbioSrvc
echo ========serviço remoto 
sc query RemoteRegistry
echo ========logs de eventos do windows 
sc query EventLog
echo =======cartão inteligente
sc query ScardSvr
sc query SCPolicySvc
echo ========= microsoft edge
sc query edgeupdatem
sc query edgeupdate
sc query MicrosoftEdgeElevationService
pause
goto menu

:17
sc query ScardSvr
sc query ScardSvr | findstr "STOPPED"
if errorlevel 1 (
    echo o processo esta ativado. desativando processo....
    sc stop ScardSvr
    sc stop SCPolicySvc
    sc config ScardSvr start= disabled
    sc config SCPolicySvc start= disabled
) else (
    echo o processo esta desativado. ativando processo...
    sc config ScardSvr start= auto
    sc config SCPolicySvc start= auto
    sc start ScardSvr
    sc start SCPolicySvc
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit

:16
sc query edgeupdatem
sc query edgeupdate
sc query MicrosoftEdgeElevationService
sc query edgeupdate | findstr "STOPPED"
if errorlevel 1 (
    echo o processo esta ativado. desativando processo....
    sc stop edgeupdate
    sc stop MicrosoftEdgeElevationService
    sc stop edgeupdatem
    sc config edgeupdate start= disabled
    sc config MicrosoftEdgeElevationService start=disabled
    sc config edgeupdate start= disabled
) else (
    echo o processo esta desativado. ativando processo...
    sc config edgeupdate start= auto
    sc config edgeupdatem start= auto
    sc config MicrosoftEdgeElevationService start= auto
    sc start edgeupdate
    sc start MicrosoftEdgeElevationService
    sc start edgeupdatem
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit


:15
sc query EventLog
sc query EventLog | findstr "STOPPED"
if errorlevel 1 (
    echo o processo esta ativado. desativando processo....
    sc stop EventLog
    sc config EventLog start= disabled
) else (
    echo o processo esta desativado. ativando processo...
    sc config EventLog start= auto
    sc start EventLog
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit


:14
sc query RemoteRegistry
sc query RemoteRegistry | findstr "STOPPED"
if errorlevel 1 (
    echo o processo esta ativado. desativando processo....
    sc stop RemoteRegistry
    sc config RemoteRegistry start= disabled
) else (
    echo o processo esta desativado. ativando processo...
    sc config RemoteRegistry start= auto
    sc start RemoteRegistry
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit


:13
sc query WbioSrvc
sc query WbioSrvc | findstr "STOPPED"
if errorlevel 1 (
    echo o processo esta ativado. desativando processo....
    sc stop WbioSrvc
    sc config WbioSrvc start= disabled
) else (
    echo o processo esta desativado. ativando processo...
    sc config WbioSrvc start= auto
    sc start WbioSrvc
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit

:12
sc query BDESVC
sc query BDESVC | findstr "STOPPED"
if errorlevel 1 (
    echo o processo esta ativado. desativando processo....
    sc stop BDESVC
    sc config BDESVC start= disabled
) else (
    echo o processo esta desativado. ativando processo...
    sc config BDESVC start= auto
    sc start BDESVC
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit

:11
sc query SENS
sc query SENS | findstr "STOPPED"
if errorlevel 1 (
    echo o processo esta ativado. desativando processo....
    sc stop SENS
    sc config SENS start= disabled
) else (
    echo o processo esta desativado. ativando processo...
    sc config SENS start= auto
    sc start SENS
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit


:10
sc query WerSvc
sc query WerSvc | findstr "STOPPED"
if errorlevel 1 (
    echo o processo esta ativado. desativando processo....
    sc stop WerSvc
    sc config WerSvc start= disabled
) else (
    echo o processo esta desativado. ativando processo...
    sc config WerSvc start= auto
    sc start WerSvc
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit



:9
echo sucesso!
wmic os get Caption | findstr "10" >nul
if errorlevel 1 (
    cls
    echo [RECUSADO, seu windows ainda tem updates.]
    echo se quiser desativar o windows update mesmo assim 
    echo digite R9
    timeout /t 2 >nul
    goto menu
)
wmic os get Caption | findstr /i "ltsc" >nul
if errorlevel 1 (
    echo passou 
) else (
    cls
    echo [RECUSADO, seu computador windows ltsc ainda tem updates.]
    echo se quiser desativar o windows update mesmo assim 
    echo digite R9
    timeout /t 2 >nul
    goto menu
)
:R9
sc query wuauserv
sc query wuauserv | findstr "STOPPED"
if errorlevel 1 (
    echo o processo esta ativado. desativando processo....
    sc stop wuauserv
    sc config wuauserv start= disabled
    if errorlevel 1 ( 
        msg "*" "ação bloqueada pelo sistema, forçando remoção"
            reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" /v NoAutoUpdate /t REG_DWORD /d 1 /f
            reg add "HKLM\SYSTEM\CurrentControlSet\Services\wuauserv" /v Start /t REG_DWORD /d 4 /f
            reg add "HKLM\SYSTEM\CurrentControlSet\Services\wuauserv" /v Start /t REG_DWORD /d 4 /f
            reg add "HKLM\SYSTEM\CurrentControlSet\Services\UsoSvc" /v Start /t REG_DWORD /d 4 /f
            reg add "HKLM\SYSTEM\CurrentControlSet\Services\WaaSMedicSvc" /v Start /t REG_DWORD /d 4 /f

    )
) else (
    echo o processo esta desativado. ativando processo...
    sc config wuauserv start= auto
    sc start wuauserv
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit

:8
sc query TermService
sc query TermService | findstr "STOPPED"
if errorlevel 1 (
    echo o processo esta ativado. desativando processo....
    sc stop TermService
    sc config TermService start= disabled
) else (
    echo o processo esta desativado. ativando processo...
    sc config TermService start= auto
    sc start TermService
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit

:7
sc query TapiSrv
sc query PhoneSvc
sc query TapiSrv | findstr "STOPPED"
if errorlevel 1 (
    echo o processo esta ativado. desativando processo....
    sc stop TapiSrv
    sc stop PhoneSvc
    sc config TapiSrv start= disabled
    sc config PhoneSvc start= disabled
    if errorlevel 1 (
        reg add "HKLM\SYSTEM\CurrentControlSet\Services\TapiSrv" /v Start /d 4
        msg "*" "o processo será desativado após reiniciar o computador"
    )
    pause
) else (
    echo o processo esta desativado. ativando processo...
    sc config PhoneSvc start= auto
    sc config TapiSrv start= auto
    sc start PhoneSvc
    sc start TapiSrv
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit


:6
sc query walletservice
sc query walletservice | findstr "STOPPED"
if errorlevel 1 (
    echo o processo esta ativado. desativando processo....
    sc stop walletservice
    sc config walletservice start= disabled
    if errorlevel 1 (
        reg add "HKLM\SYSTEM\CurrentControlSet\Services\WalletService" /v Start /t REG_DWORD /d 4 /f
        msg "*" "wallet service será desativado após reinicialiazção, reinicie o computador para concluir"
    )
    pause
) else (
    echo o processo esta desativado. ativando processo...
    reg add "HKLM\SYSTEM\CurrentControlSet\Services\WalletService" /v Start /t REG_DWORD /d 2 /f
    sc config walletservice start= auto
    sc start walletservice
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit

:5
sc query xboxgipsvc
sc query XboxGipSvc | findstr "STOPPED"
if errorlevel 1 (
    echo o processo está ativado. desativando processo....
    sc stop XboxGipSvc
    sc stop XblGameSave
    sc stop XboxNetApiSvc
    sc stop XblAuthManager
    sc config XboxGipSvc start= disabled
    sc config XblGameSave start= disabled
    sc config XboxNetApiSvc start= disabled
    sc config XblAuthManager start= disabled
    pause
) else (
    echo o processo está desativado. ativando processo...
    reg add "HKLM\SYSTEM\CurrentControlSet\Services\XboxGipSvc" /v Start /t REG_DWORD /d 2 /f
    sc config xboxgipsvc start= auto
    sc congig XblGameSave start= auto
    sc config XboxNetApiSvc start= auto
    sc config XblAuthManager start= auto
    sc start XblAuthManager
    sc start XboxNetApiSvc
    sc start xboxgipsvc
    sc start XblGameSave
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit

:4
sc query spooler
sc query spooler | findstr "STOPPED"
if errorlevel 1 (
    echo o processo esta ativado. desativando processo....
    sc stop spooler
    sc config spooler start= disabled
) else (
    echo o processo esta desativado. ativando processo...
    sc config spooler start= auto
    sc start spooler
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit

:3
sc query wsearch
sc query wsearch | findstr "STOPPED"
if errorlevel 1 (
    echo o processo esta ativado. desativando processo....
    sc stop wsearch
    sc config wsearch start= disabled
) else (
    echo o processo esta desativado. ativando processo...
    sc config wsearch start= auto
    sc start wsearch
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit

:1
sc query SysMain
sc query SysMain | findstr "STOPPED"
if errorlevel 1 (
    echo o processo esta ativado. desativando processo....
    sc stop SysMain
    sc config SysMain start= disabled
) else (
    echo o processo esta desativado. ativando processo...
    sc config SysMain start= auto
    sc start SysMain
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit

:2
sc query diagtrack | findstr  "STOPPED"
if errorlevel 1 ( 
    echo desativando DiagTrack
    sc stop DiagTrack
    sc config DiagTrack start= disabled
) else (
    echo ativando DiagTrack
    sc config DiagTrack start= auto
    sc start DiagTrack
)
timeout /t 2 >nul
start C:\trix_cmd\1\processos-auto.bat
exit

:p
cls
echo ========================================
echo [1] remover processo personalizado
echo [2] adicionar processo personalizado
echo [x] voltar
echo ========================================
set /p "opc=>"
if "%opc%"=="1" goto p1
if "%opc%"=="2" goto p2
if /i "%opc%"=="x" goto menu
echo opção inválida, tente novamente
timeout /t 2 >nul
goto P

:p1
cls
set /p "opc=escreva o nome do processo que deseja remover: "
sc query %opc% | findstr  "STOPPED"
if errorlevel 1 ( 
    echo desativando %opc%
    sc stop %opc%
    sc config %opc% start= disabled
)
timeout /t 2 >nul
goto P

:p2
cls
set /p "opc=escreva o nome do processo que deseja adicionar: "
sc query %opc% | findstr  "RUNNING"
if errorlevel 1 ( 
    echo ativando processo...
    sc config %opc% start= auto
    sc start %opc%
) else (
    echo %opc% não está em execução
) 
sc query %opc% | findstr  "RUNNING"
if errorlevel 1 ( 
    echo %opc% não existe ou não foi executado. buscando pela segunda via...
)
sc query %opc% | findstr  "STOPPED"
if errorlevel 1 ( 
    echo %opc% não existe
) else (
    echo %opc% está ativo, fora de execução
)
goto p

:x
call C:\trix_cmd\1\processos.bat
goto menu
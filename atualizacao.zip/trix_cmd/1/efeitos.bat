@echo off
chcp 65001 >nul
cls 
echo verificando integridade dos códigos...
echo testando códigos...
setlocal enabledelayedexpansion
set /p menu=<C:\trix_cmd\0\menu.txt
if exist "C:\users\%username%\dados\nome\nome.txt" (
   for /f "usebackq delims=" %%a in ("C:\users\%username%\dados\nome\nome.txt") do (
       set  nome=%%a
   )
)
echo nome: "%nome%"

for /F "tokens=1 delims=:" %%H in ("%TIME%") do (
    set hora=%%H
)
set hora=%hora: =%
if "%hora:~0,1%"=="0" set hora=%hora:~1%
set msg=Boa noite!
if %hora% GEQ 5 if %hora% LSS 12 set msg=Bom dia!
if %hora% GEQ 12 if %hora% LSS 18 set msg=Boa tarde!

echo %msg% %nome%
for /F %%a in ('"prompt $E & for %%b in (1) do rem"') do set "ESC=%%a"
set rd=%%ESC%%[31m
set nl=%%ESC%%[30m
set gr=%%ESC%%[32m
set yw=%%ESC%%[33m
set bl=%%ESC%%[34m
set pl=%%ESC%%[35m
set ci=%%ESC%%[36m
set we=%%ESC%%[37m
set sd=%%ESC%%[0m
set ln=%gr%
set cl=%pl%
set c11=%userprofile%\dados\pers\cor\cl
set L11=%userprofile%\dados\pers\cor\ln
if exist %c11%\rd.txt (
   set cl=%rd%
)
if exist %c11%\nl.txt (
   set cl=%nl%
)
if exist %c11%\gr.txt (
   set cl=%gr%
)
if exist %c11%\yw.txt (
   set cl=%yw%
)
if exist %c11%\bl.txt (
   set cl=%bl%
)
if exist %c11%\pl.txt (
   set cl=%pl%
)
if exist %c11%\ci.txt (
   set cl=%ci%
)
if exist %c11%\we.txt (
   set cl=%we%
)
if exist %c11%\sd.txt (
   set cl=%sd%
)
::linhas
if exist %L11%\rd.txt (
   set ln=%rd%
)
if exist %l11%\nl.txt (
   set ln=%nl%
)
if exist %l11%\gr.txt (
   set ln=%gr%
)
if exist %l11%\yw.txt (
   set ln=%yw%
)
if exist %l11%\bl.txt (
   set ln=%bl%
)
if exist %l11%\pl.txt (
   set ln=%pl%
)
if exist %l11%\ci.txt (
   set ln=%ci%
)
if exist %l11%\we.txt (
   set ln=%we%
)
if exist %l11%\sd.txt (
   set ln=%sd%
)

cls
:menu
color 2
cls
call echo %cl%===========================================================
call echo                       %ln%efeitos visuais%cl%
call echo ============================================================%gr%
call echo [1] %ln%melhor desempenho%gr%
call echo [2] %ln%melhor aparência%gr%
call echo [3] %ln%automatico%gr%
call echo [4] %ln%voltar%cl%
call echo ============================================================%rd%
call echo 1-desativa todas as animações, mas diminui os travamentos
call echo 2-ativa todas as animações, mas deixa o computador mais lento
call echo 3- o windows escolhe quais animações seu computador precisa%cl%
call echo =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-%yw%
set /p "opc=escolha uma opção= "

if "%opc%"=="1" goto 1
if "%opc%"=="2" goto 2
if "%opc%"=="3" goto 3
if /i "%opc%"=="x" goto x
call echo %rd%opção inválida, tente novamente
timeout /t 3 >nul
goto menu

:1
echo melhor desempenho ativado, desativando animações
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 2 /f

reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v ListviewAlphaSelect /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v ListviewShadow /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarAnimations /t REG_DWORD /d 0 /f
reg add "HKCU\Control Panel\Desktop" /v DragFullWindows /t REG_SZ /d 0 /f
reg add "HKCU\Control Panel\Desktop" /v FontSmoothing /t REG_DWORD /d 0 /f
reg add "HKCU\Control Panel\Desktop" /v UserPreferencesMask /t REG_BINARY /d 9012038010000000 /f
taskkill /f /im explorer.exe & start explorer.exe
timeout /t 3 >nul
goto per

:per
echo %nome% deseja reiniciar o computador agora para aplicar as mudanças? pressione (S) para sim e (N) para não
set /p "opc= reinciar? "

if /i "%opc%"=="s" goto sim
if /i "%opc%"=="sim" goto sim
if /i "%opc%"=="n" goto nao 
if /i "%opc%"=="não" goto nao
if /i "%opc%"==="nao" goto nao

:nao
echo ok, a proxima vez que ele for desligado irei finalizar a limpeza. 
echo [pressione qualquer tecla para continuar]
pause >nul
goto menu

:sim
echo entendido, em 10 segundos seu computador irá ser reiniciado, se tiver algo não salvo, salve-o
timeout /t 10 /nobreak
call C:\trix_cmd\2\informacoes.bat

:2
echo melhor aparência ativada, ativando animações
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 1 /f

reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v ListviewAlphaSelect /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v ListviewShadow /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarAnimations /t REG_DWORD /d 1 /f
reg add "HKCU\Control Panel\Desktop" /v DragFullWindows /t REG_SZ /d 1 /f
reg add "HKCU\Control Panel\Desktop" /v FontSmoothing /t REG_DWORD /d 2 /f
reg add "HKCU\Control Panel\Desktop" /v UserPreferencesMask /t REG_BINARY /d 9E1E078012000000 /f

taskkill /f /im explorer.exe & start explorer.exe
timeout /t 3 >nul
goto per

:3
echo windows irá escolher automaticamente a melhor opção para %nome%
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 0 /f

taskkill /f /im explorer.exe & start explorer.exe
timeout /t 3 >nul
goto per

:x
echo voltando..
timeout /t 3 >nul
%menu%
exit
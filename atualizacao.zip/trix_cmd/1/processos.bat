@echo off 
chcp 65001
:menu
cls
echo ====================================================
echo             gerenciador de processos
echo ====================================================
echo [1] gerenciar manualmente processos
echo [2] otimização automática de processos [BETA]
echo [3] otimizações de politicas de grupo [BETA]
echo [x] voltar
echo ====================================================
set /p "opc=> "
if "%opc%"=="1" goto inicio
if "%opc%"=="2" goto proc-gerenciador
if "%opc%"=="3" goto polikit
if /i "%opc%"=="x" goto x
echo opção inválida, tente novamente
timeout /t 2 >nul
goto menu

:proc-gerenciador
call C:\trix_cmd\1\processos-auto.bat
goto menu
:polikit
call C:\trix_cmd\1\politicas.bat
goto menu
:inicio
cls
echo ====================================
echo     processos em segundo plano 
echo =====================================
echo [1] escolher processos para finalizar
echo [2] ver processos ativos
echo [3] ver processos em segundo plano
echo [4] ativar processos
echo [x] voltar ao menu 
set /p "opc=> "

if "%opc%"=="1" cls & goto 1
if "%opc%"=="2" cls & goto 2
if "%opc%"=="3" cls & goto 3
if "%opc%"=="4" cls & goto 4
if "%opc%"=="x" cls & goto menu
echo opção inválida, tente novamente!
timeout /t 2 >nul
goto inicio

:4
cls
echo cerifique-se que o processo exista
echo  [x] voltar ao menu
set /p "processo=qual processo irá desativar? "
if "%processo%"=="x" goto inicio
pause
echo %processo% > "c:\trix_cmd\cache\processo.txt"
set %processo%=< c:\trix_cmd\cache\processo.txt
tasklist | findstr "%processo%" 
if errorlevel 1 ( 
    cls
    start %processo%
    if errorlevel 1 (
        echo processo não pode ser ativo
        echo motivo: processo inexistente ou bloqueado
        echo testando segunda via...
        timeout /t 2 >nul 
        goto inicio
    )
) else (
    cls
    echo o processo já esá ativado. executando-o novamente
    start %processo%
    timeout /t 2 >nul
    goto inicio
)
tasklist | findstr "%processo%" 
if errorlevel 1 ( 
    echo processo inválido ou não encontrado
) 
goto inicio

:1
tasklist 
echo para desativar algum processo é so copiar e escreve-lo aqui, cuidado se não souber mexer nisso então volte para o menu
echo AVISO: não finalize qualquer processo, caso contrario poderá causar danos ao windows
echo  [x] voltar ao menu
set /p "processo=qual processo irá desativar? "
if "%processo%"=="x" goto inicio
pause
echo %processo% > "c:\trix_cmd\cache\processo.txt"
set %processo%=< c:\trix_cmd\cache\processo.txt
tasklist | findstr "%processo%" 
if errorlevel 1 (
    echo esse processo não existe ou já está desativado
    timeout /t 2 >nul
    goto inicio
) else (
    echo finalizando pela via1
    taskkill /f /im %processo%
    echo finalizando pela via2 
    taskkill /f /im %processo%.exe
    echo processo finalizado com sucesso, voltando ao incio!
    timeout /t 2 >nul
    goto inicio
)

:2
tasklist
echo todos os processos ativos foram listados!
ECHO [PRESSIONE QUALQUER TECLA PARA VOLTAR]
pause >nul
goto inicio

:3
tasklist /v
echo processos em segundo plano listados!
echo [PRESSIONE QUALQUER TECLA PARA VOLTAR]
pause >nul
goto inicio

:x
echo voltando ao menu...
timeout /t 2 >nul
call c:\trix_cmd\1\escolha.bat
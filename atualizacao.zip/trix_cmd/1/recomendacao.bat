@echo off
chcp 65001
color 2
cls 
echo verificando integridade dos códigos...
echo testando códigos...
setlocal enabledelayedexpansion

if exist "C:\trix_cmd\nome.txt" (
   for /f "usebackq delims=" %%a in ("C:\trix_cmd\nome.txt") do (
       set  nome=%%a
   )
)
echo nome: "%nome%"

for /F "tokens=1 delims=:" %%H in ("%TIME%") do (
    set hora=%%H
)
set hora=%hora: =%
if "%hora:~0,1%"=="0" set hora=%hora:~1%
set msg=Boa noite!
if %hora% GEQ 5 if %hora% LSS 12 set msg=Bom dia!
if %hora% GEQ 12 if %hora% LSS 18 set msg=Boa tarde!
set /p menu=<C:\trix_cmd\menu.txt
echo %msg% %nome%
cls
echo ===================================
echo        carregando ajuda...
echo ===================================
timeout /t 5 >nul
cls
echo ======================================================================================
echo se estiver em dúvida em qual opção escolher
echo responda essas perguntas para vermos a melhor recomendação de performance para seu pc.
echo ======================================================================================
pause
goto menu

:menu
color 2
cls
echo ==========================================================================
echo seu computador descarrega rápido ou tem pouca ram?
echo [1] sim
echo [2] não
echo [3] não sei quanta ram ou armazenamento meu computador tem
echo [4] meu computador tem menos ram ou mais de ram
echo [5] voltar
echo [x] menu
echo ===========================================================================
set /p "opc=escolha uma opção= " 
if "%opc%"=="1" goto 2
if "%opc%"=="2" goto não0 & echo opções de economias mais baixas
if "%opc%"=="3" goto infos
if "%opc%"=="4" goto 1
if "%opc%"=="5" call C:\trix_cmd\1\1a-performace.bat
if /i "%opc%"=="x" %menu%
echo opção inválida, tente novamente
timeout /t 1 >nul
goto menu

:2
color 2
cls
echo ============================================
echo informações mais precisas...
echo ============================================
timeout /t 3 >nul
goto 21
:21
color 2
cls
echo ===============================================
echo selecione uma opção abaixo
echo ===============================================
echo [1] meu computador tem bastante ram mas trava
echo [2] meu computador tem pouca ram mas não trava 
echo [3] meu computador não dura a bateria, mas tem ram
echo [4] não sei o que é ram ou quanto tenho
set /p "opt=escolha uma opção= "
if "%opt%"=="1" goto 2opt1
if "%opt%"=="2" goto 2opt2
if "%opt%"=="3" goto 2opt3
if "%opt%"=="4" goto infos
echo opção inválida, tente novamente
timeout /t 1 >nul
goto 21

:2opt1
color 5
cls
echo seria aconselhavel fazer uma limpeza em seu computador e coloca-lo no modo alto desempenho, mesmo que ele não dure a bateria, se quiser que ele dure mais a bateria coloque em equilibrado, mas ele irá travar mais
echo irei ativar o alto desempenho e o enviar para a limpeza diretamente...
echo ativando alto desempenho...
timeout /t 1 >nul
powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
if %errorlevel% neq 0 (
  echo erro ao ativar o esquema 'alto desempenho'. verifique o GUID ou permissoes.
pause
goto menu
)
echo 'alto desempenho' foi ativado!
timeout /t 5 >nul
echo para iniciar a limpeza
pause
call C:\trix_cmd\2\2trix-limpeza.bat

:2opt2
color 5
cls
echo então seu computador está em boas condições, recomendavel usar o alto desempenho ou equlibrado
timeout /t 5 >nul 
echo redirecionando para o menu de perfomance...
timeout /t 10 >nul
call C:\trix_cmd\1\1a-trix-performace.bat
timeout /t 1 >nul
exit

:2opt3
color 5
cls 
echo então seu computador deve ser trocada a bateria.
echo se quiser um desempenho melhor ative o alto desempenho
echo já se quiser uma duração maior da bateria ative o equilibrado ou a economia de bateria
echo [para confirmar a leitura clique em qualquer tecla]
pause
call C:\trix_cmd\1\1a-trix-performace.bat
timeout /t 1 >nul
exit

:infos 
color 5
cls
echo ========================================================================
echo entendo, vou enviar as informações de seu computador, espere um pouco...
echo ========================================================================
cls 
echo ========================================================================
echo                                MEMÓRIA RAM 
ECHO ========================================================================
powershell "get-wmiobject win32_computersystem | foreach-object { [math]::round($_.totalphysicalmemory / 1gb, 2) }"
ECHO ========================================================================
ECHO                              ARMAZENAMENTO
ECHO ========================================================================
powershell "Get-PSDrive C | Select-Object @{Name='Total (GB)';Expression={[math]::Round(($_.Used + $_.Free) / 1GB, 2)}}, @{Name='Livre (GB)';Expression={[math]::Round($_.Free / 1GB, 2)}}"
echo o primeiro número diz quanto de ram %nome% tem.
echo =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
echo precisa de mais dados?
echo =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=
echo para continuar para o outro menu
pause
goto moinf

:moinf
color 5
cls
echo ===============================================
echo        precisa de mais informações?
echo ===============================================
echo digite s para sim e n para não
echo ===============================================
set /p "opt=escolha uma opção= "
echo opção inválida, tente novamente
if "%opt%"=="n" goto nn
if "%opt%"=="s" goto ss
if "%opt%"=="sim" goto ss
if "%opt%"=="nao" goto nn
if "%opt%"=="não" goto nn

:ss
cls 
echo entendido, voltando para o menu..... 
timeout /t 5 >nul 
goto menu

:nn
cls
echo entendido, vou passar algumas informações mais completas... 
timeout /t 5 >nul & systeminfo 
echo [pressione qualquer tecla para voltar] 
pause 
cls 
goto menu

:não0
color 2
cls
echo ==============================================================
echo ok, seu computador tem menos de 6 de ram e 20 de armazenamento
echo seu pc é um notebook? se sim ele descarrega rapido?
echo [1] sim, ele descarrega e é um notebook
echo [2] não, ele não descarrega ou não é um notebook
echo -==============================================================
set /p "opy=escolha uma opção= "
echo opção inválida, tente novamente
if "%opy%"=="1" goto n1
if "%opy%"=="2" goto s1
echo opção inválida, tente novamente
timeout /t 1 >nul
goto não0

:s1
color 5
cls
echo ======================================
echo então a melhor opção é alto desempenho
echo ======================================
echo ativando alto desempenho...
timeout /t 1 >nul
powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
if %errorlevel% neq 0 (
  echo erro ao ativar o esquema 'alto desempenho'. verifique o GUID ou permissoes.
pause
goto menu
)
echo 'alto desempenho' foi ativado!
timeout /t 5 >nul
goto menu
exit

:n1
color 5
cls
echo ======================================
echo então a melhor opção é equilibrado
echo ======================================
echo ativando equilibrado...
timeout /t 1 >nul
powercfg /setactive 381b4222-f694-41f0-9685-ff5bb260df2e
if %errorlevel% neq 0 (
  echo erro ao ativar o esquema 'equilibrado'. verifique o GUID ou permissoes.
timeout /t 10 >nul
goto menu
)
echo 'equilibrado' foi ativado!
timeout /t 5 >nul
goto menu
exit

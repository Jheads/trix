@echo off
chcp 65001
:menu
cls
echo ===================================
echo       INICIALIZAÇÃO RÁPIDA
echo ===================================
echo [1] desativar inicialização rápida
echo [2] suspender ao desligar
echo [3] hibernar ao desligar
echo [x] voltar
echo ===================================
echo 1 desliga o computador totalmente
echo.
echo 2 suspende o computador para uma 
echo inicialização rápida, mesmo desligado 
echo (função de ativada de fábrica)
echo.
echo 3 hiberna o computador mesmo desligado
echo consome pouca energia e ram, mas continua ligado
echo.
set /p "opc=>"
if "%opc%"=="1" goto 1
if "%opc%"=="2" goto 2
if "%opc%"=="3" goto 3
if /i "%opc%"=="x" goto x
echo opção inválida, tente novamente
timeout /t 2 >nul
goto menu

:1
:: equilibrado
powercfg /setacvalueindex 381b4222-f694-41f0-9685-ff5bb260df2e SUB_SLEEP lidaction 0
powercfg /setdcvalueindex 381b4222-f694-41f0-9685-ff5bb260df2e SUB_SLEEP lidaction 0
powercfg /S 381b4222-f694-41f0-9685-ff5bb260df2e

:: Economia de energia
powercfg /setacvalueindex a1841308-3541-4fab-bc81-f71556f20b4a SUB_SLEEP lidaction 0
powercfg /setdcvalueindex a1841308-3541-4fab-bc81-f71556f20b4a SUB_SLEEP lidaction 0
powercfg /S a1841308-3541-4fab-bc81-f71556f20b4a

:: Alto desempenho
powercfg /setacvalueindex 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c SUB_SLEEP lidaction 0
powercfg /setdcvalueindex 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c SUB_SLEEP lidaction 0
powercfg /S 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c


goto per

:2
:: equilibrado
powercfg /setacvalueindex 381b4222-f694-41f0-9685-ff5bb260df2e SUB_SLEEP lidaction 1
powercfg /setdcvalueindex 381b4222-f694-41f0-9685-ff5bb260df2e SUB_SLEEP lidaction 1
powercfg /S 381b4222-f694-41f0-9685-ff5bb260df2e

:: Economia de energia
powercfg /setacvalueindex a1841308-3541-4fab-bc81-f71556f20b4a SUB_SLEEP lidaction 1
powercfg /setdcvalueindex a1841308-3541-4fab-bc81-f71556f20b4a SUB_SLEEP lidaction 1
powercfg /S a1841308-3541-4fab-bc81-f71556f20b4a

:: Alto desempenho
powercfg /setacvalueindex 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c SUB_SLEEP lidaction 1
powercfg /setdcvalueindex 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c SUB_SLEEP lidaction 1
powercfg /S 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c

goto per

:3
:: equilibrado
powercfg /setacvalueindex 381b4222-f694-41f0-9685-ff5bb260df2e SUB_SLEEP lidaction 2
powercfg /setdcvalueindex 381b4222-f694-41f0-9685-ff5bb260df2e SUB_SLEEP lidaction 2
powercfg /S 381b4222-f694-41f0-9685-ff5bb260df2e

:: Economia de energia
powercfg /setacvalueindex a1841308-3541-4fab-bc81-f71556f20b4a SUB_SLEEP lidaction 2
powercfg /setdcvalueindex a1841308-3541-4fab-bc81-f71556f20b4a SUB_SLEEP lidaction 2
powercfg /S a1841308-3541-4fab-bc81-f71556f20b4a

:: Alto desempenho
powercfg /setacvalueindex 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c SUB_SLEEP lidaction 2
powercfg /setdcvalueindex 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c SUB_SLEEP lidaction 2
powercfg /S 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
goto per

:per
cls
msg * "computador mudado para alto desempenho para aplicar mudanças, mude-o plano de energia no menu se desejar"
echo deseja reiniciar o computador para aplicar as mudanças?
echo [1] sim
echo [2] aplicar ao ser desligado
echo =======================================================
set /p "opc=>"
if "%opc%"=="1" goto sut
if "%opc%"=="2" goto x
echo opção inválida, tente novamente
goto per
:sut
shutdown /r
:x
call c:\trix_cmd\1\escolha.bat
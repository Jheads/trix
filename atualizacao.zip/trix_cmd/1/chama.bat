powershell -ExecutionPolicy Bypass -File "c:\trix_cmd\1\avaliar.ps1"
exit

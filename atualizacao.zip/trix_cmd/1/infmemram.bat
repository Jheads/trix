@echo off
chcp 65001
color 8
@echo off
chcp 65001 >nul
cls 

if exist "%userprofile%\dados\nome\*.txt" (
   for /f "usebackq delims=" %%a in ("%userprofile%\dados\nome\*.txt") do (
       set  nome=%%a
   )
)
echo nome: "%nome%"

cls
cls
echo ====================================================
echo              o que é memoria ram?
echo ====================================================
echo %nome%, irei dar uma breve explicação de o que é memória RAM e 
echo memória ROM.
echo a memória ram é um dos 2 tipos de memória do computador, ela é responsavel 
echo por deixar o computador mais flúido sem travamentos.
echo a memória ram é importante? sim ela é importante para seu computador pois 
echo sem ela o seu computador nem ligaria a tela.
echo como dito a memória ram a memória ram é uma das DUAS memórias do computador,
echo mas qual é a outra? é a memória ROM conhecida como memória interna ou
echo memória de armazenamento
echo pressione (S/N) para dizer se entendeu o que é memória ram
set /p "opc=entendeu o que é memória ram? "

if "%opc%"=="s" goto sim
if "%opc%"=="sim" goto sim
if "%opc%"=="n" goto nao
if "%opc%"=="nao" goto nao
if "%opc%"=="não" goto nao

:nao
echo entendo, %nome% vou envia-lo para uma video aula
timeout /t 5 >nul
start https://youtu.be/P4NBieveSdo?si=uwO9H7xo3VZ-6aAc
timeout /t 3 >nul
call C:\trix_cmd\1\escolha.bat

:sim
echo fico grata que tenha entendido, voltando para o menu
timeout /t 5 >nul
call C:\trix_cmd\1\escolha.bat

@echo off
title Politicas estilo 1155 ET
color 0A
::créditos www.youtube.com/@1155doET
set menu=C:\trix_cmd\1\processos.bat
chcp 65001
cls
:menu
cls
echo =========================================
echo   configurações de politica
echo =========================================
echo baseados nas configurações do 1155 ET
echo.

:: ===== OPCAO 1 - TELEMETRIA =====
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v AllowTelemetry >nul 2>&1
if %errorlevel%==0 (
    for /f "tokens=3" %%a in ('reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v AllowTelemetry ^| find "REG_DWORD"') do set tel=%%a
) else set tel=1

if "%tel%"=="0x0" (
    echo [1] ativar telemetria        - envio de dados básicos para Microsoft
) else (
    echo [1] desativar telemetria     - bloqueia coleta de dados e diagnostico para microsoft
)

:: ===== OPCAO 2 - EXPERIENCIAS CONSUMIDOR =====
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v DisableWindowsConsumerFeatures >nul 2>&1
if %errorlevel%==0 (
    for /f "tokens=3" %%a in ('reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v DisableWindowsConsumerFeatures ^| find "REG_DWORD"') do set cons=%%a
) else set cons=0

if "%cons%"=="0x1" (
    echo [2] ativar experiencias      - restaura sugestoes e apps padrao
) else (
    echo [2] desativar experiencias   - impede bloat[instalação automatica de apps] e anuncios
)

:: ===== OPCAO 3 - EXPERIENCIAS PERSONALIZADAS =====
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v DisableTailoredExperiencesWithDiagnosticData >nul 2>&1
if %errorlevel%==0 (
    for /f "tokens=3" %%a in ('reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v DisableTailoredExperiencesWithDiagnosticData ^| find "REG_DWORD"') do set tailor=%%a
) else set tailor=0

if "%tailor%"=="0x1" (
    echo [3] ativar personalizacao    - usa dados para recomendacoes de anuncios e etc..
) else (
    echo [3] desativar personalizacao - remove sugestoes inteligentes
)

:: ===== OPCAO 4 - APPS EM BACKGROUND =====
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled >nul 2>&1
if %errorlevel%==0 (
    for /f "tokens=3" %%a in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled ^| find "REG_DWORD"') do set bg=%%a
) else set bg=0

if "%bg%"=="0x1" (
    echo [4] ativar apps background   - apps podem rodar em segundo plano
) else (
    echo [4] desativar apps background-  menos consumo de RAM/CPU
)

:: ===== OPCAO 5 - WINDOWS UPDATE =====
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" /v NoAutoUpdate >nul 2>&1
if %errorlevel%==0 (
    for /f "tokens=3" %%a in ('reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" /v NoAutoUpdate ^| find "REG_DWORD"') do set wu=%%a
) else set wu=0

if "%wu%"=="0x1" (
    echo [5] ativar windows update    - updates automaticos
) else (
    echo [5] desativar windows update - sem updates automáticos automaticos
)

:: ===== OPCAO 6 - DRIVERS =====
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v ExcludeWUDriversInQualityUpdate >nul 2>&1
if %errorlevel%==0 (
    for /f "tokens=3" %%a in ('reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v ExcludeWUDriversInQualityUpdate ^| find "REG_DWORD"') do set drv=%%a
) else set drv=0

if "%drv%"=="0x1" (
    echo [6] ativar drivers WU       - drivers atualizam via Windows Update 
) else (
    echo [6] desativar drivers WU    - drivers atualizam só manualmente
)

:: ===== OPCAO 7 - MICROSOFT STORE =====
reg query "HKLM\SOFTWARE\Policies\Microsoft\WindowsStore" /v RemoveWindowsStore >nul 2>&1
if %errorlevel%==0 (
    for /f "tokens=3" %%a in ('reg query "HKLM\SOFTWARE\Policies\Microsoft\WindowsStore" /v RemoveWindowsStore ^| find "REG_DWORD"') do set store=%%a
) else set store=0

if "%store%"=="0x1" (
    echo [7] ativar microsoft store  - restaura acesso e updates
) else (
    echo [7] desativar microsoft store- remove store e auto updates
)

:: ===== OPCAO 8 - PRIORIDADE CPU =====
reg query "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v Win32PrioritySeparation >nul 2>&1
if %errorlevel%==0 (
    for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v Win32PrioritySeparation ^| find "REG_DWORD"') do set cpu=%%a
) else set cpu=0x2

if "%cpu%"=="0x26" (
    echo [8] restaurar prioridade     - padrão do Windows
) else (
    echo [8] priorizar desempenho     - foco no app em uso
)
if "%svc%"=="0x400000" (
    echo [9] restaurar svchost padrao
) else (
    echo [9] otimizar svchost "[4 GB] engana" o windows fazendo ele usar menos processos
)

echo.
echo [X] sair
echo.
set /p op=Escolha:

if "%op%"=="1" goto 1
if "%op%"=="2" goto 2
if "%op%"=="3" goto 3
if "%op%"=="4" goto 4
if "%op%"=="5" goto 5
if "%op%"=="6" goto 6
if "%op%"=="7" goto 7
if "%op%"=="8" goto 8
if "%op%"=="9" goto 9
if /i "%op%"=="x" %menu%
goto menu

:: ===== TOGGLES =====

:1
if "%tel%"=="0x0" (
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v AllowTelemetry /t REG_DWORD /d 1 /f
) else (
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v AllowTelemetry /t REG_DWORD /d 0 /f
)
goto menu

:2
if "%cons%"=="0x1" (
    reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v DisableWindowsConsumerFeatures /f
) else (
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v DisableWindowsConsumerFeatures /t REG_DWORD /d 1 /f
)
goto menu

:3
if "%tailor%"=="0x1" (
    reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v DisableTailoredExperiencesWithDiagnosticData /f
) else (
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v DisableTailoredExperiencesWithDiagnosticData /t REG_DWORD /d 1 /f
)
goto menu

:4
if "%bg%"=="0x1" (
    reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled /f
) else (
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 1 /f
)
goto menu

:5
if "%wu%"=="0x1" (
    reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" /v NoAutoUpdate /f
) else (
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" /v NoAutoUpdate /t REG_DWORD /d 1 /f
)
goto menu

:6
if "%drv%"=="0x1" (
    reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v ExcludeWUDriversInQualityUpdate /f
) else (
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v ExcludeWUDriversInQualityUpdate /t REG_DWORD /d 1 /f
)
goto menu

:7
if "%store%"=="0x1" (
    reg delete "HKLM\SOFTWARE\Policies\Microsoft\WindowsStore" /v RemoveWindowsStore /f
) else (
    reg add "HKLM\SOFTWARE\Policies\Microsoft\WindowsStore" /v RemoveWindowsStore /t REG_DWORD /d 1 /f
)
goto menu

:8
if "%cpu%"=="0x26" (
    reg add "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v Win32PrioritySeparation /t REG_DWORD /d 2 /f
) else (
    reg add "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v Win32PrioritySeparation /t REG_DWORD /d 26 /f
)
:9
setlocal EnableExtensions EnableDelayedExpansion
reg query "HKLM\SYSTEM\CurrentControlSet\Control" /v SvcHostSplitThresholdInKB >nul 2>&1
if %errorlevel%==0 (
    for /f "tokens=3" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control" /v SvcHostSplitThresholdInKB ^| find "REG_DWORD"') do set svc=%%a
) else (
    set svc=0
)

if "%svc%"=="0x400000" (
    reg delete "HKLM\SYSTEM\CurrentControlSet\Control" /v SvcHostSplitThresholdInKB /f
    echo Svchost restaurado para o padrao
) else (
    reg add "HKLM\SYSTEM\CurrentControlSet\Control" /v SvcHostSplitThresholdInKB /t REG_DWORD /d 4194304 /f
    echo Svchost otimizado para 4 GB
)

echo.
echo Reinicio necessario para aplicar.
timeout /t 2 >nul
goto menu

﻿:menu
cls
net session >nul 2>&1
if %errorlevel% neq 0 (
   echo solicitando privilégios de adm...
   powershell -command "start-process cmd -argumentlist '/c \"%~f0\"' -verb runas"
   exit
)
echo rodando script trix com privilégios de administrador
cls
@echo off 
chcp 65001
color 0d
cls
echo =====================escolha de performance==================================
echo [1] equilibrado
echo [2] alto desempenho 
echo [3] econômia de energia 
echo [i] ajuda
echo [x] menu
echo =============================================================================
echo I
echo I
echo I
echo I
echo I
echo I
ECHO =-=-=-=-=-=-=-==-=-=-=--=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-
echo 1-recomendado para notebooks
echo 2-recomendado para computadores sem baterias, dispositivos
echo com bateria irão consumir mais bateria se ativado
echo 3-restringe todo o desempenho para economizar energia
echo 6-escolha como as animações de tela serão executadas. Se todas as animações forem ativadas podem deixar o computador mais lento, dependendo do computador.
echo =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=
echo ATENÇÃO! AS OPÇÕES 4 E 5 PODEM NÃO FUNCIONAR EM ALGUNS COMPUTADORES!
echo =-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
set /p escolha="escolha uma opcao="

if "%escolha%"=="1" goto equilibrado
if "%escolha%"=="2" goto alto
if "%escolha%"=="3" goto economia
if /i "%escolha%"=="i" call C:\trix_cmd\1\recomendacao.bat
if /i "%escolha%"=="x" goto voltar
echo opção inválida, tente novamente.
timeout /t 2 >nul
goto menu
pause

:equilibrado
cls
powercfg /setactive 381b4222-f694-41f0-9685-ff5bb260df2e
if %errorlevel% neq 0 (
  echo erro ao ativar o esquema 'equilibrado'. verifique o GUID ou permissoes.
  pause
  goto menu
)
echo 'equilibrado' foi ativado!
timeout /t 2 >nul
goto menu

:alto
cls
powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
if %errorlevel% neq 0 (
  echo erro ao ativar o esquema 'alto desempenho'. verifique o GUID ou permissoes.
  pause
  goto menu
)
echo 'alto desempenho' foi ativado!
timeout /t 2 >nul
goto menu

:economia
cls
powercfg /setactive a1841308-3541-4fab-bc81-f71556f20b4a
if %errorlevel% neq 0 (
  echo erro ao ativar o esquema 'economia de enrgia'. verifique o GUID ou permissoes.
  pause
  goto menu
)
echo 'economia de energia' foi ativado!
timeout /t 2 >nul
goto menu


:voltar
cls
call C:\trix_cmd\1\escolha.bat
pause
exit
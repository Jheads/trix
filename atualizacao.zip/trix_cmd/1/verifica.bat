@echo off
chcp 65001
cls
set /p menu=<c:\trix_cmd\0\menu.txt
if exist %userprofile%\dados\status\menu-inicia.txt (
   powershell remove-item -path %userprofile%\dados\status\menu-inicia.txt -recurse -force
   cls
   %menu%
   exit
)
if exist %userprofile%\dados\status\escolha-inicia.txt (
   powershell remove-item -path %userprofile%\dados\status\escolha-inicia.txt -recurse -force
   cls
   start c:\trix_cmd\1\escolha.bat
   exit
)
echo erro de caminho
timeout /t 2 >nul
exit
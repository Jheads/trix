﻿set /p menu=<c:\trix_cmd\0\menu.txt
 
@echo off 
chcp 65001
for /F %%a in ('"prompt $E & for %%b in (1) do rem"') do set "ESC=%%a"
set rd=%%ESC%%[31m
set nl=%%ESC%%[30m
set gr=%%ESC%%[32m
set yw=%%ESC%%[33m
set bl=%%ESC%%[34m
set pl=%%ESC%%[35m
set ci=%%ESC%%[36m
set we=%%ESC%%[37m
set sd=%%ESC%%[0m
set ln=%gr%
set cl=%pl%
set c11=%userprofile%\dados\pers\cor\cl
set L11=%userprofile%\dados\pers\cor\ln
if exist %c11%\rd.txt (
   set cl=%rd%
)
if exist %c11%\nl.txt (
   set cl=%nl%
)
if exist %c11%\gr.txt (
   set cl=%gr%
)
if exist %c11%\yw.txt (
   set cl=%yw%
)
if exist %c11%\bl.txt (
   set cl=%bl%
)
if exist %c11%\pl.txt (
   set cl=%pl%
)
if exist %c11%\ci.txt (
   set cl=%ci%
)
if exist %c11%\we.txt (
   set cl=%we%
)
if exist %c11%\sd.txt (
   set cl=%sd%
)
::linhas
if exist %L11%\rd.txt (
   set ln=%rd%
)
if exist %l11%\nl.txt (
   set ln=%nl%
)
if exist %l11%\gr.txt (
   set ln=%gr%
)
if exist %l11%\yw.txt (
   set ln=%yw%
)
if exist %l11%\bl.txt (
   set ln=%bl%
)
if exist %l11%\pl.txt (
   set ln=%pl%
)
if exist %l11%\ci.txt (
   set ln=%ci%
)
if exist %l11%\we.txt (
   set ln=%we%
)
if exist %l11%\sd.txt (
   set ln=%sd%
)
%cr%
cls 
cls
:inicio
cls
call echo %cl%=======================================================
call echo                 %gr%MENNU DE OTIMIZAÇÃO DA RAM%cl%
call echo =======================================================%yw%
call echo [1] %ln%performance de energia%yw%
call echo [2] %ln%efeitos visuais%yw%
call echo [3] %ln%otimização RAM%yw%
call echo [4] %ln%otimizar politica do windows e processos%yw% [BETA]
call echo [5] %ln%otimizar internet%yw%
call echo [6] %ln%avaliar computador%yw%
call echo [7] %ln%configurar desligar%yw%
call echo [8] %ln%fazer debloat básico%yw%
call echo [9] %ln%otimização via Winscript%yw%
call echo %rd%[x] %ln%voltar ao menu%yw%
call echo [i] o que é memória ram?%cl%
call echo =======================================================%yw%
call echo digite 1,2,3 ou 4 e clique enter para selecionar.
echo digite i para informações.
set /p "opc= escolha uma opção= "

if "%opc%"=="1" cls & goto opc1
if "%opc%"=="2" cls & goto opc2
if "%opc%"=="3" cls & goto opc3
if "%opc%"=="4" cls & goto opc4
if "%opc%"=="5" cls & goto opc5
if "%opc%"=="6" cls & goto opc6
if "%opc%"=="7" cls & goto opc7
if "%opc%"=="8" cls & goto opc8
if "%opc%"=="9" cls & goto opc9

if /i "%opc%"=="x" cls & goto opcx
if /i "%opc%"=="i" cls & goto opci
call echo %rd%opção inválida, tente novamente
timeout /t 2 >nul
goto inicio

:opc9
powershell -command ("irm "https://winscript.cc/irm" | iex")
cls
goto inicio

:opc8
call C:\trix_cmd\1\debloat.bat
goto menu

:opc7
echo aviso: alguns computadores ficam ligados mesmo após serem desligados 
echo para uma inicialização mais rápida mas isso pode degradar baterias em 
echo notebooks e consumir energia mesmo desligado, essa opção desativa 
echo esse comportamento 
echo [pressione qualquer tecla para ir ao menu]
pause >nul
call c:\trix_cmd\1\desligar.bat
goto inicio

:opc6
echo 1 > %userprofile%\dados\status\escolha-inicia.txt
start c:\trix_cmd\1\chama.bat
exit

:opc1
 echo entendido, abrindo performance de energia... 
timeout /t 5 >nul 
call C:\trix_cmd\1\1a-trix-performace.bat
echo algo deu errado...
timeout /t 2 >nul
goto inicio

:opc2
echo entendido, abrindo efeitos visuais...  
timeout /t 5 >nul 
call c:\trix_cmd\1\efeitos.bat
echo algo deu errado..
timeout /t 2 >nul
goto incio

:opc3
:: Verifica se o script tem permissões de administrador
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo O script precisa ser executado como administrador.
    powershell -Command "Start-Process cmd -ArgumentList '/c %~fnx0' -Verb RunAs"
    exit
)

echo Otimizando RAM...

:: Coleta de lixo do .NET
powershell -Command "[System.GC]::Collect()"

:: Limpeza do arquivo temporário
powershell -Command "Write-Output \"\" | Out-File \"$env:TEMP\clear_memory.tmp\" -Encoding ASCII; Remove-Item \"$env:TEMP\clear_memory.tmp\""

:: Verificar se o pagefile.sys existe e tentar limpá-lo
if exist C:\pagefile.sys (
    powershell -Command "Clear-Content C:\\pagefile.sys -Force"
) else (
    echo Pagefile.sys não encontrado ou desabilitado.
)

:: Forçar coleta de memória
powershell -Command "& {[void] [System.GC]::Collect()}"

:: Desabilita e remove o arquivo de paginação se necessário
wmic pagefile set AutomaticManagedPagefile=False  
wmic pagefile where name="C:\\pagefile.sys" delete  

:: Apagar arquivos temporários e cache
del /s /f /q C:\Windows\Prefetch\*  
del /s /f /q C:\Windows\System32\wbem\Logs\*  
del /s /f /q %temp%\*  
del /s /f /q C:\Windows\Temp\*  
rd /s /q %temp%  
md %temp%
%SystemRoot%\System32\mdsched.exe /r
C:\Windows\System32\mdsched.exe /r & echo agendamento
echo Memória otimizada e arquivos temporários limpos!
echo pressione qualquer tecla para voltar
pause >nul
goto inicio


echo memória otimizada!
echo para voltar ao inicio pressione qualquer tecla
pause >nul
goto inicio

:opc4
echo abrindo processos em segundo plano....
timeout /t 2 >nul
call c:\trix_cmd\1\processos.bat
echo algo deu errado
timeout /t 2 >nul
goto incio

:opc5
echo otimizando internet!
netsh winsock reset
netsh int ip reset
ipconfig /release
ipconfig /flushdns
ipconfig /renew
echo testando conexão...
ping google.com
echo internet otimizada!
echo para voltar ao menu pressione qualquer tecla
pause >nul
goto inicio

:opcx
echo voltando para o menu... 
timeout /t 5 >nul 
%menu%
echo algo deu errado
timeout /t 2 >nul
goto inicio

:opci
cls
call C:\trix_cmd\1\infmemram.bat
echo algo deu errado...
timeout /t 2 >nul
goto inicio
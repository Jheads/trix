@echo off
chcp 65001
@echo off
mkdir %userprofile%\dados\debloat
set caminho=%userprofile%\dados\debloat
set extras=%caminho%\remove-extras.txt
set /p menu=c:\trix_cmd\1\escolha.bat
set ctt=<C:\trix_cmd\9\biblioteca-extensoes\ctt-tools.txt
:menu
cls
echo =================================================
echo              MENU DE DEBLOAT
echo =================================================
echo [1] debloat total
echo [2] otimização de ponta
echo [x] voltar
echo -------------------------------------------------
set /p "opc=> "
if "%opc%"=="1" goto 1
if "%opc%"=="2" goto 2
if /i "%opc%"==""x goto sair
echo opção inválida, tente novamente!
timeout /t 2 >nul
goto menu

:erro
echo erro inesperado, reiniciando página
timeout /t 2 >nul
goto menu
:2
powershell -command "irm "https://christitus.com/win" | iex"
goto menu

:1
cls
echo > %cache%\%opc%.txt
echo deseja remover ou desativar todos os blotwares?
echo AVISO: após desinstalar não terá como instalar novamente por aqui
echo somente pela internet ou sites oficiais da Microsoft
if not exist %extras% ( 
    echo [1] remover e bloquear
) else ( 
    echo [1] habilitar
)
echo [x] voltar
set /p "opc=> "
if "%opc%"=="1" goto rem-extras
if /i "%opc%"=="x" goto menu
echo opção inválida, tente novamente
timeout /t 2 >nul
:rem-extras
if not exist %extras% (
    powershell -command "Get-AppxPackage *WebView2* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *WebView2*"
    powershell -command "Get-AppxPackage *WindowsStore* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *WindowsStore*"
    powershell -command "Get-AppxPackage *GetHelp* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *GetHelp*"
    powershell -command "Get-AppxPackage *Getstarted* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *Getstarted*
    powershell -command "Get-AppxPackage *People* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *People* 
    powershell -command "Get-AppxPackage *Xbox* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *Xbox*
    powershell -command "Get-AppxPackage *Bing* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *Bing*
    powershell -command "Get-AppxPackage *Zune* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *Zune*
    powershell -command "Get-AppxPackage *Solitaire* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *Solitaire*"
    powershell -command "Get-AppxPackage *YourPhone* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *YourPhone* 
    powershell -command "Get-AppxPackage *MixedReality* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *MixedReality*
    powershell -command "Get-AppxPackage *OfficeHub* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *OfficeHub*
    powershell -command "Get-AppxPackage *Todos* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *Todos*
    powershell -command "Get-AppxPackage *StickyNotes* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *StickyNotes*
    powershell -command "Get-AppxPackage *Maps* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *Maps*
    powershell -command "Get-AppxPackage *FeedbackHub* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *FeedbackHub*
    powershell -command "Get-AppxPackage *Microsoft.XboxGameCallableUI* | Remove-AppxPackage"
    powershell -command "Get-AppxPackage *Microsoft.XboxGameCallableUI*
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v AllowTelemetry /t REG_DWORD /d 0 /f
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Privacy" /v TailoredExperiencesWithDiagnosticDataEnabled /t REG_DWORD /d 0 /f
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo" /v Enabled /t REG_DWORD /d 0 /f
    reg add "HKCU\Software\Policies\Microsoft\Windows\Explorer" /v DisableSearchBoxSuggestions /t REG_DWORD /d 1 /f
    reg add "HKCU\Software\Microsoft\InputPersonalization" /v RestrictImplicitTextCollection /t REG_DWORD /d 1 /f
    reg add "HKCU\Software\Microsoft\InputPersonalization" /v RestrictImplicitInkCollection /t REG_DWORD /d 1 /f
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People" /v PeopleBand /t REG_DWORD /d 0 /f
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v DisablePeopleBand /t REG_DWORD /d 1 /f
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338393Enabled /t REG_DWORD /d 0 /f
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338388Enabled /t REG_DWORD /d 0 /f
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v RotatingLockScreenEnabled /t REG_DWORD /d 0 /f
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v RotatingLockScreenOverlayEnabled /t REG_DWORD /d 0 /f
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Dsh" /v AllowNewsAndInterests /t REG_DWORD /d 0 /f
    reg add "HKCU\Software\Policies\Microsoft\Windows\WindowsCopilot" /v TurnOffWindowsCopilot /t REG_DWORD /d 1 /f
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v BingSearchEnabled /t REG_DWORD /d 0 /f
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v CortanaConsent /t REG_DWORD /d 0 /f
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v EnableActivityFeed /t REG_DWORD /d 0 /f
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v PublishUserActivities /t REG_DWORD /d 0 /f
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v UploadUserActivities /t REG_DWORD /d 0 /f
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v AllowTelemetry /t REG_DWORD /d 0 /f
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v BackgroundModeEnabled /t REG_DWORD /d 0 /f
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v StartupBoostEnabled /t REG_DWORD /d 0 /f
    gpupdate /force
    taskkill /f /im explorer.exe
    start explorer.exe
    echo bloatwares de baixa prioridade foram removidos
    echo regras de politica foram adicionadas para bloquar a instalação
    echo dos aplicativos após uma atualização.
    echo      [pressione qualquer tecla para continuar]
    pause >nul
    echo > %extras%
    goto 1
) else (
    reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People" /v PeopleBand /f
    reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v DisablePeopleBand /f
    reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338393Enabled /f
    reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338388Enabled /f
    reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v RotatingLockScreenEnabled /f
    reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v RotatingLockScreenOverlayEnabled /f
    reg delete "HKLM\SOFTWARE\Policies\Microsoft\Dsh" /v AllowNewsAndInterests /f
    reg delete "HKCU\Software\Policies\Microsoft\Windows\WindowsCopilot" /v TurnOffWindowsCopilot /f
    reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v BingSearchEnabled /f
    reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v CortanaConsent /f
    reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v EnableActivityFeed /f
    reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v PublishUserActivities /f
    reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v UploadUserActivities /f
    reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v AllowTelemetry /f
    reg delete "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v BackgroundModeEnabled /f
    reg delete "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v StartupBoostEnabled /f
    echo agora os aplicativos poderão ser reinstalados
    echo      [pressione qualquer tecla para voltar]
    pause >nul
    goto 1
)
:sair
powershell remove-item C:\trix_cmd\cache\* -recurse -force
%menu%
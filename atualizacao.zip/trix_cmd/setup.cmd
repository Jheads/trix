﻿@echo off
:inn
chcp 65001
@echo off
if exist c:\trix_cmd\adm.txt goto aviso2
if not exist C:\trix_Cmd (
   goto notfound 
   ) else (
   goto inicio
)
:notfound
cls
echo [===============================================================================]
echo                  baixando sistema no disco C, aguarde...
echo [===============================================================================]
Echo "0%[                                                                             ]"
powershell -command "$p = Get-ChildItem C:\,D:\,E:\ -Directory -Filter trix_cmd -Recurse -Depth 5 -ErrorAction SilentlyContinue | Select-Object -First 1; if ($p) { Copy-Item $p.FullName -Destination C:\ -Recurse -Force; echo 'copiado para C:\' } else { echo 'não encontrado' }"
if errorlevel 1 (
   echo erro desconhecido, tentando segunda via...
   mkdir C:\trix_cmd
   robocopy %userprofile%\Downloads\trix_cmd C:\trix_cmd
)
if not exist C:\trix_cmd (
   echo erro desconhecido, tente novamente
)
goto inn
:inicio
cls
echo ====================================================================================================
echo                                      SEJA BEM VINDO! 
echo ====================================================================================================
echo na primeira instação irei dar alguns avisos, depois o sistema iniciará normalmente sem esses avisos!
echo info: para pular qualquer aviso é só apertar enter repetidamente, mas aconselho que veja esse aviso!
echo.
echo AVISO: o sistema trix necessita de privilégios administrativos para funcionar corretamente
echo se o sistema não estiver com privilégios pode dar erros, bugs ou artefatos!
echo inicie o instalador como adminstrador ou confirme posisitivamente na proxima tela de diálogo
echo.
echo INFO: o sistema é open source então não tenha medo, se quiser você poderá abrir os arquivos e modifica-los
echo tanto para corrigir algum bug ou para seu alivio. a maioria das versões trix são open source mas possuem direitos autorais
echo então abaixe do site oficial para não ter riscos de pegar algum virús!
echo.
echo [pressione qualquer tecla para pular]
pause >nul
cls
net session >nul 2>&1
if %errorlevel% neq 0 (
   echo solicitando privilégios de adm...
   powershell -command "start-process cmd -argumentlist '/c \"%~f0\"' -verb runas"
   echo rodando com privilégios de administrador
   echo > c:\trix_cmd\adm.txt
   timeout /t 2 >nul
   echo -------------------FALHA NA PERMISSÃO ADMINISTRATIVA-----------------------
   exit /b
)
:aviso2
if exist c:\trix_cmd\adm.txt (
   powershell remove-item C:\trix_cmd\adm.txt -recurse -force
)
cls
echo ------------------------------------INFO opcionais---------------------------------------------------
echo os sistemas trix tem a interface mais antiga para diminuir o uso de ram, ele foi feito em um windows 10 e 
echo descontinuado depois de 2 anos.
echo sistemas trix tem versões modificadas que podem ajudar em certos componentes únicos para cada computador, 
echo mas também podem acabar espalhando algum virús.
echo o sistema trix já foi testado em 
echo windows modificados
echo windows 10
echo windows 10 ltsc
echo windows 10 lot entreprise
echo windows MBR,GPT,UEFI,LEGACY
echo computadores com 4 de ram podem demorar mais na limpeza!
echo windwos mais antigos podem apresentar maior taxa de bugs ou falta de componentes recentes!
echo o sistema tem comandos de remover arquivos para limpeza e o windows defender pode acabar 
echo bloqueando algum desses arquivos.
echo o sistema é 90% off-line, apenas em atualizações ou em baixar aplicativos o sistema entra em contato com 
echo internet!
echo o sitema normalmente recebe vários remakes para deixa-lo mais leve e amigável.
echo.
echo [pressione qualquer tecla para pular]
pause >nul
echo carregando instalação...
timeout /t 2 >nul
call c:\trix_cmd\0\0instalador.bat
if errorlevel 1 (
   echo um erro ocorreu, tentando segunda via
   start c:\trix_cmd\0\0instalador.bat
   exit
)
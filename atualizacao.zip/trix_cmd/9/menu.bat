﻿@echo off
chcp 65001
set extensoes=C:\trix_Cmd\9\biblioteca-extensoes
set windows=C:\trix_Cmd\9\biblioteca-windows
set biblioteca=C:\trix_cmd\biblioteca
set jogos=C:\trix_cmd\biblioteca-jogos
set defesa=C:\trix_cmd\defesa
set status-extensoes=%userprofile%\dados\status\extensoes.txt
set status-windows=%userprofile%\dados\status\windows.txt
set status-lupa=%userprofile%\dados\status\lupa.txt
set status-jogos=%userprofile%\dados\status\jogos.txt
set status-defesa=%userprofile%\dados\status\defesa.txt
set /p menu=<c:\trix_cmd\0\menu.txt
@echo off
:menu
cls
echo as alterações serão feitas ao voltar ao menu
echo =====================================================
if not exist %status-extensoes% ( 
   echo [1] remover biblioteca de extensoes
   ) else ( 
   echo [1] criar biblioteca de extensoes
)
if not exist %status-windows% (
   echo [2] remover biblioteca de ativação windows
   ) else ( 
   echo [2] criar biblioteca de ativação
)
if not exist %status-lupa% (
   echo [3] remover pesquisa
   ) else (
   echo [3] criar biblioteca da pesquisa
)
if not exist %status-jogos% (
   echo [4] remover biblioteca de jogos
   ) else ( 
   echo [4] criar biblioteca de jogos
)
if not exist %status-defesa% (
   echo [5] remover biblioteca de defesa
   ) else (
   echo [5] cirar biblioteca de defesa
)
echo [x] voltar
echo ----------------------------------------------------
if exist %status-jogos% echo jogos serão excluidos
if exist %status-windows% echo ativação será excluida
if exist %status-lupa% echo lupa será excluida
if exist %status-defesa% echo defesa será excluida
if exist %status-extensoes% echo extensoes serão exluidas
echo =====================================================
set /p "opc=>"
if "%opc%"=="1" goto 1
if "%opc%"=="2" goto 2
if "%opc%"=="3" goto 3
if "%opc%"=="4" goto 4
if "%opc%"=="5" goto 5 
if /i "%opc%"=="x" goto x
echo opção inválida, tente novamente
timeout /t 2 >nul
goto menu
:1
if not exist %status-extensoes% (
   echo > %status-extensoes%
   ) else (
     powershell remove-item %status-extensoes% -recurse -force
   echo atualize o sistema para as bibliotecas serem criadas
   timeout /t 2 >nul
)
goto menu
:2
if not exist %status-windows% (
   echo > %status-windows%
   ) else (
   powershell remove-item %status-windows% -recurse -force
   echo atualize o sistema para as bibliotecas serem criadas
   timeout /t 2 >nul
)
goto menu
:3
if not exist %status-lupa% (
   echo > %status-lupa%
   ) else (
     powershell remove-item %status-lupa% -recurse -force
   echo atualize o sistema para as bibliotecas serem criadas
   timeout /t 2 >nul
)
goto menu
:4
if not exist %status-jogos% (
   echo > %status-jogos%
   ) else (
     powershell remove-item %userprofile%\dados\status\jogos.txt -recurse -force
   echo atualize o sistema para as bibliotecas serem criadas
   timeout /t 2 >nul
)
goto menu
:5
if not exist %status-defesa% (
   echo > %status-defesa%
   ) else (
     powershell remove-item %userprofile%\dados\status\defesa.txt -recurse -force
   echo atualize o sistema para as bibliotecas serem criadas
   timeout /t 2 >nul
)
goto menu
:x
%menu%
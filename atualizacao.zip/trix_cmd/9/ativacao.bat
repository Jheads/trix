@echo off
chcp 65001
set /p menu=<c:\trix_cmd\0\menu.txt
cls
setlocal enabledelayedexpansion

set "folder=C:\trix_cmd\9\biblioteca-windows"
set /a count=0

rem Criar lista de arquivos txt
for %%f in ("%folder%\*.txt") do (
    set /a count+=1
    set "file[!count!]=%%~f"
    set "name[!count!]=%%~nf"
)

if %count%==0 (
    echo Nenhum arquivo txt encontrado em %folder%
    pause
    exit /b
)

:menu
cls
echo =======================================
echo escolha um server para ativar o windows.
echo cada servidor funciona para um windows 
echo diferente.
echo =======================================
echo [x] voltar 
echo =======================================
for /l %%i in (1,1,%count%) do (
    echo [%%i] !name[%%i]!
)
echo.
set /p "option=> "

rem Validar entrada
if /i "%option%"=="x" goto x
if "%option%"=="" goto menu
if %option% lss 1 goto menu
if %option% gtr %count% goto menu

rem Ler conte�do do arquivo escolhido
set "selected_file=!file[%option%]!"
set "command="

for /f "usebackq delims=" %%a in ("!selected_file!") do (
    set "command=%%a"
    goto execute
)

:execute
if defined command (
    echo Executando: !command!
    powershell -command "!command!"
    timeout /t 2 >nul
) else (
    echo server desativado ou comando invalido.
    echo [pressione qualquer letra para continuar]
    pause >nul
)
goto menu

:x
%menu%
